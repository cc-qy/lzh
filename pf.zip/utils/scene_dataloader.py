import torch
import torchvision
import torchvision.transforms as transforms
import torchvision.transforms.functional  as  FF
import torch.utils.data as data
import numpy as np
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse
import random
from PIL import Image
import matplotlib.pyplot as plt
import cv2
class RandomResizedCrop(object):
    """Crop the given PIL Image to random size and aspect ratio.

    A crop of random size (default: of 0.08 to 1.0) of the original size and a random
    aspect ratio (default: of 3/4 to 4/3) of the original aspect ratio is made. This crop
    is finally resized to given size.
    This is popularly used to train the Inception networks.

    Args:
        size: expected output size of each edge
        scale: range of size of the origin size cropped
        ratio: range of aspect ratio of the origin aspect ratio cropped
        interpolation: Default: PIL.Image.BILINEAR
    """

    def __init__(self, size=(370,1226), scale=(0.80, 1.0), ratio=(3. / 4., 4. / 3.), interpolation=Image.BILINEAR):
        if isinstance(size, tuple):
            self.size = size
        else:
            self.size = (size, size)
        if (scale[0] > scale[1]) or (ratio[0] > ratio[1]):
            warnings.warn("range should be of kind (min, max)")

        self.interpolation = interpolation
        self.scale = scale
        self.ratio = ratio

    @staticmethod
    def get_params(imgl1,imgr1,imgl2,imgr2, scale, ratio):
        """Get parameters for ``crop`` for a random sized crop.

        Args:
            img (PIL Image): Image to be cropped.
            scale (tuple): range of size of the origin size cropped
            ratio (tuple): range of aspect ratio of the origin aspect ratio cropped

        Returns:
            tuple: params (i, j, h, w) to be passed to ``crop`` for a random
                sized crop.
        """
        # width, height = _get_image_size(img)
        # print(imgl1.size[0])
        width = imgl1.size[0]
        height = imgl1.size[1]
        area = height * width

        for attempt in range(10):
            # target_area = random.uniform(*scale) * area
            # log_ratio = (math.log(ratio[0]), math.log(ratio[1]))
            # aspect_ratio = math.exp(random.uniform(*log_ratio))

            # w = int(round(math.sqrt(target_area * aspect_ratio)))
            # h = int(round(math.sqrt(target_area / aspect_ratio)))
            w_random = random.uniform(*scale)
            h_random = random.uniform(*scale)

            w = int(round(width * w_random))
            h = int(round(height * h_random))

            if 0 < w <= width and 0 < h <= height:
                i = random.randint(0, height - h)
                j = random.randint(0, width - w)
                return i, j, h, w

        # Fallback to central crop
        in_ratio = float(width) / float(height)
        if (in_ratio < min(ratio)):
            w = width
            h = int(round(w / min(ratio)))
        elif (in_ratio > max(ratio)):
            h = height
            w = int(round(h * max(ratio)))
        else:  # whole image
            w = width
            h = height
        i = (height - h) // 2
        j = (width - w) // 2
        return i, j, h, w

    def __call__(self, imgl1,imgr1,imgl2,imgr2):
        """
        Args:
            img (PIL Image): Image to be cropped and resized.

        Returns:
            PIL Image: Randomly cropped and resized image.
        """
        i, j, h, w = self.get_params(imgl1,imgr1,imgl2,imgr2, self.scale, self.ratio)
        # print("111111111111111111111111111")

        return FF.resized_crop(imgl1, i, j, h, w, self.size, self.interpolation),\
        FF.resized_crop(imgr1, i, j, h, w, self.size, self.interpolation),\
        FF.resized_crop(imgl2, i, j, h, w, self.size, self.interpolation),\
        FF.resized_crop(imgr2, i, j, h, w, self.size, self.interpolation)

    def __repr__(self):
        interpolate_str = _pil_interpolation_to_str[self.interpolation]
        format_string = self.__class__.__name__ + '(size={0}'.format(self.size)
        format_string += ', scale={0}'.format(tuple(round(s, 4) for s in self.scale))
        format_string += ', ratio={0}'.format(tuple(round(r, 4) for r in self.ratio))
        format_string += ', interpolation={0})'.format(interpolate_str)
        return format_string

class CenterCrop(object):
    """Crops the given PIL Image at the center.

    Args:
        size (sequence or int): Desired output size of the crop. If size is an
            int instead of sequence like (h, w), a square crop (size, size) is
            made.
    """

    def __init__(self, size=(320,896)):
        if isinstance(size, tuple):
            self.size = size
        else:
            self.size = (size, size)

    def __call__(self, img):
        """
        Args:
            img (PIL Image): Image to be cropped.

        Returns:
            PIL Image: Cropped image.
        """
        return FF.center_crop(img, self.size)

    def __repr__(self):
        return self.__class__.__name__ + '(size={0})'.format(self.size)
class RandomCrop(object):
    """Crop the given PIL.Image at a random location.

    Args:
        size (sequence or int): Desired output size of the crop. If size is an
            int instead of sequence like (h, w), a square crop (size, size) is
            made.
        padding (int or sequence, optional): Optional padding on each border
            of the image. Default is 0, i.e no padding. If a sequence of length
            4 is provided, it is used to pad left, top, right, bottom borders
            respectively.
    """

    def __init__(self, size = (320, 896), padding=0):
        if isinstance(size, tuple):
            self.size = size
        else:
            self.size = (size, size)
        self.padding = padding

    def __call__(self, imgl1,imgl2):
        """
        Args:
            img (PIL.Image): Image to be cropped.

        Returns:
            PIL.Image: Cropped image.
        """
        if self.padding > 0:
            imgl1 = ImageOps.expand(imgl1, border=self.padding, fill=0)

        w, h = imgl1.size

        th, tw = self.size
        if w == tw and h == th:
            return img

        x1 = random.randint(0, w - tw)
        y1 = random.randint(0, h - th)

        return imgl1.crop((x1, y1, x1 + tw, y1 + th)),imgl2.crop((x1, y1, x1 + tw, y1 + th))#,imgl2.crop((x1, y1, x1 + tw, y1 + th)),imgr2.crop((x1, y1, x1 + tw, y1 + th))

class RandomCrop_taowa(object):
    """Crop the given PIL.Image at a random location.

    Args:
        size (sequence or int): Desired output size of the crop. If size is an
            int instead of sequence like (h, w), a square crop (size, size) is
            made.
        padding (int or sequence, optional): Optional padding on each border
            of the image. Default is 0, i.e no padding. If a sequence of length
            4 is provided, it is used to pad left, top, right, bottom borders
            respectively.
    """

    def __init__(self, size = (320, 896), padding=0):
        if isinstance(size, tuple):
            self.size = size
        else:
            self.size = (size, size)
        self.padding = padding

    def __call__(self, imgl1,imgl2):
        """
        Args:
            img (PIL.Image): Image to be cropped.

        Returns:
            PIL.Image: Cropped image.
        """
        if self.padding > 0:
            imgl1 = ImageOps.expand(imgl1, border=self.padding, fill=0)

        w, h = imgl1.size
        # print("w, h ", (w, h))
        th, tw = self.size
        if w == tw and h == th:
            return img

        delta_w = w-tw
        delta_h = h - th

        x1 = random.randint(64, delta_w - 64)
        y1 = random.randint(0, 15)
        # print("x1, y1  ", (x1, y1))
        return imgl1.crop((x1, y1, x1 + tw, y1 + th)),imgl2.crop((x1, y1, x1 + tw, y1 + th)), x1, y1

class RandomCrop_df(object):
    """Crop the given PIL.Image at a random location.

    Args:
        size (sequence or int): Desired output size of the crop. If size is an
            int instead of sequence like (h, w), a square crop (size, size) is
            made.
        padding (int or sequence, optional): Optional padding on each border
            of the image. Default is 0, i.e no padding. If a sequence of length
            4 is provided, it is used to pad left, top, right, bottom borders
            respectively.
    """

    def __init__(self, size = (320, 896), padding=0):
        if isinstance(size, tuple):
            self.size = size
        else:
            self.size = (size, size)
        self.padding = padding

    def __call__(self, img1l,img2l, img1r, img2r):
        """
        Args:
            img (PIL.Image): Image to be cropped.

        Returns:
            PIL.Image: Cropped image.
        """
        if self.padding > 0:
            img1l = ImageOps.expand(img1l, border=self.padding, fill=0)

        w, h = img1l.size
        # print("w, h ", (w, h))
        th, tw = self.size
        if w == tw and h == th:
            return img

        delta_w = w-tw
        delta_h = h - th

        x1 = random.randint(64, delta_w - 64)
        y1 = random.randint(0, 15)
        # print("x1, y1  ", (x1, y1))
        return img1l.crop((x1, y1, x1 + tw, y1 + th)),img2l.crop((x1, y1, x1 + tw, y1 + th)), img1r.crop((x1, y1, x1 + tw, y1 + th)),img2r.crop((x1, y1, x1 + tw, y1 + th)),x1, y1

def get_kitti_cycle_data(file_path_train, path):
    f_train = open(file_path_train)
    former_left_image_train = list()
    latter_left_image_train = list()
    former_right_image_train = list()
    latter_right_image_train = list()
    
    #read from filesname_file   order is 0 2 1 3
    for line in f_train:
        former_left_image_train.append(path+line.split()[0])
        latter_left_image_train.append(path+line.split()[2])
        former_right_image_train.append(path+line.split()[1])
        latter_right_image_train.append(path+line.split()[3])
    #return left1,left2,right1,right2    
    return former_left_image_train, latter_left_image_train, former_right_image_train, latter_right_image_train


def get_raw_data(file_path_train, path):
    f_train = open(file_path_train)
    former_left_image_train = list()
    latter_left_image_train = list()

    # read from filesname_file   order is 0 2 1 3
    for line in f_train:
        former_left_image_train.append(path + line.split()[0])
        latter_left_image_train.append(path + line.split()[1])
    # return left1,left2,right1,right2
    return former_left_image_train, latter_left_image_train

def get_flow_test_data(file_path_test, path):
    f_test = open(file_path_test)
    left_image_test_1 = list()
    left_image_test_2 = list()
    flow_noc = list()
    flow_occ = list()

    for line in f_test:
        left_image_test_1.append(path + line.split()[0])
        left_image_test_2.append(path + line.split()[1])
        flow_noc.append(path + line.split()[2])
        flow_occ.append(path + line.split()[3])

    return left_image_test_1, left_image_test_2, flow_noc, flow_occ


def get_test_data(file_path_test, path):
    f_test = open(file_path_test)
    left_image_test_1 = list()
    right_image_test_1 = list()
    left_image_test_2 = list()
    right_image_test_2 = list()
    flow_noc = list()
    flow_occ = list()
    disp = list()
    k = list()

    for line in f_test:
        left_image_test_1.append(path + line.split()[0])
        right_image_test_1.append(path + line.split()[1])
        left_image_test_2.append(path + line.split()[2])
        right_image_test_2.append(path + line.split()[3])
        flow_noc.append(path + line.split()[4])
        flow_occ.append(path + line.split()[5])
        disp.append(path + line.split()[6])
        k.append(path + line.split()[7])

    return left_image_test_1, left_image_test_2, flow_noc, flow_occ


################################################################################
################################################################################
################# for pretrian by KITTI VO dataset #############################

def get_depth_flow_data_pre(file_path_train, path):
    f_train = open(file_path_train)
    left_1= list()
    left_2 = list()
    right_1 = list()
    right_2 = list()

    for line in f_train:
        left_1.append(path + line.split()[0])
        left_2.append(path + line.split()[2])
        right_1.append(path + line.split()[1])
        right_2.append(path + line.split()[3])

    return left_1, left_2, right_1, right_2


################# for finetune by KITTI MultiView dataset #############################

def get_depth_flow_data_multiview_ft(file_path_train, path):
    f_train = open(file_path_train)
    left_1= list()
    left_2 = list()

    for line in f_train:
        print(line)
        left_1.append(path + line.split()[0])
        left_2.append(path + line.split()[1])

    return left_1, left_2


def get_depth_flow_data(file_path_train, path):
    f_train = open(file_path_train)
    former_left_image_train = list()
    latter_left_image_train = list()
    former_right_image_train = list()
    latter_right_image_train = list()
    cam_intrinsic_path = list()

    # read from filesname_file   order is 0 2 1 3
    for line in f_train:
        former_left_image_train.append(path + line.split()[0])
        latter_left_image_train.append(path + line.split()[2])
        former_right_image_train.append(path + line.split()[1])
        latter_right_image_train.append(path + line.split()[3])
        cam_intrinsic_path.append(path + line.split()[4])
    # return left1,left2,right1,right2
    return former_left_image_train, latter_left_image_train, former_right_image_train, latter_right_image_train, cam_intrinsic_path


def get_data(file_path_test, path):
    f_test = open(file_path_test)
    left_image_test = list()
    right_image_test = list()

    for line in f_test:
        left_image_test.append(path+line.split()[0])
        right_image_test.append(path+line.split()[1])
        
    return left_image_test, right_image_test

def get_flow_data(file_path_test, path):
    f_test = open(file_path_test)
    flow_test = list()
    former_image_test = list()
    latter_image_test = list()

    for line in f_test:
        former_image_test.append(path+line.split()[0])
        latter_image_test.append(path+line.split()[1])
        flow_test.append(path+line.split()[2])
        
    return former_image_test, latter_image_test, flow_test

def get_transform_pre(param):
    return transforms.Compose([
        transforms.Resize([param.input_height, param.input_width]),
        transforms.ToTensor()
    ])

def get_transform(param):
    return transforms.Compose([
        # transforms.RandomCrop([param.input_height, param.input_width]),
        # transforms.Resize([param.input_height, param.input_width]),
        transforms.ToTensor(),
        # transforms.Normalize(mean=[0,0,0], std=[255,255,255]),
        # transforms.Normalize(mean=[0.411,0.432,0.45], std=[1,1,1])
    ])

def get_transform_test(param):
    return transforms.Compose([
        transforms.Resize([param.input_height, param.input_width]),
        transforms.ToTensor(),
    ])

def Resize(param):
    return transforms.Compose([
        transforms.Resize([param.input_height, param.input_width])
    ])

def Resize0(param):
    return transforms.Compose([
        transforms.Resize([370, 1226])
    ])

def Resize1():
    return transforms.Compose([transforms.Resize([384, 1280])
    ])


def add_gaussian_noise(image_in, noise_sigma):

    image_in = np.array(image_in)
    H, W, C = image_in.shape
    # print("H,W  ", (H,W))

    temp_noise = np.zeros((H,W))
    mask = np.zeros((H,W))

    ww = random.randint(int(0.2 * W), int(0.8 * W))
    hh = random.randint(0.1 * H, 0.8 * H)
    w = random.randint(30, 60)
    h = random.randint(8, 10)
    # temp[:,ww:(ww+w),hh:(hh+h)] *= 1.0

    # temp_image = np.float64(np.copy(image_in))
    #
    # h, w, _ = temp_image.shape
    # noise_sigma
    noise = np.random.randn(h, w) * noise_sigma
    temp_noise[hh:(hh + h), ww:(ww + w)] = noise
    mask[hh:(hh + h), ww:(ww + w)] *= 1.0

    noisy_image = np.zeros(image_in.shape, np.float64)
    if len(image_in.shape) == 2:
        noisy_image = image_in + temp_noise
    else:
        noisy_image[:, :, 0] = image_in[:, :, 0] + temp_noise
        noisy_image[:, :, 1] = image_in[:, :, 1] + temp_noise
        noisy_image[:, :, 2] = image_in[:, :, 2] + temp_noise

    noisy_image = Image.fromarray(np.clip((noisy_image), 0, 255).astype('uint8'), 'RGB')

    return noisy_image, mask

def add_mask(img1, img2):

    img1 = np.array(img1)
    img2 = np.array(img2)
    H, W, C = img1.shape
    # print("H,W  ", (H,W))

    # mask1 = np.ones_like(img1)
    # mask2 = np.ones_like(img2)
    mask_all = np.ones((1,H,W))

    ww = random.randint(int(0.2 * W), int(0.8 * W))
    hh = random.randint(0.1 * H, 0.8 * H)
    w = random.randint(30, 60)
    h = random.randint(10, 15)

    delta_w = -1 * random.randint(10, 20)
    delta_h = random.randint(8, 12)


    # mask1[hh:(hh + h), ww:(ww + w), :] *= 0.0
    # mask2[(hh+delta_h):(hh + h + delta_h), (ww+delta_w):(ww + w + delta_w), :] *= 0.0
    mask_all[:, (hh):(hh+h+delta_h), (ww+delta_w):(ww+w)] *= 0.0

    # img1 = img1 * mask1
    # img2 = img2 * mask2
    img1[hh:(hh + h), ww:(ww + w), :] *= 0
    img2[(hh+delta_h):(hh + h + delta_h), (ww+delta_w):(ww + w + delta_w), :] *= 0

    img1 = Image.fromarray(np.clip((img1), 0, 255).astype('uint8'), 'RGB')
    img2 = Image.fromarray(np.clip((img2), 0, 255).astype('uint8'), 'RGB')

    return img1, img2, mask_all


def read_cam(path):
    file = open(cam_intrinsic_path, 'r')
    last_line = file.readlines()[-1]
    raw_cam_vec = np.array(list(map(float, last_line.split()[1:])))
    raw_cam_mat = np.reshape(raw_cam_vec, (3, 4))
    raw_cam_mat = raw_cam_mat[0:3, 0:3]
    return raw_cam_mat


def random_flip(img1, img2):
    if random.uniform(0, 1) > 0.7:
        img1 = img1.transpose(Image.FLIP_LEFT_RIGHT)
        img2 = img2.transpose(Image.FLIP_LEFT_RIGHT)
    # if random.uniform(0, 1) > 0.7:
    #     img1 = img1.transpose(Image.FLIP_TOP_BOTTOM)
    #     img2 = img2.transpose(Image.FLIP_TOP_BOTTOM)
    return img1, img2

def random_flip_df(img1l, img2l, img1r, img2r):
    if random.uniform(0, 1) > 0.7:
        img1l = img1l.transpose(Image.FLIP_LEFT_RIGHT)
        img2l = img2l.transpose(Image.FLIP_LEFT_RIGHT)
        img1r = img1r.transpose(Image.FLIP_LEFT_RIGHT)
        img2r = img2r.transpose(Image.FLIP_LEFT_RIGHT)
    # if random.uniform(0, 1) > 0.7:
    #     img1 = img1.transpose(Image.FLIP_TOP_BOTTOM)
    #     img2 = img2.transpose(Image.FLIP_TOP_BOTTOM)
    return img1l, img2l, img1r, img2r

def random_color(img1, img2):
    if random.uniform(0, 1) > 0.8:
        brightness = random.uniform(0.85, 1.15)
        img1 = Image.fromarray(np.clip((np.array(img1) * brightness), 0, 255).astype('uint8'), 'RGB')
        img2 = Image.fromarray(np.clip((np.array(img2) * brightness), 0, 255).astype('uint8'), 'RGB')
    # if random.uniform(0, 1) > 0.7:
    #     colors = [random.uniform(0.85, 1.15) for i in range(3)]
    #     shape = np.array(left_image_1).shape
    #     white = np.ones((shape[0], shape[1]))
    #     color_image = np.stack([white * colors[i] for i in range(3)], axis=2)
    #     img1 = Image.fromarray(np.clip((np.array(img1) * color_image), 0, 255).astype('uint8'), 'RGB')
    #     img2 = Image.fromarray(np.clip((np.array(img2) * color_image), 0, 255).astype('uint8'), 'RGB')
    if random.uniform(0, 1) > 0.7:
        shape = np.array(img1).shape
        colors = [random.uniform(0.85, 1.15) for i in range(3)]
        white = np.ones((shape[0], shape[1]))
        color_image = np.stack([white * colors[i] for i in range(3)], axis=2)
        # color_image = np.random.randint(0.85, 1.15, shape)
        img1 = Image.fromarray(np.clip((np.array(img1) * color_image), 0, 255).astype('uint8'), 'RGB')
        img2 = Image.fromarray(np.clip((np.array(img2) * color_image), 0, 255).astype('uint8'), 'RGB')
    return img1, img2

def random_color_df(img1l, img2l, img1r, img2r):
    if random.uniform(0, 1) > 0.8:
        brightness = random.uniform(0.85, 1.15)
        img1l = Image.fromarray(np.clip((np.array(img1l) * brightness), 0, 255).astype('uint8'), 'RGB')
        img2l = Image.fromarray(np.clip((np.array(img2l) * brightness), 0, 255).astype('uint8'), 'RGB')
        img1r = Image.fromarray(np.clip((np.array(img1r) * brightness), 0, 255).astype('uint8'), 'RGB')
        img2r = Image.fromarray(np.clip((np.array(img2r) * brightness), 0, 255).astype('uint8'), 'RGB')
    # if random.uniform(0, 1) > 0.7:
    #     colors = [random.uniform(0.85, 1.15) for i in range(3)]
    #     shape = np.array(left_image_1).shape
    #     white = np.ones((shape[0], shape[1]))
    #     color_image = np.stack([white * colors[i] for i in range(3)], axis=2)
    #     img1 = Image.fromarray(np.clip((np.array(img1) * color_image), 0, 255).astype('uint8'), 'RGB')
    #     img2 = Image.fromarray(np.clip((np.array(img2) * color_image), 0, 255).astype('uint8'), 'RGB')
    if random.uniform(0, 1) > 0.7:
        shape = np.array(img1).shape
        colors = [random.uniform(0.85, 1.15) for i in range(3)]
        white = np.ones((shape[0], shape[1]))
        color_image = np.stack([white * colors[i] for i in range(3)], axis=2)
        # color_image = np.random.randint(0.85, 1.15, shape)
        img1l = Image.fromarray(np.clip((np.array(img1l) * color_image), 0, 255).astype('uint8'), 'RGB')
        img2l = Image.fromarray(np.clip((np.array(img2l) * color_image), 0, 255).astype('uint8'), 'RGB')
        img1r = Image.fromarray(np.clip((np.array(img1r) * color_image), 0, 255).astype('uint8'), 'RGB')
        img2r = Image.fromarray(np.clip((np.array(img2r) * color_image), 0, 255).astype('uint8'), 'RGB')
    return img1l, img2l, img1r, img2r

def random_change_channel(img1, img2):
    order = np.array([[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]])
    idx = random.randint(0, 5)
    change = order[idx]
    img1 = np.array(img1)
    channel_1 = img1[:, :, change[0]]
    channel_2 = img1[:, :, change[1]]
    channel_3 = img1[:, :, change[2]]
    img1 = np.stack([channel_1, channel_2, channel_3], axis=2)
    img1 = Image.fromarray(img1.astype('uint8'), 'RGB')

    img2 = np.array(img2)
    channel_1 = img2[:, :, change[0]]
    channel_2 = img2[:, :, change[1]]
    channel_3 = img2[:, :, change[2]]
    img2 = np.stack([channel_1, channel_2, channel_3], axis=2)
    img2 = Image.fromarray(img2.astype('uint8'), 'RGB')

    return img1, img2

def random_change_channel_df(img1l, img2l, img1r, img2r):
    order = np.array([[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]])
    idx = random.randint(0, 5)
    change = order[idx]
    img1l = np.array(img1l)
    channel_1 = img1l[:, :, change[0]]
    channel_2 = img1l[:, :, change[1]]
    channel_3 = img1l[:, :, change[2]]
    img1l = np.stack([channel_1, channel_2, channel_3], axis=2)
    img1l = Image.fromarray(img1l.astype('uint8'), 'RGB')

    img2l = np.array(img2l)
    channel_1 = img2l[:, :, change[0]]
    channel_2 = img2l[:, :, change[1]]
    channel_3 = img2l[:, :, change[2]]
    img2l = np.stack([channel_1, channel_2, channel_3], axis=2)
    img2l = Image.fromarray(img2l.astype('uint8'), 'RGB')

    img1r = np.array(img1r)
    channel_1 = img1r[:, :, change[0]]
    channel_2 = img1r[:, :, change[1]]
    channel_3 = img1r[:, :, change[2]]
    img1r = np.stack([channel_1, channel_2, channel_3], axis=2)
    img1r = Image.fromarray(img1r.astype('uint8'), 'RGB')

    img2r = np.array(img2r)
    channel_1 = img2r[:, :, change[0]]
    channel_2 = img2r[:, :, change[1]]
    channel_3 = img2r[:, :, change[2]]
    img2r = np.stack([channel_1, channel_2, channel_3], axis=2)
    img2r = Image.fromarray(img2r.astype('uint8'), 'RGB')

    return img1l, img2l, img1r, img2r

def random_crop(img1, img2):
    randomCrop = RandomCrop()
    img1, img2 = randomCrop(img1, img2)
    return img1, img2

def random_crop_taowa(img1, img2):
    randomCrop = RandomCrop_taowa()
    img1, img2, x1, y1 = randomCrop(img1, img2)
    return img1, img2, x1, y1

def random_crop_df(img1l, img2l, img1r, img2r):
    randomCrop = RandomCrop_df()
    img1l, img2l, img1r, img2r, x1, y1 = randomCrop(img1l, img2l, img1r, img2r)
    return img1l, img2l, img1r, img2r, x1, y1

def data_agumentation(img1, img2):
    ### random flip left-right
    img1, img2 = random_color(img1, img2)
    img1, img2 = random_change_channel(img1, img2)
    # img1, img2 = random_flip(img1, img2)
    img1, img2 = random_crop(img1, img2)
    img2, mask = add_gaussian_noise(img2, 25)
    return img1, img2, mask

def data_agumentation_taowa(img1, img2, param):
    ### random flip left-right
    img1, img2 = random_color(img1, img2)
    img1, img2 = random_change_channel(img1, img2)
    # img1, img2 = random_flip(img1, img2)
    img1_s, img2_s, x1, y1 = random_crop_taowa(img1, img2)
    img1_s, mask = add_gaussian_noise(img1_s, 45)
    resize = Resize(param)
    img1 = resize(img1)
    img2 = resize(img2)
    return img1, img2, img1_s, img2_s, x1, y1, mask

def data_agumentation_motion(img1, img2, param):
    ### random flip left-right
    img1, img2 = random_color(img1, img2)
    # img1, img2 = random_change_channel(img1, img2)
    # img1, img2 = random_flip(img1, img2)
    img1_s, img2_s, x1, y1 = random_crop_taowa(img1, img2)
    img1_s, img2_s, mask = add_mask(img1_s, img2_s)
    resize = Resize(param)
    img1 = resize(img1)
    img2 = resize(img2)
    return img1, img2, img1_s, img2_s, x1, y1, mask

def data_agumentation_df(img1l, img2l, img1r, img2r, cam_mat, param):
    ### random flip left-right
    img1l, img2l, img1r, img2r = random_color(img1l, img2l, img1r, img2r)
    img1l, img2l, img1r, img2r = random_change_channel(img1l, img2l, img1r, img2r)
    # img1, img2 = random_flip(img1, img2)
    img1l_s, img2l_s, img1r_s, img2r_s, x1, y1 = random_crop_df(img1l, img2l, img1r, img2r)
    cam_mat[0, 2] = cam_mat[0, 2] * width_ratio - x1
    cam_mat[1, 2] = cam_mat[1, 2] * height_ratio - y1
    resize = Resize(param)
    img1l = resize(img1l)
    img2l = resize(img2l)
    return img1l, img2l, img1l_s, img2l_s, img1r_s, img2r_s, cam_mat, x1, y1

class myCycleImageFolder(data.Dataset):
    def __init__(self, left1, left2, right1, right2, training, param):
        self.right1 = right1
        self.left1 = left1
        self.right2 = right2
        self.left2 = left2
        self.training = training
        self.param = param
        
    def __getitem__(self, index):
        left1 = self.left1[index]
        # right1 = self.right1[index]
        left2 = self.left2[index]
        # right2 = self.right2[index]
        param = self.param
        left_image_1 = Image.open(left1).convert('RGB')
        # right_image_1 = Image.open(right1).convert('RGB')
        left_image_2 = Image.open(left2).convert('RGB')
        # right_image_2 = Image.open(right2).convert('RGB')

        #augmentation
        if self.training:
            left_image_1, left_image_2, mask = data_agumentation(left_image_1, left_image_2)

        #transforms
        process = get_transform(param)
        left_image_1 = process(left_image_1)
        # right_image_1 = process(right_image_1)
        left_image_2 = process(left_image_2)
        # right_image_2 = process(right_image_2)
        
        return left_image_1, left_image_2, mask#, right_image_1, right_image_2
    def __len__(self):
        return len(self.left1)


class myCycleImageFolder_taowa(data.Dataset):
    def __init__(self, left1, left2, right1, right2, training, param):
        self.right1 = right1
        self.left1 = left1
        self.right2 = right2
        self.left2 = left2
        self.training = training
        self.param = param

    def __getitem__(self, index):
        left1 = self.left1[index]
        # right1 = self.right1[index]
        left2 = self.left2[index]
        # right2 = self.right2[index]
        param = self.param
        left_image_1 = Image.open(left1).convert('RGB')
        # right_image_1 = Image.open(right1).convert('RGB')
        left_image_2 = Image.open(left2).convert('RGB')
        # right_image_2 = Image.open(right2).convert('RGB')

        resize0 = Resize0()
        left_image_1 = resize0(left_image_1)
        left_image_2 = resize0(left_image_2)

        # augmentation
        if self.training:
            left_image_1, left_image_2, left_image_std_1, left_image_std_2, x1, y1, mask = data_agumentation_taowa(left_image_1, left_image_2, param)

        # transforms
        process = get_transform(param)
        left_image_1 = process(left_image_1)
        left_image_std_1 = process(left_image_std_1)
        # right_image_1 = process(right_image_1)
        left_image_2 = process(left_image_2)
        left_image_std_2 = process(left_image_std_2)
        # right_image_2 = process(right_image_2)

        return left_image_1, left_image_2, left_image_std_1, left_image_std_2, x1, y1, mask  # , right_image_1, right_image_2

    def __len__(self):
        return len(self.left1)

class myCycleImageFolder_motion(data.Dataset):
    def __init__(self, left1, left2, right1, right2, training, param):
        self.right1 = right1
        self.left1 = left1
        self.right2 = right2
        self.left2 = left2
        self.training = training
        self.param = param

    def __getitem__(self, index):
        left1 = self.left1[index]
        # right1 = self.right1[index]
        left2 = self.left2[index]
        # right2 = self.right2[index]
        param = self.param
        left_image_1 = Image.open(left1).convert('RGB')
        # right_image_1 = Image.open(right1).convert('RGB')
        left_image_2 = Image.open(left2).convert('RGB')
        # right_image_2 = Image.open(right2).convert('RGB')

        resize0 = Resize0()
        left_image_1 = resize0(left_image_1)
        left_image_2 = resize0(left_image_2)

        # augmentation
        if self.training:
            left_image_1, left_image_2, left_image_std_1, left_image_std_2, x1, y1, mask = data_agumentation_motion(left_image_1, left_image_2, param)

        # transforms
        process = get_transform(param)
        left_image_1 = process(left_image_1)
        left_image_std_1 = process(left_image_std_1)
        # right_image_1 = process(right_image_1)
        left_image_2 = process(left_image_2)
        left_image_std_2 = process(left_image_std_2)
        # right_image_2 = process(right_image_2)

        return left_image_1, left_image_2, left_image_std_1, left_image_std_2, x1, y1, mask  # , right_image_1, right_image_2

    def __len__(self):
        return len(self.left1)


class myCycleImageFolder_raw(data.Dataset):
    def __init__(self, left1, left2, training, param):
        self.left1 = left1
        self.left2 = left2
        self.training = training
        self.param = param

    def __getitem__(self, index):
        left1 = self.left1[index]
        # right1 = self.right1[index]
        left2 = self.left2[index]
        # right2 = self.right2[index]
        param = self.param
        left_image_1 = Image.open(left1).convert('RGB')
        # right_image_1 = Image.open(right1).convert('RGB')
        left_image_2 = Image.open(left2).convert('RGB')
        # right_image_2 = Image.open(right2).convert('RGB')

        resize0 = Resize0()
        left_image_1 = resize0(left_image_1)
        left_image_2 = resize0(left_image_2)

        # augmentation
        if self.training:
            left_image_1, left_image_2, left_image_std_1, left_image_std_2, x1, y1, mask = data_agumentation_motion(left_image_1, left_image_2, param)

        # transforms
        process = get_transform(param)
        left_image_1 = process(left_image_1)
        left_image_std_1 = process(left_image_std_1)
        # right_image_1 = process(right_image_1)
        left_image_2 = process(left_image_2)
        left_image_std_2 = process(left_image_std_2)
        # right_image_2 = process(right_image_2)

        return left_image_1, left_image_2, left_image_std_1, left_image_std_2, x1, y1, mask  # , right_image_1, right_image_2

    def __len__(self):
        return len(self.left1)


class PnP_CycleImageFolder_Pre(data.Dataset):
    def __init__(self, left1, left2, right1, right2, training, param):
        self.right1 = right1
        self.left1 = left1
        self.right2 = right2
        self.left2 = left2
        self.training = training
        self.param = param
        
    def __getitem__(self, index):
        left_1 = self.left1[index]
        left_2 = self.left2[index]
        right_1 = self.right1[index]
        right_2 = self.right2[index]
        param = self.param

        left_image_1 = Image.open(left_1).convert('RGB')
        left_image_2 = Image.open(left_2).convert('RGB')
        right_image_1 = Image.open(right_1).convert('RGB')
        right_image_2 = Image.open(right_2).convert('RGB')
     
        #augmentation
        if self.training:
            
            #randomly flip
            if random.uniform(0, 1) > 0.7:
                left_image_1 = left_image_1.transpose(Image.FLIP_LEFT_RIGHT)
                right_image_1 = right_image_1.transpose(Image.FLIP_LEFT_RIGHT)
                left_image_2 = left_image_2.transpose(Image.FLIP_LEFT_RIGHT)
                right_image_2 = right_image_2.transpose(Image.FLIP_LEFT_RIGHT)
                
            #randomly shift gamma
            if random.uniform(0, 1) > 0.7:
                gamma = random.uniform(0.9, 1.1)
                left_image_1 = Image.fromarray(np.clip((np.array(left_image_1) ** gamma), 0, 255).astype('uint8'), 'RGB')
                right_image_1 = Image.fromarray(np.clip((np.array(right_image_1) ** gamma), 0, 255).astype('uint8'), 'RGB')
                left_image_2 = Image.fromarray(np.clip((np.array(left_image_2) ** gamma), 0, 255).astype('uint8'), 'RGB')
                right_image_2 = Image.fromarray(np.clip((np.array(right_image_2) ** gamma), 0, 255).astype('uint8'), 'RGB')
            
            #randomly shift brightness
            if random.uniform(0, 1) > 0.7:
                brightness = random.uniform(0.85, 1.15)
                left_image_1 = Image.fromarray(np.clip((np.array(left_image_1) * brightness), 0, 255).astype('uint8'), 'RGB')
                right_image_1 = Image.fromarray(np.clip((np.array(right_image_1) * brightness), 0, 255).astype('uint8'), 'RGB')
                left_image_2 = Image.fromarray(np.clip((np.array(left_image_2) * brightness), 0, 255).astype('uint8'), 'RGB')
                right_image_2 = Image.fromarray(np.clip((np.array(right_image_2) * brightness), 0, 255).astype('uint8'), 'RGB')
            
            #randomly shift color
            if random.uniform(0, 1) > 0.7:
                colors = [random.uniform(0.85, 1.15) for i in range(3)]
                shape = np.array(left_image_1).shape
                white = np.ones((shape[0], shape[1]))
                color_image = np.stack([white * colors[i] for i in range(3)], axis=2)
                left_image_1 = Image.fromarray(np.clip((np.array(left_image_1) * color_image), 0, 255).astype('uint8'), 'RGB')
                right_image_1 = Image.fromarray(np.clip((np.array(right_image_1) * color_image), 0, 255).astype('uint8'), 'RGB')
                left_image_2 = Image.fromarray(np.clip((np.array(left_image_2) * color_image), 0, 255).astype('uint8'), 'RGB')
                right_image_2 = Image.fromarray(np.clip((np.array(right_image_2) * color_image), 0, 255).astype('uint8'), 'RGB')
        

        process_pre = get_transform_pre(param)
        left_img_1 = process_pre(left_image_1)
        left_img_2 = process_pre(left_image_2)
        right_img_1 = process_pre(right_image_1)
        right_img_2 = process_pre(right_image_2)
        
        return left_img_1, left_img_2, right_img_1, right_img_2

    def __len__(self):
        return len(self.left1)


###  for KITTI MultiView finetune
class PnP_CycleImageFolder_Multiview_ft(data.Dataset):
    def __init__(self, left1, left2, training, param):
        self.left1 = left1
        self.left2 = left2
        self.training = training
        self.param = param
        
    def __getitem__(self, index):
        left_1 = self.left1[index]
        left_2 = self.left2[index]

        param = self.param

        left_image_1 = Image.open(left_1).convert('RGB')
        left_image_2 = Image.open(left_2).convert('RGB')
        print("left_image_1:"+str(left_image_1.size))
        print("index"+str(index))
        #augmentation
        if self.training:
            
            #randomly flip
            if random.uniform(0, 1) > 0.7:
                left_image_1 = left_image_1.transpose(Image.FLIP_LEFT_RIGHT)
                left_image_2 = left_image_2.transpose(Image.FLIP_LEFT_RIGHT)
           
                
            #randomly shift gamma
            if random.uniform(0, 1) > 0.7:
                gamma = random.uniform(0.9, 1.1)
                left_image_1 = Image.fromarray(np.clip((np.array(left_image_1) ** gamma), 0, 255).astype('uint8'), 'RGB')
                left_image_2 = Image.fromarray(np.clip((np.array(left_image_2) ** gamma), 0, 255).astype('uint8'), 'RGB')
            
            #randomly shift brightness
            if random.uniform(0, 1) > 0.7:
                brightness = random.uniform(0.85, 1.15)
                left_image_1 = Image.fromarray(np.clip((np.array(left_image_1) * brightness), 0, 255).astype('uint8'), 'RGB')          
                left_image_2 = Image.fromarray(np.clip((np.array(left_image_2) * brightness), 0, 255).astype('uint8'), 'RGB')
            
            #randomly shift color
            if random.uniform(0, 1) > 0.7:
                colors = [random.uniform(0.85, 1.15) for i in range(3)]
                shape = np.array(left_image_1).shape
                white = np.ones((shape[0], shape[1]))
                color_image = np.stack([white * colors[i] for i in range(3)], axis=2)
                left_image_1 = Image.fromarray(np.clip((np.array(left_image_1) * color_image), 0, 255).astype('uint8'), 'RGB')
                left_image_2 = Image.fromarray(np.clip((np.array(left_image_2) * color_image), 0, 255).astype('uint8'), 'RGB')
        

        process_pre = get_transform_pre(param)
        left_img_1 = process_pre(left_image_1)
        left_img_2 = process_pre(left_image_2)

        
        return left_img_1, left_img_2

    def __len__(self):
        return len(self.left1)



class PnP_CycleImageFolder(data.Dataset):
    def __init__(self, left1, left2, right1, right2, training, param):
        self.right1 = right1
        self.left1 = left1
        self.right2 = right2
        self.left2 = left2

        self.training = training
        self.param = param

    def __getitem__(self, index):
        left1 = self.left1[index]
        right1 = self.right1[index]
        left2 = self.left2[index]
        right2 = self.right2[index]
        param = self.param

        left_image_1 = Image.open(left1).convert('RGB')
        right_image_1 = Image.open(right1).convert('RGB')
        left_image_2 = Image.open(left2).convert('RGB')
        right_image_2 = Image.open(right2).convert('RGB')

        W, H = left_image_1.size
        width_ratio = W / 1226.0
        height_ratio = H / 370.0

        raw_cam_mat = read_cam(cam_intrinsic_path)
        raw_cam_mat[0, 0] = raw_cam_mat[0, 0] * width_ratio
        raw_cam_mat[0, 2] = raw_cam_mat[0, 2] * width_ratio
        raw_cam_mat[1, 1] = raw_cam_mat[1, 1] * height_ratio
        raw_cam_mat[1, 2] = raw_cam_mat[1, 2] * height_ratio

        resize0 = Resize0()
        left_image_1 = resize0(left_image_1)
        left_image_2 = resize0(left_image_2)

        # augmentation
        if self.training:
            left_image_1, left_image_2, left_image_std_1, left_image_std_2, right_image_std_1, right_image_std_2, raw_cam_mat, x1, y1 = \
                data_agumentation_df(left_image_1, left_image_2, right_image_1, right_image_2, param)

        # transforms
        process = get_transform(param)
        left_image_1 = process(left_image_1)
        left_image_std_1 = process(left_image_std_1)
        right_image_std_1 = process(right_image_std_1)
        left_image_2 = process(left_image_2)
        left_image_std_2 = process(left_image_std_2)
        right_image_std_2 = process(right_image_std_2)
        fx = raw_cam_mat[0,0]
        K_inv = np.linalg.inv(raw_cam_mat)

        return left_image_1, left_image_2, left_image_std_1, left_image_std_2, right_image_std_1, right_image_std_2, \
               fx, raw_cam_mat,K_inv,x1, y1  # , right_image_1, right_image_2

    def __len__(self):
        return len(self.left1)


class myCycleImageFolder_df(data.Dataset):
    def __init__(self, left1, left2, right1, right2, cam_intrinsic_path, training, param):
        self.right1 = right1
        self.left1 = left1
        self.right2 = right2
        self.left2 = left2
        self.cam_intrinsic_path = cam_intrinsic_path
        self.training = training
        self.param = param

    def __getitem__(self, index):
        left1 = self.left1[index]
        right1 = self.right1[index]
        left2 = self.left2[index]
        right2 = self.right2[index]
        cam_intrinsic_path = self.cam_intrinsic_path[index]
        param = self.param
        left_image_1 = Image.open(left1).convert('RGB')
        right_image_1 = Image.open(right1).convert('RGB')
        left_image_2 = Image.open(left2).convert('RGB')
        right_image_2 = Image.open(right2).convert('RGB')
        W, H = left_image_1.size
        width_ratio = W / 1226.0
        height_ratio = H / 370.0

        raw_cam_mat = read_cam(cam_intrinsic_path)
        raw_cam_mat[0, 0] = raw_cam_mat[0, 0] * width_ratio
        raw_cam_mat[0, 2] = raw_cam_mat[0, 2] * width_ratio
        raw_cam_mat[1, 1] = raw_cam_mat[1, 1] * height_ratio
        raw_cam_mat[1, 2] = raw_cam_mat[1, 2] * height_ratio

        resize0 = Resize0()
        left_image_1 = resize0(left_image_1)
        left_image_2 = resize0(left_image_2)

        # augmentation
        if self.training:
            left_image_1, left_image_2, left_image_std_1, left_image_std_2, right_image_std_1, right_image_std_2, raw_cam_mat, x1, y1 = \
                data_agumentation_df(left_image_1, left_image_2, right_image_1, right_image_2, param)

        # transforms
        process = get_transform(param)
        left_image_1 = process(left_image_1)
        left_image_std_1 = process(left_image_std_1)
        right_image_std_1 = process(right_image_std_1)
        left_image_2 = process(left_image_2)
        left_image_std_2 = process(left_image_std_2)
        right_image_std_2 = process(right_image_std_2)
        fx = raw_cam_mat[0,0]
        K_inv = np.linalg.inv(raw_cam_mat)

        return left_image_1, left_image_2, left_image_std_1, left_image_std_2, right_image_std_1, right_image_std_2, \
               fx, raw_cam_mat,K_inv,x1, y1  # , right_image_1, right_image_2

    def __len__(self):
        return len(self.left1)
    
# class myImageFolder(data.Dataset):
#     def __init__(self, left, right, flow, param):
#         self.right = right
#         self.left = left
#         self.flow = flow
#         self.param = param
#
#     def __getitem__(self, index):
#         left = self.left[index]
#         right = self.right[index]
#         param = self.param
#         left_image = Image.open(left).convert('RGB')
#         right_image = Image.open(right).convert('RGB')
#
#         process = get_transform_test(param)
#         left_image = process(left_image)
#         right_image = process(right_image)
#
#         if self.flow is not None:
#             flow = self.flow[index]
#             flow_image = cv2.imread(flow, -1)
#             h, w, _ = flow_image.shape
#             flo_img = flow_image[:,:,2:0:-1].astype(np.float32)
#             invalid = (flow_image[:,:,0] == 0)
#
#             flo_img = (flo_img - 32768) / 64
#             flo_img[np.abs(flo_img) < 1e-10] = 1e-10
#             flo_img[invalid, :] = 0
#
#             f = torch.from_numpy(flo_img.transpose((2,0,1)))
#             mask = torch.from_numpy((flow_image[:,:,0] == 1).astype(np.float32)).type(torch.FloatTensor)
#
#             return left_image, right_image, f.type(torch.FloatTensor), mask, h, w
#
#         return left_image, right_image
#
#     def __len__(self):
#         return len(self.left)

class myImageFolder(data.Dataset):
    def __init__(self, left, right, flow, param):
        self.right = right
        self.left = left
        self.flow = flow
        self.param = param

    def __getitem__(self, index):
        left = self.left[index]
        right = self.right[index]
        param = self.param
        left_image = Image.open(left).convert('RGB')
        right_image = Image.open(right).convert('RGB')

        process = get_transform_test(param)
        left_image = process(left_image)
        right_image = process(right_image)

        if self.flow is not None:
            flow = self.flow[index]
            flow_image = cv2.imread(flow, -1)
            h, w, _ = flow_image.shape
            flo_img = flow_image[:, :, 2:0:-1].astype(np.float32)
            invalid = (flow_image[:, :, 0] == 0)

            flo_img = (flo_img - 32768) / 64
            flo_img[np.abs(flo_img) < 1e-10] = 1e-10
            flo_img[invalid, :] = 0

            f = torch.from_numpy(flo_img.transpose((2, 0, 1)))
            mask = torch.from_numpy((flow_image[:, :, 0] == 1).astype(np.float32)).type(torch.FloatTensor)

            return left_image, right_image, f.type(torch.FloatTensor), mask, h, w

        return left_image, right_image

    def __len__(self):
        return len(self.left)
    

class myImageFolder_test(data.Dataset):
    def __init__(self, left_image_test_1, left_image_test_2,
                 flow_noc, flow_occ, param):
        self.left_image_test_1 = left_image_test_1

        self.left_image_test_2 = left_image_test_2

        self.flow_noc = flow_noc
        self.flow_occ = flow_occ

        self.param = param

    def __getitem__(self, index):
        left_image_test_1 = self.left_image_test_1[index]

        left_image_test_2 = self.left_image_test_2[index]

        flow_noc = self.flow_noc[index]
        flow_occ = self.flow_occ[index]

        param = self.param

        left_image_test_1 = Image.open(left_image_test_1).convert('RGB')
        left_image_test_2 = Image.open(left_image_test_2).convert('RGB')
        W, H = left_image_test_1.size

        process = get_transform_test(param)
        left_image_test_1 = process(left_image_test_1)

        left_image_test_2 = process(left_image_test_2)

        if self.flow_noc is not None:
            ########################load flow_noc
            flow_noc = self.flow_noc[index]
            flow_image_noc = cv2.imread(flow_noc, -1)
            h, w, _ = flow_image_noc.shape
            flo_img_noc = flow_image_noc[:, :, 2:0:-1].astype(np.float32)
            invalid_noc = (flow_image_noc[:, :, 0] == 0)
            flo_img_noc = (flo_img_noc - 32768) / 64
            flo_img_noc[np.abs(flo_img_noc) < 1e-10] = 1e-10
            flo_img_noc[invalid_noc, :] = 0

            f_noc = torch.from_numpy(flo_img_noc.transpose((2, 0, 1)))
            mask_noc = torch.from_numpy((flow_image_noc[:, :, 0] == 1).astype(np.float32)).type(torch.FloatTensor)
            ########################load flow_occ
            flow_occ = self.flow_occ[index]
            flow_image_occ = cv2.imread(flow_occ, -1)
            flo_img_occ = flow_image_occ[:, :, 2:0:-1].astype(np.float32)
            invalid_occ = (flow_image_occ[:, :, 0] == 0)
            flo_img_occ = (flo_img_occ - 32768) / 64
            # flo_img = flow_image_noc.astype(np.float32) / 256
            flo_img_occ[np.abs(flo_img_occ) < 1e-10] = 1e-10
            flo_img_occ[invalid_occ, :] = 0

            f_occ = torch.from_numpy(flo_img_occ.transpose((2, 0, 1)))
            mask_occ = torch.from_numpy((flow_image_occ[:, :, 0] == 1).astype(np.float32)).type(torch.FloatTensor)


            return left_image_test_1, left_image_test_2, \
                   f_noc.type(torch.FloatTensor), mask_noc, f_occ.type(
                torch.FloatTensor), mask_occ, h, w  # , K_yuan

        return left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2

    def __len__(self):
        return len(self.left_image_test_1)


class myImageFolder_flow(data.Dataset):
    def __init__(self, left_image_test_1, left_image_test_2, flow_noc, flow_occ, param):
        self.left_image_test_1 = left_image_test_1
        self.left_image_test_2 = left_image_test_2
        self.flow_noc = flow_noc
        self.flow_occ = flow_occ

        self.param = param

    def __getitem__(self, index):
        left_image_test_1 = self.left_image_test_1[index]
        left_image_test_2 = self.left_image_test_2[index]


        param = self.param

        left_image_test_1 = Image.open(left_image_test_1).convert('RGB')
        left_image_test_2 = Image.open(left_image_test_2).convert('RGB')
        W, H = left_image_test_1.size

        process = get_transform_test(param)
        left_image_test_1 = process(left_image_test_1)
        left_image_test_2 = process(left_image_test_2)

        if self.flow_noc is not None:
            ########################load flow_noc
            flow_noc = self.flow_noc[index]
            flow_image_noc = cv2.imread(flow_noc, -1)
            h, w, _ = flow_image_noc.shape
            flo_img_noc = flow_image_noc[:, :, 2:0:-1].astype(np.float32)
            invalid_noc = (flow_image_noc[:, :, 0] == 0)
            flo_img_noc = (flo_img_noc - 32768) / 64
            flo_img_noc[np.abs(flo_img_noc) < 1e-10] = 1e-10
            flo_img_noc[invalid_noc, :] = 0

            f_noc = torch.from_numpy(flo_img_noc.transpose((2, 0, 1)))
            mask_noc = torch.from_numpy((flow_image_noc[:, :, 0] == 1).astype(np.float32)).type(torch.FloatTensor)
            ########################load flow_occ
            flow_occ = self.flow_occ[index]
            flow_image_occ = cv2.imread(flow_occ, -1)
            flo_img_occ = flow_image_occ[:, :, 2:0:-1].astype(np.float32)
            invalid_occ = (flow_image_occ[:, :, 0] == 0)
            flo_img_occ = (flo_img_occ - 32768) / 64
            # flo_img = flow_image_noc.astype(np.float32) / 256
            flo_img_occ[np.abs(flo_img_occ) < 1e-10] = 1e-10
            flo_img_occ[invalid_occ, :] = 0

            f_occ = torch.from_numpy(flo_img_occ.transpose((2, 0, 1)))
            mask_occ = torch.from_numpy((flow_image_occ[:, :, 0] == 1).astype(np.float32)).type(torch.FloatTensor)


            return left_image_test_1, left_image_test_2, \
                   f_noc.type(torch.FloatTensor), f_occ.type(torch.FloatTensor), mask_noc, mask_occ, h, w  # , K_yuan

        return left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2

    def __len__(self):
        return len(self.left_image_test_1)