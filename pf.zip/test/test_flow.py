import torch
import torchvision
import os
import torchvision.transforms as transforms
import torch.utils.data as data
import numpy as np
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse
import random
from PIL import Image
import matplotlib.pyplot as plt
import cv2
from models.MonodepthModel import *
from models.PWC_net import *
from models.PWC_net import PWCDCNet
from utils.scene_dataloader import *
from utils.utils import *
import copy

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

def get_args():
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--model_name',                type=str,   help='model name', default='monodepth')
    # parser.add_argument('--data_path',                 type=str,   help='path to the data', required=True)
    parser.add_argument('--load_2012_kitti_data_path',                 type=str,   help='path to the data', default="/home/cc/dataset/KITTI/kitti_2012_flow/")
    parser.add_argument('--load_2015_kitti_data_path',                 type=str,   help='path to the data', default="/home/cc/dataset/KITTI/kitti_2015_flow/")
    parser.add_argument('--load_2012_noc_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/kitti_flow_val_files_194_2012.txt")
    parser.add_argument('--load_2012_occ_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/kitti_flow_val_files_occ_194_2012.txt")
    parser.add_argument('--load_2015_noc_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/kitti_flow_val_files_200.txt")
    parser.add_argument('--load_2015_occ_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/kitti_flow_val_files_occ_200.txt")
    parser.add_argument('--input_height',              type=int,   help='input height', default=320)
    parser.add_argument('--input_width',               type=int,   help='input width', default=896)
    parser.add_argument('--checkpoint_path',           type=str,   help='path to a specific checkpoint to load', required=True)
    parser.add_argument('--result_path',           type=str,   help='path to a save result', required=True)
    parser.add_argument('--model_name_path',           type=str,   help='path to a save result', default="/home/cc/hty/models/rr/a.txt")
    parser.add_argument('--test_together',           type=int,   help='path to a save result', default=0)
    args = parser.parse_args()
    return args

args = get_args()
test_kitti_2012 = True
test_kitti_2015 = True
test_noc = True
test_all = True
save_dir = args.result_path + "test.txt"
print(save_dir)
test_together = args.test_together
print(test_together)

if test_together == False:
    checkpoint = torch.load(args.checkpoint_path)
    if args.model_name == 'monodepth':
        net = MonodepthNet().cuda()
    elif args.model_name == 'pwc':
        net = pwc_dc_net().cuda()
        args.input_width = 896
    net.load_state_dict(checkpoint['state_dict'])
    epoch_cur = checkpoint['epoch']
    print(epoch_cur)
    f2 = open(save_dir,'a+')
    f2.write("The model is : "+args.checkpoint_path+ "\n")

    if test_kitti_2015:
        if test_noc:
            former_test, latter_test, flow = get_flow_data(args.load_2015_noc_filenames_file, args.load_2015_kitti_data_path)
            TestFlowLoader = torch.utils.data.DataLoader(
                    myImageFolder(former_test, latter_test, flow, args),
                    batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

            total_error = 0
            fl_error = 0
            num_test = 0
            for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                
                # left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                # right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                
                # left = Variable(left_batch.cuda())
                # right = Variable(right_batch.cuda())
                # model_input = torch.cat((left, right), 1)
                # if args.model_name == 'monodepth':
                #     disp_est_scale, disp_est = net(model_input)
                # elif args.model_name == 'pwc':
                #     disp_est_scale = net(model_input)
                left = Variable(left.cuda())
                right = Variable(right.cuda())
                # print (left.shape)


                left_batch_ = torch.cat((left[:,:,0 : 320,0:896], left[:,:,0 : 320,int(w)-896:int(w)],left[:,:,int(h)-320:int(h),0:896],left[:,:,int(h)-320:int(h),int(w)-896:int(w)],left[:,:,int(h)-320:int(h),int(w)-896:int(w)]), 0)
                right_batch_ = torch.cat((right[:,:,0 : 320,0:896], right[:,:,0 : 320,int(w)-896:int(w)],right[:,:,int(h)-320:int(h),0:896],right[:,:,int(h)-320:int(h),int(w)-896:int(w)],left[:,:,int(h)-320:int(h),int(w)-896:int(w)]), 0)
                # print (left_batch_.size())


                model_input0 = torch.cat((left_batch_, right_batch_), 1)
                # print (model_input0.size())

                # left_batch_ = torch.cat((left[:,:,0 : 320,0:896], left[:,:,0 : 320,int(w)-896:int(w)],left[:,:,int(h)-320:int(h),0:896],left[:,:,int(h)-320:int(h),int(w)-896:int(w)]), 0)
                # print (left_batch_.size())
                if args.model_name == 'monodepth':
                    disp_est_scale0, disp_est0 = net(model_input0)
                elif args.model_name == 'pwc':
                    disp_est_scale0 = net(model_input0)

                # model_input1 = torch.cat((left[:,:,0 : 320,int(w)-896:int(w)], right[:,:,0 : 320,int(w)-896:int(w)]), 1)
                # if args.model_name == 'monodepth':
                #     disp_est_scale0, disp_est0 = net(model_input1)
                # elif args.model_name == 'pwc':
                #     disp_est_scale1 = net(model_input1)

                # model_input2 = torch.cat((left[:,:,int(h)-320:int(h),0:896], right[:,:,int(h)-320:int(h),0:896]), 1)
                # if args.model_name == 'monodepth':
                #     disp_est_scale0, disp_est0 = net(model_input2)
                # elif args.model_name == 'pwc':
                #     disp_est_scale2 = net(model_input2)

                # model_input3 = torch.cat((left[:,:,int(h)-320:int(h),int(w)-896:int(w)], right[:,:,int(h)-320:int(h),int(w)-896:int(w)]), 1)
                # if args.model_name == 'monodepth':
                #     disp_est_scale0, disp_est0 = net(model_input3)
                # elif args.model_name == 'pwc':
                #     disp_est_scale3 = net(model_input3)

                # model_input4 = torch.cat((left[:,:,int(h)-320:int(h),int(w)-896:int(w)], right[:,:,int(h)-320:int(h),int(w)-896:int(w)]), 1)
                # if args.model_name == 'monodepth':
                #     disp_est_scale0, disp_est0 = net(model_input4)
                # elif args.model_name == 'pwc':
                #     disp_est_scale4 = net(model_input4)
                print(disp_est_scale0[0].shape)
                print(disp_est_scale0[1].shape)
                disp_est_scale = disp_est_scale0[0][4:5].clone()

                disp_est_scale = F.interpolate(disp_est_scale * 0, [int(h), int(w)], mode='bilinear',align_corners=True)
                W_2 = int(int(w)/2)
                H_2 = int(int(h)/2)
                # print(W_2)
                # print(H_2)
                W_2_ = int(w)-W_2
                H_2_ = int(h)-H_2
                disp_est_scale[:,:,0 : H_2,0:W_2] = disp_est_scale0[0][:1][:,:, 0 : H_2, 0:W_2]
                disp_est_scale[:,:,0 : H_2,W_2:int(w)] = disp_est_scale0[0][1:2][:,:, 0 : H_2, (896-W_2_):896]
                disp_est_scale[:,:,H_2 : int(h),0:W_2] = disp_est_scale0[0][2:3][:,:, (320-H_2_) :320, 0:W_2]
                disp_est_scale[:,:,H_2 : int(h),W_2:int(w)] = disp_est_scale0[0][3:4][:,:, (320-H_2_) :320, (896-W_2_):896]



                mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                # Mat a = disp_est_scale[0][:1]
                # disp_ori_scale = cv2.resize(
                #     a, (int(w), int(h)), interpolation=cv2.INTER_LINEAR)align_corners=True
                # print(int(w),int(h))
                # disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear',align_corners=True)
                disp_ori_scale = disp_est_scale
                disp_ori_scale[0,0] = disp_ori_scale[0,0] * float(int(w)) / float(args.input_width)
                disp_ori_scale[0,1] = disp_ori_scale[0,1] * float(int(h)) / float(args.input_height)

                error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                total_error += error
                fl_error += fl
                num_test += 1
                
            total_error /= num_test
            fl_error /= num_test
            print("The 2015 noc average EPE is : ", total_error)
            print("The average Fl is : ", fl_error)
            f2.write("The 2015 noc average EPE is : "+str(total_error)+ "\n")
            f2.write("The average Fl is : "+str(fl_error)+ "\n")

        if test_all:
            former_test, latter_test, flow = get_flow_data(args.load_2015_occ_filenames_file, args.load_2015_kitti_data_path)
            TestFlowLoader = torch.utils.data.DataLoader(
                    myImageFolder(former_test, latter_test, flow, args),
                    batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

            total_error = 0
            fl_error = 0
            num_test = 0
            for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                
                left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                # left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                # right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                
                left = Variable(left_batch.cuda())
                right = Variable(right_batch.cuda())

                model_input = torch.cat((left, right), 1)
                if args.model_name == 'monodepth':
                    disp_est_scale, disp_est = net(model_input)
                elif args.model_name == 'pwc':
                    disp_est_scale = net(model_input)

                mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                total_error += error
                fl_error += fl
                num_test += 1
                
            total_error /= num_test
            fl_error /= num_test
            print("The 2015 all average EPE is : ", total_error)
            print("The average Fl is : ", fl_error)
            f2.write("The 2015 all average EPE is : "+str(total_error)+ "\n")
            f2.write("The average Fl is : "+str(fl_error)+ "\n")



    if test_kitti_2012:
        if test_noc:
            former_test, latter_test, flow = get_flow_data(args.load_2012_noc_filenames_file, args.load_2012_kitti_data_path)
            TestFlowLoader = torch.utils.data.DataLoader(
                    myImageFolder(former_test, latter_test, flow, args),
                    batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

            total_error = 0
            fl_error = 0
            num_test = 0
            for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                
                left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                
                left = Variable(left_batch.cuda())
                right = Variable(right_batch.cuda())

                model_input = torch.cat((left, right), 1)
                if args.model_name == 'monodepth':
                    disp_est_scale, disp_est = net(model_input)
                elif args.model_name == 'pwc':
                    disp_est_scale = net(model_input)

                mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                total_error += error
                fl_error += fl
                num_test += 1
                
            total_error /= num_test
            fl_error /= num_test
            print("The 2012 noc average EPE is : ", total_error)
            print("The average Fl is : ", fl_error)
            f2.write("The 2012 noc average EPE is : "+str(total_error)+ "\n")
            f2.write("The average Fl is : "+str(fl_error)+ "\n")

        if test_all:
            former_test, latter_test, flow = get_flow_data(args.load_2012_occ_filenames_file, args.load_2012_kitti_data_path)
            TestFlowLoader = torch.utils.data.DataLoader(
                    myImageFolder(former_test, latter_test, flow, args),
                    batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

            total_error = 0
            fl_error = 0
            num_test = 0
            for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                
                left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                
                left = Variable(left_batch.cuda())
                right = Variable(right_batch.cuda())

                model_input = torch.cat((left, right), 1)
                if args.model_name == 'monodepth':
                    disp_est_scale, disp_est = net(model_input)
                elif args.model_name == 'pwc':
                    disp_est_scale = net(model_input)

                mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                total_error += error
                fl_error += fl
                num_test += 1
                
            total_error /= num_test
            fl_error /= num_test
            print("The 2012 all average EPE is : ", total_error)
            print("The average Fl is : ", fl_error)
            f2.write("The 2012 all average EPE is : "+str(total_error)+ "\n")
            f2.write("The average Fl is : "+str(fl_error)+ "\n"+ "\n")
#######################################################################################################################################






#####################################################################################################################
if test_together == True:
    with open(args.model_name_path,'r') as f:
        content = [line.rstrip('\n') for line in f]
        for i in content:
            print(args.result_path + str(i))
            model_path = args.result_path + str(i)
        
            checkpoint = torch.load(model_path)
            if args.model_name == 'monodepth':
                net = MonodepthNet().cuda()
            elif args.model_name == 'pwc':
                net = pwc_dc_net().cuda()
                args.input_width = 832
            net.load_state_dict(checkpoint['state_dict'])
            epoch_cur = checkpoint['epoch']
            print(epoch_cur)
            f2 = open(save_dir,'a+')
            f2.write("The model is : "+model_path+ "\n")

            if test_kitti_2015:
                if test_noc:
                    former_test, latter_test, flow = get_flow_data(args.load_2015_noc_filenames_file, args.load_2015_kitti_data_path)
                    TestFlowLoader = torch.utils.data.DataLoader(
                            myImageFolder(former_test, latter_test, flow, args),
                            batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

                    total_error = 0
                    fl_error = 0
                    num_test = 0
                    for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                        
                        left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                        right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                        
                        left = Variable(left_batch.cuda())
                        right = Variable(right_batch.cuda())

                        model_input = torch.cat((left, right), 1)
                        if args.model_name == 'monodepth':
                            disp_est_scale, disp_est = net(model_input)
                        elif args.model_name == 'pwc':
                            disp_est_scale = net(model_input)

                        mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                        # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                        disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                        disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                        disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                        error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                        total_error += error
                        fl_error += fl
                        num_test += 1
                        
                    total_error /= num_test
                    fl_error /= num_test
                    print("The 2015 noc average EPE is : ", total_error)
                    print("The average Fl is : ", fl_error)
                    f2.write("The 2015 noc average EPE is : "+str(total_error)+ "\n")
                    f2.write("The average Fl is : "+str(fl_error)+ "\n")

                if test_all:
                    former_test, latter_test, flow = get_flow_data(args.load_2015_occ_filenames_file, args.load_2015_kitti_data_path)
                    TestFlowLoader = torch.utils.data.DataLoader(
                            myImageFolder(former_test, latter_test, flow, args),
                            batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

                    total_error = 0
                    fl_error = 0
                    num_test = 0
                    for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                        
                        left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                        right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                        
                        left = Variable(left_batch.cuda())
                        right = Variable(right_batch.cuda())

                        model_input = torch.cat((left, right), 1)
                        if args.model_name == 'monodepth':
                            disp_est_scale, disp_est = net(model_input)
                        elif args.model_name == 'pwc':
                            disp_est_scale = net(model_input)

                        mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                        # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                        disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                        disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                        disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                        error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                        total_error += error
                        fl_error += fl
                        num_test += 1
                        
                    total_error /= num_test
                    fl_error /= num_test
                    print("The 2015 all average EPE is : ", total_error)
                    print("The average Fl is : ", fl_error)
                    f2.write("The 2015 all average EPE is : "+str(total_error)+ "\n")
                    f2.write("The average Fl is : "+str(fl_error)+ "\n")



            if test_kitti_2012:
                if test_noc:
                    former_test, latter_test, flow = get_flow_data(args.load_2012_noc_filenames_file, args.load_2012_kitti_data_path)
                    TestFlowLoader = torch.utils.data.DataLoader(
                            myImageFolder(former_test, latter_test, flow, args),
                            batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

                    total_error = 0
                    fl_error = 0
                    num_test = 0
                    for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                        
                        left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                        right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                        
                        left = Variable(left_batch.cuda())
                        right = Variable(right_batch.cuda())

                        model_input = torch.cat((left, right), 1)
                        if args.model_name == 'monodepth':
                            disp_est_scale, disp_est = net(model_input)
                        elif args.model_name == 'pwc':
                            disp_est_scale = net(model_input)

                        mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                        # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                        disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                        disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                        disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                        error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                        total_error += error
                        fl_error += fl
                        num_test += 1
                        
                    total_error /= num_test
                    fl_error /= num_test
                    print("The 2012 noc average EPE is : ", total_error)
                    print("The average Fl is : ", fl_error)
                    f2.write("The 2012 noc average EPE is : "+str(total_error)+ "\n")
                    f2.write("The average Fl is : "+str(fl_error)+ "\n")

                if test_all:
                    former_test, latter_test, flow = get_flow_data(args.load_2012_occ_filenames_file, args.load_2012_kitti_data_path)
                    TestFlowLoader = torch.utils.data.DataLoader(
                            myImageFolder(former_test, latter_test, flow, args),
                            batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

                    total_error = 0
                    fl_error = 0
                    num_test = 0
                    for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                        
                        left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                        right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                        
                        left = Variable(left_batch.cuda())
                        right = Variable(right_batch.cuda())

                        model_input = torch.cat((left, right), 1)
                        if args.model_name == 'monodepth':
                            disp_est_scale, disp_est = net(model_input)
                        elif args.model_name == 'pwc':
                            disp_est_scale = net(model_input)

                        mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                        # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                        disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                        disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                        disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                        error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                        total_error += error
                        fl_error += fl
                        num_test += 1
                        
                    total_error /= num_test
                    fl_error /= num_test
                    print("The 2012 all average EPE is : ", total_error)
                    print("The average Fl is : ", fl_error)
                    f2.write("The 2012 all average EPE is : "+str(total_error)+ "\n")
                    f2.write("The average Fl is : "+str(fl_error)+ "\n"+ "\n")