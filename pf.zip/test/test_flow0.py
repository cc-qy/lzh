import torch
import torchvision
import os
import torchvision.transforms as transforms
import torch.utils.data as data
import numpy as np
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse
import random
from PIL import Image
import matplotlib.pyplot as plt
import cv2
from models.MonodepthModel import *
from models.PWC_net import *
from models.PWC_net import PWCDCNet
from utils.scene_dataloader import *
from utils.utils import *
import warnings
warnings.filterwarnings("ignore")

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

def get_args():
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--model_name',                type=str,   help='model name', default='monodepth')
    parser.add_argument('--data_path',                 type=str,   help='path to the data', required=True)
    parser.add_argument('--load_2012_kitti_data_path',                 type=str,   help='path to the data', default="/home/cc/dataset/KITTI/kitti_2012_flow/")
    parser.add_argument('--load_2015_kitti_data_path',                 type=str,   help='path to the data', default="/home/cc/dataset/KITTI/kitti_2015_flow/")
    parser.add_argument('--load_2012_noc_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/kitti_flow_val_files_194_2012.txt")
    parser.add_argument('--load_2012_occ_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/kitti_flow_val_files_occ_194_2012.txt")
    parser.add_argument('--load_2015_noc_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/kitti_flow_val_files_200.txt")
    parser.add_argument('--load_2015_occ_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/kitti_flow_val_files_occ_200.txt")
    parser.add_argument('--input_height',              type=int,   help='input height', default=320)
    parser.add_argument('--input_width',               type=int,   help='input width', default=896)
    parser.add_argument('--checkpoint_path',           type=str,   help='path to a specific checkpoint to load', required=True)
    parser.add_argument('--result_path',           type=str,   help='path to a save result', required=True)
    parser.add_argument('--model_name_path',           type=str,   help='path to a save result', default="/home/hty/cc/model-pytorch0/a.txt")
    parser.add_argument('--test_together',           type=int,   help='path to a save result', default=0)
    args = parser.parse_args()
    return args

args = get_args()
test_kitti_2012 = True
test_kitti_2015 = True
test_noc = True
test_all = True
save_dir = args.result_path + "test.txt"
print(save_dir)
test_together = args.test_together
print(test_together)

def convertOptRGB(optical_flow):
    ####
    # 超时空这里的 0 1 即 x,y 方向上的维度反了
    ####

    blob_x = optical_flow[1]
    blob_y = optical_flow[0]

    hsv = np.zeros((blob_x.shape[0], blob_y.shape[1], 3), np.uint8)
    mag, ang = cv2.cartToPolar(blob_x, blob_y)
    hsv[..., 0] = ang * 180 / np.pi / 2
    hsv[..., 1] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)
    hsv[..., 2] = 255
    bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

    result = np.zeros((blob_x.shape[0], blob_x.shape[1], 3), np.uint8)
    result[:, :, 0] = bgr[:, :, 2]
    result[:, :, 1] = bgr[:, :, 1]
    result[:, :, 2] = bgr[:, :, 0]

    return result

image_path_2015 = '/home/cc/ww/model/vis_flow_2015/'
image_path_2012 = '/home/cc/ww/model/vis_flow_2012/'

if test_together == False:
    checkpoint = torch.load(args.checkpoint_path)
    if args.model_name == 'monodepth':
        net = MonodepthNet().cuda()
    elif args.model_name == 'pwc':
        net = pwc_dc_net().cuda()
        # args.input_width = 832
    net.load_state_dict(checkpoint['state_dict'])
    epoch_cur = checkpoint['epoch']
    print(epoch_cur)
    f2 = open(save_dir,'a+')
    f2.write("The model is : "+args.checkpoint_path+ "\n")

    if test_kitti_2015:
        if test_noc:
            former_test, latter_test, flow = get_flow_data(args.load_2015_noc_filenames_file, args.load_2015_kitti_data_path)
            TestFlowLoader = torch.utils.data.DataLoader(
                    myImageFolder(former_test, latter_test, flow, args),
                    batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

            total_error = 0
            fl_error = 0
            num_test = 0
            for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                
                left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                
                left = Variable(left_batch.cuda())
                right = Variable(right_batch.cuda())

                model_input = torch.cat((left, right), 1)
                if args.model_name == 'monodepth':
                    disp_est_scale, disp_est = net(model_input)
                elif args.model_name == 'pwc':
                    disp_est_scale = net(model_input)

                mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                total_error += error
                fl_error += fl
                num_test += 1
                
            total_error /= num_test
            fl_error /= num_test
            print("The 2015 noc average EPE is : ", total_error)
            print("The average Fl is : ", fl_error)
            f2.write("The 2015 noc average EPE is : "+str(total_error)+ "\n")
            f2.write("The average Fl is : "+str(fl_error)+ "\n")

        if test_all:
            former_test, latter_test, flow = get_flow_data(args.load_2015_occ_filenames_file, args.load_2015_kitti_data_path)
            TestFlowLoader = torch.utils.data.DataLoader(
                    myImageFolder(former_test, latter_test, flow, args),
                    batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

            total_error = 0
            fl_error = 0
            num_test = 0
            for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                
                left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                
                left = Variable(left_batch.cuda())
                right = Variable(right_batch.cuda())

                model_input = torch.cat((left, right), 1)
                if args.model_name == 'monodepth':
                    disp_est_scale, disp_est = net(model_input)
                elif args.model_name == 'pwc':
                    disp_est_scale = net(model_input)

                mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                ########### vis flow
                # image_ = (disp_ori_scale[0].cpu() - gt[0]) * mask
                # image = image_.data.numpy()
                # flow_image = convertOptRGB(image)
                # # print("image--size",image.shape)
                # # print("flow_image--size",flow_image.shape)
                # cv2.imwrite(image_path_2015 + "{}".format(batch_idx).zfill(6) + '.png', flow_image)
                ###############3333

                error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                total_error += error
                fl_error += fl
                num_test += 1
                
            total_error /= num_test
            fl_error /= num_test
            print("The 2015 all average EPE is : ", total_error)
            print("The average Fl is : ", fl_error)
            f2.write("The 2015 all average EPE is : "+str(total_error)+ "\n")
            f2.write("The average Fl is : "+str(fl_error)+ "\n")



    if test_kitti_2012:
        if test_noc:
            former_test, latter_test, flow = get_flow_data(args.load_2012_noc_filenames_file, args.load_2012_kitti_data_path)
            TestFlowLoader = torch.utils.data.DataLoader(
                    myImageFolder(former_test, latter_test, flow, args),
                    batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

            total_error = 0
            fl_error = 0
            num_test = 0
            for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                
                left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                
                left = Variable(left_batch.cuda())
                right = Variable(right_batch.cuda())

                model_input = torch.cat((left, right), 1)
                if args.model_name == 'monodepth':
                    disp_est_scale, disp_est = net(model_input)
                elif args.model_name == 'pwc':
                    disp_est_scale = net(model_input)

                mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                total_error += error
                fl_error += fl
                num_test += 1
                
            total_error /= num_test
            fl_error /= num_test
            print("The 2012 noc average EPE is : ", total_error)
            print("The average Fl is : ", fl_error)
            f2.write("The 2012 noc average EPE is : "+str(total_error)+ "\n")
            f2.write("The average Fl is : "+str(fl_error)+ "\n")

        if test_all:
            former_test, latter_test, flow = get_flow_data(args.load_2012_occ_filenames_file, args.load_2012_kitti_data_path)
            TestFlowLoader = torch.utils.data.DataLoader(
                    myImageFolder(former_test, latter_test, flow, args),
                    batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

            total_error = 0
            fl_error = 0
            num_test = 0
            for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                
                left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                
                left = Variable(left_batch.cuda())
                right = Variable(right_batch.cuda())

                model_input = torch.cat((left, right), 1)
                if args.model_name == 'monodepth':
                    disp_est_scale, disp_est = net(model_input)
                elif args.model_name == 'pwc':
                    disp_est_scale = net(model_input)

                mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                ########### vis flow
                # image_ = (disp_ori_scale[0].cpu() - gt[0]) * mask
                # image = image_.data.numpy()
                # flow_image = convertOptRGB(image)
                # # print("image--size",image.shape)
                # # print("flow_image--size",flow_image.shape)
                # cv2.imwrite(image_path_2012 + "{}".format(batch_idx).zfill(6) + '.png', flow_image)
                ###############3333

                error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                total_error += error
                fl_error += fl
                num_test += 1
                
            total_error /= num_test
            fl_error /= num_test
            print("The 2012 all average EPE is : ", total_error)
            print("The average Fl is : ", fl_error)
            f2.write("The 2012 all average EPE is : "+str(total_error)+ "\n")
            f2.write("The average Fl is : "+str(fl_error)+ "\n"+ "\n")

if test_together == True:
    with open(args.model_name_path,'r') as f:
        content = [line.rstrip('\n') for line in f]
        for i in content:
            print(args.result_path + str(i))
            model_path = args.result_path + str(i)
        
            checkpoint = torch.load(model_path)
            if args.model_name == 'monodepth':
                net = MonodepthNet().cuda()
            elif args.model_name == 'pwc':
                net = pwc_dc_net().cuda()
                args.input_width = 832
            net.load_state_dict(checkpoint['state_dict'])
            epoch_cur = checkpoint['epoch']
            print(epoch_cur)
            f2 = open(save_dir,'a+')
            f2.write("The model is : "+model_path+ "\n")

            if test_kitti_2015:
                if test_noc:
                    former_test, latter_test, flow = get_flow_data(args.load_2015_noc_filenames_file, args.load_2015_kitti_data_path)
                    TestFlowLoader = torch.utils.data.DataLoader(
                            myImageFolder(former_test, latter_test, flow, args),
                            batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

                    total_error = 0
                    fl_error = 0
                    num_test = 0
                    for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                        
                        left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                        right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                        
                        left = Variable(left_batch.cuda())
                        right = Variable(right_batch.cuda())

                        model_input = torch.cat((left, right), 1)
                        if args.model_name == 'monodepth':
                            disp_est_scale, disp_est = net(model_input)
                        elif args.model_name == 'pwc':
                            disp_est_scale = net(model_input)

                        mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                        # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                        disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                        disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                        disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                        error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                        total_error += error
                        fl_error += fl
                        num_test += 1
                        
                    total_error /= num_test
                    fl_error /= num_test
                    print("The 2015 noc average EPE is : ", total_error)
                    print("The average Fl is : ", fl_error)
                    f2.write("The 2015 noc average EPE is : "+str(total_error)+ "\n")
                    f2.write("The average Fl is : "+str(fl_error)+ "\n")

                if test_all:
                    former_test, latter_test, flow = get_flow_data(args.load_2015_occ_filenames_file, args.load_2015_kitti_data_path)
                    TestFlowLoader = torch.utils.data.DataLoader(
                            myImageFolder(former_test, latter_test, flow, args),
                            batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

                    total_error = 0
                    fl_error = 0
                    num_test = 0
                    for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                        
                        left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                        right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                        
                        left = Variable(left_batch.cuda())
                        right = Variable(right_batch.cuda())

                        model_input = torch.cat((left, right), 1)
                        if args.model_name == 'monodepth':
                            disp_est_scale, disp_est = net(model_input)
                        elif args.model_name == 'pwc':
                            disp_est_scale = net(model_input)

                        mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                        # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                        disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                        disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                        disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                        error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                        total_error += error
                        fl_error += fl
                        num_test += 1
                        
                    total_error /= num_test
                    fl_error /= num_test
                    print("The 2015 all average EPE is : ", total_error)
                    print("The average Fl is : ", fl_error)
                    f2.write("The 2015 all average EPE is : "+str(total_error)+ "\n")
                    f2.write("The average Fl is : "+str(fl_error)+ "\n")



            if test_kitti_2012:
                if test_noc:
                    former_test, latter_test, flow = get_flow_data(args.load_2012_noc_filenames_file, args.load_2012_kitti_data_path)
                    TestFlowLoader = torch.utils.data.DataLoader(
                            myImageFolder(former_test, latter_test, flow, args),
                            batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

                    total_error = 0
                    fl_error = 0
                    num_test = 0
                    for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                        
                        left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                        right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                        
                        left = Variable(left_batch.cuda())
                        right = Variable(right_batch.cuda())

                        model_input = torch.cat((left, right), 1)
                        if args.model_name == 'monodepth':
                            disp_est_scale, disp_est = net(model_input)
                        elif args.model_name == 'pwc':
                            disp_est_scale = net(model_input)

                        mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                        # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                        disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                        disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                        disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                        error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                        total_error += error
                        fl_error += fl
                        num_test += 1
                        
                    total_error /= num_test
                    fl_error /= num_test
                    print("The 2012 noc average EPE is : ", total_error)
                    print("The average Fl is : ", fl_error)
                    f2.write("The 2012 noc average EPE is : "+str(total_error)+ "\n")
                    f2.write("The average Fl is : "+str(fl_error)+ "\n")

                if test_all:
                    former_test, latter_test, flow = get_flow_data(args.load_2012_occ_filenames_file, args.load_2012_kitti_data_path)
                    TestFlowLoader = torch.utils.data.DataLoader(
                            myImageFolder(former_test, latter_test, flow, args),
                            batch_size = 1, shuffle = False, num_workers = 1, drop_last = False)

                    total_error = 0
                    fl_error = 0
                    num_test = 0
                    for batch_idx, (left, right, gt, mask, h, w) in enumerate(TestFlowLoader, 0):
                        
                        left_batch = torch.cat((left, torch.from_numpy(np.flip(left.numpy(), 3).copy())), 0)
                        right_batch = torch.cat((right, torch.from_numpy(np.flip(right.numpy(), 3).copy())), 0)
                        
                        left = Variable(left_batch.cuda())
                        right = Variable(right_batch.cuda())

                        model_input = torch.cat((left, right), 1)
                        if args.model_name == 'monodepth':
                            disp_est_scale, disp_est = net(model_input)
                        elif args.model_name == 'pwc':
                            disp_est_scale = net(model_input)

                        mask = np.ceil(np.clip(np.abs(gt[0,0]), 0, 1))

                        # disp_ori_scale = nn.UpsamplingBilinear2d(size=(int(h), int(w)))(disp_est_scale[0][:1])
                        disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
                        disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
                        disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

                        error, fl = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), gt[0].numpy(), mask.numpy())
                        total_error += error
                        fl_error += fl
                        num_test += 1
                        
                    total_error /= num_test
                    fl_error /= num_test
                    print("The 2012 all average EPE is : ", total_error)
                    print("The average Fl is : ", fl_error)
                    f2.write("The 2012 all average EPE is : "+str(total_error)+ "\n")
                    f2.write("The average Fl is : "+str(fl_error)+ "\n"+ "\n")