python3 training.py \
--model_name='flow' \
--dataset='/mnt/nas/cc/EuRoC/' \
--file_name='/home/HTY_3_user/wqj/code/EuRoC/codes/pose_flow/utils/filenames/EuRoC_train_flow.txt' \
--pretrain_flag=0 \
--pretrain_model_path='/home/HTY_3_user/wy/model/pose_test/' \
--flow_model_path='/home/HTY_3_user/wy/model/pose_test/'