import torch
import torchvision
import torch.utils.data as data
import numpy as np
import os
import time
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse

from models.PWC_net import *
from models.PWC_net import PWCDCNet
from utils.scene_dataloader import *
from utils.utils import *

from tensorboardX import SummaryWriter

import warnings
warnings.filterwarnings("ignore")


## CUDA device
os.environ["CUDA_VISIBLE_DEVICES"] = "0"


def Subspace_PnP_depthflow_args():
    SubspacePnP_parser = argparse.ArgumentParser(description = 'Subspace PnP depth and flow pytorch')
    
    SubspacePnP_parser.add_argument(
    	'--model_name',           type=str,   help='model name', default='flow')
    SubspacePnP_parser.add_argument(
    	'--dataset_path',         type=str,   help='path to the train dataset', required=True)
    SubspacePnP_parser.add_argument(
    	'--file_name',            type=str,   help='path to the filenames text file', required=True)
    SubspacePnP_parser.add_argument(
    	'--input_height',         type=int,   help='input height', default=448)
    SubspacePnP_parser.add_argument(
    	'--input_width',          type=int,   help='input width', default=704)
    SubspacePnP_parser.add_argument(
    	'--batch_size',           type=int,   help='batch size', default=4)
    SubspacePnP_parser.add_argument(
    	'--num_epochs',           type=int,   help='number of epochs', default=80)
    SubspacePnP_parser.add_argument(
    	'--learning_rate',        type=float, help='initial learning rate', default=0.0001)
    SubspacePnP_parser.add_argument(
    	'--alpha_image_loss',     type=float, help='weight between SSIM and L1 loss', default=0.85)
    SubspacePnP_parser.add_argument(
    	'--disp_smooth_weight',   type=float, help='disparity smoothness weigth', default=0.1)
    SubspacePnP_parser.add_argument(
    	'--num_threads',          type=int,   help='number of threads to use for data loading', default=8)
    SubspacePnP_parser.add_argument(
        '--pretrain_flag',        type=int,   help='pretrain or not', default=0)
    SubspacePnP_parser.add_argument(
    	'--pretrain_model_path',  type=str,   help='path to a pretrained model to load', default='')
    SubspacePnP_parser.add_argument(
    	'--flow_model_path',      type=str,   help='pretrained flow model path to load', default='')



    SubspacePnP_args = SubspacePnP_parser.parse_args()
    return SubspacePnP_args

SP_args = Subspace_PnP_depthflow_args()


if SP_args.model_name == 'depth':
    net = MonodepthNet()
elif SP_args.model_name == 'flow':
    net_Tea = pwc_dc_net()


######  load pretrained model
if SP_args.pretrain_flag == 1:
    pre_Teaflow_model_pth = SP_args.pretrain_model_path

    if os.path.isfile(pre_Teaflow_model_pth):
        print("=> loading pretrained Tea_flow model path from:  '{}'".format(pre_Teaflow_model_pth))
        pre_checkpoint = torch.load(pre_Teaflow_model_pth)
        net_Tea.load_state_dict(pre_checkpoint['state_dict'])
        epoch_cur = pre_checkpoint['epoch'] + 1
        print("epoch_cur:  ", epoch_cur)
    else:
        print("=> no pretrained Tea_flow model found at '{}'".format(pre_Teaflow_model_pth))
else:
    epoch_cur = 0

net_Tea.cuda()


## tensorboard write
writer = SummaryWriter(log_dir = SP_args.flow_model_path + "/EuRoC_log/")
iterrat = len(open(SP_args.file_name, 'rU').readlines()) / SP_args.batch_size


##read image from data_path/filenames_file for training
# left_img_1, left_img_2, right_img_1, right_img_2 = get_depth_flow_data_pre(SP_args.file_name, SP_args.dataset_path)

## MultiView finetune
# left_img_1, left_img_2 = get_depth_flow_data_multiview_ft(SP_args.file_name, SP_args.dataset_path)

## EuRoC dataset
left_img_1, left_img_2 = get_depth_flow_data_multiview_ft(SP_args.file_name, SP_args.dataset_path)

##image augmentation
# SubspacePnP_CycleLoader = torch.utils.data.DataLoader(
#          PnP_CycleImageFolder_Pre(left_img_1, left_img_2, right_img_1, right_img_2, True, SP_args),
#          batch_size = SP_args.batch_size, shuffle = True, num_workers = SP_args.num_threads, drop_last = False)


## MultiView finetune   image augmentation
SubspacePnP_CycleLoader = torch.utils.data.DataLoader(
         PnP_CycleImageFolder_Multiview_ft(left_img_1, left_img_2, True, SP_args),
         batch_size = SP_args.batch_size, shuffle = True, num_workers = SP_args.num_threads, drop_last = False)


## Teacher flow
optimizer_Tea = optim.Adam(net_Tea.parameters(), lr = SP_args.learning_rate)

## for pretrain 
scheduler_Tea = optim.lr_scheduler.MultiStepLR(optimizer_Tea, milestones = [20, 30, 40, 50], gamma = 0.5)

## for census loss 
# scheduler_Tea = optim.lr_scheduler.MultiStepLR(optimizer_Tea, milestones = [60, 70], gamma = 0.5)

## for KITTI MultiView finetune
# scheduler_Tea = optim.lr_scheduler.MultiStepLR(optimizer_Tea, milestones = [90, 100, 110], gamma = 0.5)




scale_weight_loss = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]

for epoch in range(epoch_cur, SP_args.num_epochs):
    
    scheduler_Tea.step()

    ##  for pretrain
    # for batch_idx, (left_img_Tea_1, left_img_Tea_2, right_img_Tea_1, right_img_Tea_2) in enumerate(SubspacePnP_CycleLoader, 0):

    ## for KITTI MultiView finetune
    for batch_idx, (left_img_Tea_1, left_img_Tea_2) in enumerate(SubspacePnP_CycleLoader, 0):


        torch.cuda.synchronize()
        start_time = time.time()

        optimizer_Tea.zero_grad()

        num_scales = 5

        left_pyramid_1_Tea = make_pyramid(left_img_Tea_1, num_scales)
        left_pyramid_2_Tea = make_pyramid(left_img_Tea_2, num_scales)

        left_pyramid_1_Tea_gray = make_gray_pyramid(left_img_Tea_1, num_scales)
        left_pyramid_2_Tea_gray = make_gray_pyramid(left_img_Tea_2, num_scales)

        
        if SP_args.model_name == 'depth':
            print("no")
            
        elif SP_args.model_name == 'flow':
            input_flow_1to2_Tea = Variable(torch.cat((left_img_Tea_1, left_img_Tea_2),1).cuda())
            input_flow_2to1_Tea = Variable(torch.cat((left_img_Tea_2, left_img_Tea_1),1).cuda())

            flow_Tea_1to2 = net_Tea(input_flow_1to2_Tea)
            flow_Tea_2to1 = net_Tea(input_flow_2to1_Tea)

        
        ## mask calculate Teacher
        fw_mask_Tea = []
        bw_mask_Tea = []
        # border_mask = [1.0 - create_taowa_mask(left_pyramid_1_Tea[i], 0.15) for i in range(num_scales)]
        border_mask = [create_border_mask(left_pyramid_1_Tea[i], 0.1) for i in range(num_scales)]
        for i in range(num_scales):
            fw, bw, diff_fw, diff_bw = get_mask(flow_Tea_1to2[i], flow_Tea_2to1[i], None)
            fw += 1e-3
            bw += 1e-3
            fw_detached = fw.clone().detach()
            bw_detached = bw.clone().detach()
            fw_mask_Tea.append(fw_detached)
            bw_mask_Tea.append(bw_detached)

        img_loss_Tea_1 = pixel_loss(flow_Tea_1to2, left_pyramid_1_Tea, left_pyramid_2_Tea, fw_mask_Tea, scale_weight_loss, SP_args)
        img_loss_Tea_2 = pixel_loss(flow_Tea_2to1, left_pyramid_2_Tea, left_pyramid_1_Tea, bw_mask_Tea, scale_weight_loss, SP_args)
        smh_loss_Tea_1 = smooth_loss(flow_Tea_1to2, left_pyramid_1_Tea, scale_weight_loss)
        smh_loss_Tea_2 = smooth_loss(flow_Tea_2to1, left_pyramid_2_Tea, scale_weight_loss)

        ## Subapce_PnP_depethflow_04 add census_loss
        census_loss_Tea_1 = census_loss_1(flow_Tea_1to2, left_pyramid_1_Tea_gray, left_pyramid_2_Tea_gray, fw_mask_Tea, scale_weight_loss, SP_args)
        census_loss_Tea_2 = census_loss_1(flow_Tea_2to1, left_pyramid_2_Tea_gray, left_pyramid_1_Tea_gray, bw_mask_Tea, scale_weight_loss, SP_args)

        # loss_Tea = ((img_loss_Tea_1 + img_loss_Tea_2) + 10 * (smh_loss_Tea_1 + smh_loss_Tea_2))
        loss_Tea = ((img_loss_Tea_1 + img_loss_Tea_2) + 10 * (smh_loss_Tea_1 + smh_loss_Tea_2)) + 0.5 * (census_loss_Tea_1 + census_loss_Tea_2)


        torch.cuda.synchronize()
        end_time = time.time()


        writer.add_scalar('img_loss_Tea_1', img_loss_Tea_1, iterrat * epoch + batch_idx)
        writer.add_scalar('img_loss_Tea_2', img_loss_Tea_2, iterrat * epoch + batch_idx)
        writer.add_scalar('smh_loss_Tea_1', smh_loss_Tea_1, iterrat * epoch + batch_idx)
        writer.add_scalar('smh_loss_Tea_2', smh_loss_Tea_2, iterrat * epoch + batch_idx)
        writer.add_scalar('cen_loss_Tea_1', census_loss_Tea_1, iterrat * epoch + batch_idx)
        writer.add_scalar('cen_loss_Tea_2', census_loss_Tea_2, iterrat * epoch + batch_idx)


        writer.add_scalar('loss_Tea', loss_Tea, iterrat * epoch + batch_idx)

        loss_Tea.backward()
        
        if SP_args.model_name == 'depth':
            print("Epoch :", epoch)
            print("Batch Index :", batch_idx)
            print(net.conv1.weight.grad[0,0,0,0])

        elif SP_args.model_name == 'flow':
            print("================================")
            print("  Epoch:           ", epoch)
            print("  Batch Index:     ", batch_idx)
            print("  Learning Rate:   ", optimizer_Tea.state_dict()['param_groups'][0]['lr'])
            print("  Computing Time:  ", round(end_time - start_time, 3))
            print("  total_loss_Tea:  ", loss_Tea)
            print("  pixel_loss_Tea:  ", (img_loss_Tea_1 + img_loss_Tea_2))
            print("  smooth_loss_Tea: ",  10 * (smh_loss_Tea_1 + smh_loss_Tea_2))
            print("  census_loss_Tea: ",  0.5 * (census_loss_Tea_1 + census_loss_Tea_2))

            print("----------------------------------------")

        
        # if batch_idx % 1000 == 0:
        #     state = {'epoch': epoch, 'batch_idx': batch_idx, 'state_dict': net_Tea.state_dict(), 
        #             'optimizer': optimizer_Tea.state_dict(), 'scheduler': scheduler_Tea}
        #     torch.save(state, SP_args.flow_model_path + "model_epoch" + str(epoch) + "_idx" + str(batch_idx))
        #     print("The model of epoch", epoch, "batch_idx", batch_idx, "has been saved.")


        ## optimize upgrade
        optimizer_Tea.step()

    if epoch % 1 == 0:
        state = {'epoch': epoch, 'state_dict': net_Tea.state_dict(), 'optimizer': optimizer_Tea.state_dict(), 'scheduler': scheduler_Tea}
        torch.save(state, SP_args.flow_model_path + "model_epoch" + str(epoch))
        print("The Tea_flow model of epoch ", epoch, "has been saved.")
