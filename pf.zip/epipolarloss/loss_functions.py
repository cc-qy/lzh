import torch
from torch.autograd import Variable
import torch.nn as nn

def normalize2dpoints(X,Y):    
    meanX = torch.mean(X,0)
    meanY = torch.mean(Y,0)
    newpX = X-meanX
    newpY = Y-meanY
    dist  = torch.sqrt(newpX**2 + newpY**2)
    meandist = torch.mean(dist,0)
    scale = 1.4142135623730951/meandist
    
    newX = scale*(X-meanX)
    newY = scale*(Y-meanY)
    T = torch.FloatTensor([[scale, 0, -scale*meanX], [0, scale, -scale*meanY],[0,0,1]]).cuda().double()
    return newX, newY, T

# def random_select_points(x,y,x_,y_,samples=10):
#     idx=torch.randperm(x.shape[0])
#     x=x[idx[:samples],:]
#     y=y[idx[:samples],:]
#     x_=x_[idx[:samples],:]
#     y_=y_[idx[:samples],:]
#     return x,y,x_,y_

def random_select_points(x,y,D,x_,y_,samples=10):
    idx=torch.randperm(x.shape[0])
    x=x[idx[:samples],:]
    y=y[idx[:samples],:]
    D = D[idx[:samples], :]
    x_=x_[idx[:samples],:]
    y_=y_[idx[:samples],:]
    return x,y,D,x_,y_

def pnp_subspaces_loss(disp, fx, K_inv, flow, mask):
    B,_,H,W = flow.size()
    xx = Variable(torch.arange(0, W).view(1, -1).repeat(H, 1).cuda())
    yy = Variable(torch.arange(0, H).view(-1, 1).repeat(1, W).cuda())
    grid_x = xx.view(1, 1, H, W).repeat(B, 1, 1, 1).float()
    grid_y = yy.view(1, 1, H, W).repeat(B, 1, 1, 1).float()

    flow_u = flow[:, 0, :, :].unsqueeze(1)
    flow_v = flow[:, 1, :, :].unsqueeze(1)

    pos_x = grid_x + flow_u
    pos_y = grid_y + flow_v

    inside_x = (pos_x <= (W - 1)) & (pos_x >= 0.0)
    inside_y = (pos_y <= (H - 1)) & (pos_y >= 0.0)
    print("the sum of inside_x:  ", inside_x.sum())
    print("the sum of inside_y:  ", inside_y.sum())

    mask = mask.type(torch.ByteTensor).cuda()

    inside = inside_x & inside_y & mask

    loss = 0
    baseline = 0.54
    loss1_weight = 0.01
    loss2_weight = 0.004

    for i in range(B):
        grid_x_i = grid_x[i, :, :, :]
        grid_y_i = grid_y[i, :, :, :]
        pos_x_i = pos_x[i, :, :, :]
        pos_y_i = pos_y[i, :, :, :]
        inside_i = inside[i, :, :, :]
        print(" the sum of before inside_i: ", inside_i.sum())
        fx_i = fx[i].float().cuda()
        disp_i = disp[i,:,:,:].float().cuda()
        #print("K_inv:  ", K_inv[i,:,:])
        K_inv_i = K_inv[i,:,:].float().cuda()
        D = -1.0 * (fx_i * baseline / disp_i)
        inside_d = (D <= 80.0) & (D >= 0.0)
        inside_i = inside_d & inside_i
        print(" the sum of inside_d:       ", inside_d.sum())
        print(" the sum of after inside_i: ", inside_i.sum())

        if inside_i.sum()>2000:
            x  = torch.masked_select(grid_x_i, inside_i).view(-1,1)
            y  = torch.masked_select(grid_y_i, inside_i).view(-1,1)
            x_ = torch.masked_select(pos_x_i, inside_i).view(-1,1)
            y_ = torch.masked_select(pos_y_i, inside_i).view(-1,1)
            D  = torch.masked_select(D, inside_i).view(-1,1)

            x, y, D, x_, y_ = random_select_points(x,y,D,x_,y_,samples=2000)
            # D = (fx_i * baseline / D)  ######## (2000,1)
            D = D.permute(1, 0)
            o = torch.ones_like(x).cuda()
            X = torch.cat((x,y,o),1).permute(1,0)            ###(3,2000)
            X = torch.mul(D,X)                    ####3(3,2000)
            P = torch.mm(K_inv_i,X) / 80.0
            P = torch.cat((P,o.permute(1,0)),0)
            X_ = -1.0 * (x_/W + y_/W).permute(1,0)         ##(1,2000)
            PX_ = torch.mul(X_,P)
            M = torch.cat((P,P,PX_),0)                         ##(12,2000)
            # o  = torch.ones_like(x)
            # x, y, x_, y_ = x/W, y/W, x_/W, y_/W
            # X  = torch.cat((x,x,x,y,y,y,o,o,o),1).permute(1,0)
            # X_ = torch.cat((x_,y_,o,x_,y_,o,x_,y_,o),1).permute(1,0)
            # M  = X * X_
            lambda1 = 10
            MTM = lambda1 * M.permute(1, 0).mm(M)
            I = torch.eye(MTM.size()[0]).cuda()
            temp1 = torch.inverse((I + MTM))
            C = temp1.mm(MTM)
            C2 = C ** 2
            loss1 = torch.sum(C2.view(-1, 1), dim=0)
            temp2 = M.mm(C) - M
            temp2 = temp2 ** 2

            loss2 = lambda1 * torch.sum(temp2.view(-1, 1), dim=0)
            loss += (loss1_weight*loss1 + loss2_weight*loss2)
        else:
            loss += 0.000000001
    return loss/B

def subspace_loss(flow,mask):
    B, _, H, W = flow.size()
    xx = Variable(torch.arange(0, W).view(1,-1).repeat(H,1).cuda())
    yy = Variable(torch.arange(0, H).view(-1,1).repeat(1,W).cuda())
    grid_x = xx.view(1,1,H,W).repeat(B,1,1,1).float()
    grid_y = yy.view(1,1,H,W).repeat(B,1,1,1).float()
    
    flow_u = flow[:,0,:,:].unsqueeze(1)
    flow_v = flow[:,1,:,:].unsqueeze(1)
    
    pos_x = grid_x + flow_u
    pos_y = grid_y + flow_v

    inside_x = (pos_x <= (W-1)) & (pos_x >= 0.0)
    inside_y = (pos_y <= (H-1)) & (pos_y >= 0.0)
    
    inside = inside_x & inside_y & mask
    
    loss = 0

    for i in range(B):
        grid_x_i = grid_x[i,:,:,:]
        grid_y_i = grid_y[i,:,:,:]
        pos_x_i = pos_x[i,:,:,:]
        pos_y_i = pos_y[i,:,:,:]
        inside_i= inside[i,:,:,:]

        if inside_i.sum()>2000:
            x  = torch.masked_select(grid_x_i, inside_i).view(-1,1)
            y  = torch.masked_select(grid_y_i, inside_i).view(-1,1)
            x_ = torch.masked_select(pos_x_i, inside_i).view(-1,1)
            y_ = torch.masked_select(pos_y_i, inside_i).view(-1,1)
            x, y, x_, y_ = random_select_points(x,y,x_,y_,samples=2000)
            o  = torch.ones_like(x)
            x, y, x_, y_ = x/W, y/W, x_/W, y_/W
            X  = torch.cat((x,x,x,y,y,y,o,o,o),1).permute(1,0)  
            X_ = torch.cat((x_,y_,o,x_,y_,o,x_,y_,o),1).permute(1,0)

            M  = X * X_

            lambda1 = 10
            MTM = lambda1 * M.permute(1,0).mm(M)
            I = torch.eye(MTM.size()[0]).cuda()
            temp1 = torch.inverse((I + MTM))
            C = temp1.mm(MTM)
            C2 = C**2
            loss1 = torch.sum(C2.view(-1,1),dim=0)
            temp2 = M.mm(C)-M
            temp2 = temp2**2

            loss2 = lambda1 * torch.sum(temp2.view(-1,1),dim=0)
            loss +=  (loss1 + loss2)
        else:
            loss += 0.0001
        
    return loss/B

def lowrank_loss(flow,mask):
    B, _, H, W = flow.size()
    xx = Variable(torch.arange(0, W).view(1,-1).repeat(H,1).cuda())
    yy = Variable(torch.arange(0, H).view(-1,1).repeat(1,W).cuda())
    grid_x = xx.view(1,1,H,W).repeat(B,1,1,1).float()
    grid_y = yy.view(1,1,H,W).repeat(B,1,1,1).float()
    
    flow_u = flow[:,0,:,:].unsqueeze(1)
    flow_v = flow[:,1,:,:].unsqueeze(1)
    
    pos_x = grid_x + flow_u
    pos_y = grid_y + flow_v

    inside_x = (pos_x <= (W-1)) & (pos_x >= 0.0)
    inside_y = (pos_y <= (H-1)) & (pos_y >= 0.0)

    # print("inside",inside_x.shape)
    # print("inside",inside_x.type())

    inside = inside_x & inside_y & mask
    
    loss = 0
    for i in range(B):
        grid_x_i = grid_x[i,:,:,:]
        grid_y_i = grid_y[i,:,:,:]
        pos_x_i = pos_x[i,:,:,:]
        pos_y_i = pos_y[i,:,:,:]
        inside_i= inside[i,:,:,:]
        if inside_i.sum()>2000:
            x  = torch.masked_select(grid_x_i, inside_i).view(-1,1)
            y  = torch.masked_select(grid_y_i, inside_i).view(-1,1)

            x_ = torch.masked_select(pos_x_i, inside_i).view(-1,1)
            y_ = torch.masked_select(pos_y_i, inside_i).view(-1,1)
            x, y, x_, y_ = random_select_points(x,y,x_,y_,samples=2000)
            o  = torch.ones_like(x)
            x, y , T = normalize2dpoints(x,y)
            x_,y_, T_= normalize2dpoints(x_,y_)

            X  = torch.cat((x,x,x,y,y,y,o,o,o),1).permute(1,0)

            X_ = torch.cat((x_,y_,o,x_,y_,o,x_,y_,o),1).permute(1,0)

            XX = torch.cat((x,y,o),1).permute(1,0).double()
            XX_= torch.cat((x_,y_,o),1).permute(1,0).double()

            M  = X * X_

            U, S, V = torch.svd(M.permute(1,0)) 
            loss += torch.sum(S.abs())/x.size()[0]
        else:
            loss += 0.0001

    return loss


    ############
    ############
    ###2019-author-mask

def warp(x, flo):
    """
    warp an image/tensor (im2) back to im1, according to the optical flow
    x: [B, C, H, W] (im2)
    flo: [B, 2, H, W] flow
    """
    B, C, H, W = x.size()
    # mesh grid 
    xx = torch.arange(0, W).view(1,-1).repeat(H,1)
    yy = torch.arange(0, H).view(-1,1).repeat(1,W)
    xx = xx.view(1,1,H,W).repeat(B,1,1,1)
    yy = yy.view(1,1,H,W).repeat(B,1,1,1)
    grid = torch.cat((xx,yy),1).float()

    if x.is_cuda:
        grid = grid.cuda()
    vgrid = Variable(grid) + flo

    # scale grid to [-1,1] 
    ##2019 code
    vgrid[:,0,:,:] = 2.0*vgrid[:,0,:,:].clone()/max(W-1,1)-1.0
    vgrid[:,1,:,:] = 2.0*vgrid[:,1,:,:].clone()/max(H-1,1)-1.0

    ##2019  author   without .clone()
    # vgrid[:,0,:,:] = 2.0*vgrid[:,0,:,:]/max(W-1,1)-1.0
    # vgrid[:,1,:,:] = 2.0*vgrid[:,1,:,:]/max(H-1,1)-1.0

    vgrid = vgrid.permute(0,2,3,1)
    output = nn.functional.grid_sample(x, vgrid)
    mask = torch.autograd.Variable(torch.ones(x.size())).cuda()
    mask = nn.functional.grid_sample(mask, vgrid)

    # if W==128:
        # np.save('mask.npy', mask.cpu().data.numpy())
        # np.save('warp.npy', output.cpu().data.numpy())
    ##2019 author
    mask[mask<0.9999] = 0
    mask[mask>0] = 1

    ##2019 code
    # mask = torch.floor(torch.clamp(mask, 0 ,1))

    return output*mask

def compute_occlusion(disp_left,disp_right,t):
    disp_right2left = warp(disp_right, disp_left)
    disp_left2right = warp(disp_left, disp_right)

    tmp_left = (disp_left + disp_right2left).abs()
    tmp_right = (disp_right + disp_left2right).abs()

    mask_left = (tmp_left[:,0,:,:] < t) & (tmp_left[:,1,:,:] < t)
    mask_left = mask_left.unsqueeze(1)
    mask_right = (tmp_right[:,0,:,:] < t) & (tmp_right[:,1,:,:] < t)
    mask_right = mask_right.unsqueeze(1)
        
    mask_left = mask_left.float()
    mask_right = mask_right.float()

    return mask_left, mask_right

# disp_left: the forward flow;
# disp_right: the backward flow.
# t is the threshold, can be 1.

############
############
