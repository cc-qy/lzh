import torch
import os
import torchvision.transforms as transforms
import torch.utils.data as data
import numpy as np
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import argparse
from models.MonodepthModel import *
from models.PWC_net import *
from models.PWC_net import PWCDCNet
from utils.scene_dataloader import *
from utils.utils import *
import warnings

warnings.filterwarnings("ignore")

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

def get_args():
    parser = argparse.ArgumentParser(description = 'Subspace PnP depth and flow pytorch test')
    
    parser.add_argument('--model_name',                type=str,   help='model name', default='flow')
    parser.add_argument('--load_2012_kitti_data_path', type=str,   help='path to the data', default='/home/HTY_user/dataset/KITTI/kitti_2012_flow/')
    parser.add_argument('--load_2015_kitti_data_path', type=str,   help='path to the data', default='/home/HTY_user/dataset/KITTI/kitti_2015_flow/')
    parser.add_argument('--load_2012_filenames_file',  type=str,   help='path to the filenames text file', default='./utils/filenames/2012.txt')
    parser.add_argument('--load_2015_filenames_file',  type=str,   help='path to the filenames text file', default='./utils/filenames/2015.txt')
    parser.add_argument('--input_height',              type=int,   help='input height', default=320)
    parser.add_argument('--input_width',               type=int,   help='input width', default=896)
    parser.add_argument('--checkpoint_path',           type=str,   help='path to a specific checkpoint to load', required=True)
    parser.add_argument('--result_path',               type=str,   help='path to a save result', required=True)
    parser.add_argument('--test_together',             type=str,   help='path to a save result', default='yes')
    args = parser.parse_args()
    return args

args = get_args()


test_kitti_2012 = True
test_kitti_2015 = True
test_noc = True
test_all = True

save_dir = args.result_path + "test.txt"
print("results save path: ", save_dir)
print("\n The model is : " + args.checkpoint_path + "\n")



if args.test_together == 'yes':
    checkpoint = torch.load(args.checkpoint_path)
    if args.model_name == 'depth':
        net = MonodepthNet().cuda()
    elif args.model_name == 'flow':
        net = pwc_dc_net().cuda()

    net.load_state_dict(checkpoint['state_dict'])

    result_file = open(save_dir,'a+')
    result_file.write("\n The model is : " + args.checkpoint_path + "\n")


    if test_kitti_2012:
        former_test, latter_test, flow_noc, flow_occ = get_flow_test_data(args.load_2012_filenames_file, args.load_2012_kitti_data_path)
        TestFlowLoader = torch.utils.data.DataLoader(
            myImageFolder_flow(former_test, latter_test, flow_noc, flow_occ, args),
            batch_size=1, shuffle=False, num_workers=1, drop_last=False)

        total_error_noc = fl_error_noc = total_error_occ = fl_error_occ = total_error_all = fl_error_all = 0.0
        num_test = 0

        for batch_idx, (left_1, left_2, flow_noc, flow_occ, mask_noc, mask_all, h, w) in enumerate(TestFlowLoader, 0):
            model_input = Variable(torch.cat((left_1, left_2), 1).cuda())

            if args.model_name == 'depth':
                disp_est_scale, disp_est = net(model_input)
            elif args.model_name == 'flow':
                disp_est_scale = net(model_input)


            mask_noc = np.ceil(np.clip(np.abs(flow_noc[0, 0]), 0, 1))
            mask_all = np.ceil(np.clip(np.abs(flow_occ[0, 0]), 0, 1))

            disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
            disp_ori_scale[0, 0] = disp_ori_scale[0, 0] * int(w) / args.input_width
            disp_ori_scale[0, 1] = disp_ori_scale[0, 1] * int(h) / args.input_height

            error_noc, fl_noc = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), flow_noc[0].numpy(),
                                              mask_noc.numpy())
            total_error_noc += error_noc
            fl_error_noc += fl_noc

            error_all, fl_all = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), flow_occ[0].numpy(),
                                              mask_all.numpy())
            total_error_all += error_all
            fl_error_all += fl_all

            error_occ, fl_occ = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), flow_occ[0].numpy(),
                                              (mask_all - mask_noc).numpy())
            total_error_occ += error_occ
            fl_error_occ += fl_occ
            num_test += 1

        print("\n KITTI 2012 training set: \n")
        result_file.write(" KITTI 2012 training set: \n")

        total_error_noc /= num_test
        fl_error_noc /= num_test
        print("NOC average EPE is :  ", total_error_noc)
        print("The average F-l is :  ", fl_error_noc)
        result_file.write("NOC average EPE is :  " + str(total_error_noc) + "\n")
        result_file.write("The average F-l is :  " + str(fl_error_noc) + "\n")

        total_error_all /= num_test
        fl_error_all /= num_test
        print("ALL average EPE is :  ", total_error_all)
        print("The average F-l is :  ", fl_error_all)
        result_file.write("ALL average EPE is :  " + str(total_error_all) + "\n")
        result_file.write("The average F-l is :  " + str(fl_error_all) + "\n")

        total_error_occ /= num_test
        fl_error_occ /= num_test
        print("OCC average EPE is :  ", total_error_occ)
        print("The average F-l is :  ", fl_error_occ)
        result_file.write("OCC average EPE is :  " + str(total_error_occ) + "\n")
        result_file.write("The average F-l is :  " + str(fl_error_occ) + "\n")


    if test_kitti_2015:
        former_test, latter_test, flow_noc, flow_occ = get_flow_test_data(args.load_2015_filenames_file, args.load_2015_kitti_data_path)
        TestFlowLoader = torch.utils.data.DataLoader(
            myImageFolder_flow(former_test, latter_test, flow_noc, flow_occ, args),
            batch_size=1, shuffle=False, num_workers=1, drop_last=False)
        total_error_noc = fl_error_noc = total_error_occ = fl_error_occ = total_error_all = fl_error_all = 0.0
        num_test = 0
        num_occ = 0

        for batch_idx, (left_1, left_2, flow_noc, flow_occ, mask_noc, mask_all, h, w) in enumerate(TestFlowLoader, 0):
            model_input = Variable(torch.cat((left_1, left_2), 1).cuda())


            if args.model_name == 'depth':
                disp_est_scale, disp_est = net(model_input)
            elif args.model_name == 'flow':
                disp_est_scale = net(model_input)


            mask_noc = np.ceil(np.clip(np.abs(flow_noc[0, 0]), 0, 1))
            mask_all = np.ceil(np.clip(np.abs(flow_occ[0, 0]), 0, 1))

            disp_ori_scale = F.interpolate(disp_est_scale[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
            disp_ori_scale[0, 0] = disp_ori_scale[0, 0] * int(w) / args.input_width
            disp_ori_scale[0, 1] = disp_ori_scale[0, 1] * int(h) / args.input_height

            error_noc, fl_noc = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), flow_noc[0].numpy(), mask_noc.numpy())
            total_error_noc += error_noc
            fl_error_noc += fl_noc

            error_all, fl_all = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), flow_occ[0].numpy(), mask_all.numpy())
            total_error_all += error_all
            fl_error_all += fl_all

            if (mask_all-mask_noc).sum() > 0.0:
                error_occ, fl_occ = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), flow_occ[0].numpy(),
                                                  (mask_all - mask_noc).numpy())
            else:
                error_occ = 0.0
                fl_occ = 0.0
            total_error_occ += error_occ
            fl_error_occ += fl_occ
            num_test += 1


        print("\n KITTI 2015 training set: \n")
        result_file.write(" KITTI 2015 training set: \n")

        total_error_noc /= num_test
        fl_error_noc /= num_test
        print("NOC average EPE is :  ", total_error_noc)
        print("The average F-l is :  ", fl_error_noc)

        result_file.write("NOC average EPE is :  " + str(total_error_noc) + "\n")
        result_file.write("The average F-l is :  " + str(fl_error_noc) + "\n")

        total_error_all /= num_test
        fl_error_all /= num_test
        print("All average EPE is :  ", total_error_all)
        print("The average F-l is :  ", fl_error_all)
        result_file.write("All average EPE is :  " + str(total_error_all) + "\n")
        result_file.write("The average F-l is :  " + str(fl_error_all) + "\n")

        total_error_occ /= num_test
        fl_error_occ /= num_test
        print("OCC average EPE is :  ", total_error_occ)
        print("The average F-l is :  ", fl_error_occ)
        result_file.write("OCC average EPE is :  " + str(total_error_occ) + "\n")
        result_file.write("The average F-l is :  " + str(fl_error_occ) + "\n")

        result_file.close()

