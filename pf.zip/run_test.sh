# python3 testing_flow.py \
# --checkpoint_path='/home/cc/hty/models/model_04/model_epoch89' \
# --result_path='/home/cc/hty/models/model_04/'


## for MUltiView dataset finetune
python3 testing_flow.py \
--checkpoint_path='/home/HTY_3_user/hty_BYSJ/models/model_06/model_epoch96' \
--result_path='/home/HTY_3_user/hty_BYSJ/models/model_06/'