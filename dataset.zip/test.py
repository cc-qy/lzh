from PIL import Image
import numpy as np
import copy
import numpy.ma as ma
# ==============================================================================
#                                                                   SCALE_TO_255
# ==============================================================================
def scale_to_255(a, min, max, dtype=np.uint8):
    """ Scales an array of values from specified min, max range to 0-255
        Optionally specify the data type of the output (default is uint8)
    """
    return (((a - min) / float(max - min)) * 255).astype(dtype)
 
# ==============================================================================
#                                                         POINT_CLOUD_2_BIRDSEYE
# ==============================================================================
def point_cloud_2_birdseye(points,
                           res=0.1,
                           side_range=(-10., 10.),  # left-most to right-most
                           fwd_range = (-1., 50.), # back-most to forward-most
                           height_range=(-3., 5.),  # bottom-most to upper-most
                           ):
    """ Creates an 2D birds eye view representation of the point cloud data.
 
    Args:
        points:     (numpy array)
                    N rows of points data
                    Each point should be specified by at least 3 elements x,y,z
        res:        (float)
                    Desired resolution in metres to use. Each output pixel will
                    represent an square region res x res in size.
        side_range: (tuple of two floats)
                    (-left, right) in metres
                    left and right limits of rectangle to look at.
        fwd_range:  (tuple of two floats)
                    (-behind, front) in metres
                    back and front limits of rectangle to look at.
        height_range: (tuple of two floats)
                    (min, max) heights (in metres) relative to the origin.
                    All height values will be clipped to this min and max value,
                    such that anything below min will be truncated to min, and
                    the same for values above max.
    Returns:
        2D numpy array representing an image of the birds eye view.
    """
    # EXTRACT THE POINTS FOR EACH AXIS
    x_points = points[:, 0]
    y_points = points[:, 1]
    z_points = points[:, 2]
    # FILTER - To return only indices of points within desired cube
    # Three filters for: Front-to-back, side-to-side, and height ranges
    # Note left side is positive y axis in LIDAR coordinates
    f_filt = np.logical_and((x_points > fwd_range[0]), (x_points < fwd_range[1]))
    s_filt = np.logical_and((y_points > -side_range[1]), (y_points < -side_range[0]))
    filter = np.logical_and(f_filt, s_filt)
    indices = np.argwhere(filter).flatten()
    # KEEPERS
    x_points = x_points[indices]
    y_points = y_points[indices]
    z_points = z_points[indices]
    # CONVERT TO PIXEL POSITION VALUES - Based on resolution
    x_img = (-y_points / res).astype(np.int32)  # x axis is -y in LIDAR
    y_img = (-x_points / res).astype(np.int32)  # y axis is -x in LIDAR
      # - Camera:   x: right,   y: down,  z: forward
  # - Velodyne: x: forward, y: left,  z: up
  # - GPS/IMU:  x: forward, y: left,  z: up
    # SHIFT PIXELS TO HAVE MINIMUM BE (0,0)
    # floor & ceil used to prevent anything being rounded to below 0 after shift
    x_img -= int(np.floor(side_range[0] / res))
    y_img += int(np.ceil(fwd_range[1] / res))
    # CLIP HEIGHT VALUES - to between min and max heights
    pixel_values = np.clip(a=z_points,
                           a_min=height_range[0],
                           a_max=height_range[1])
    # RESCALE THE HEIGHT VALUES - to be between the range 0-255
    pixel_values = scale_to_255(pixel_values,
                                min=height_range[0],
                                max=height_range[1])
    # INITIALIZE EMPTY ARRAY - of the dimensions we want
    x_max = 1 + int((side_range[1] - side_range[0]) / res)
    y_max = 1 + int((fwd_range[1] - fwd_range[0]) / res)
    im = np.zeros([y_max, x_max], dtype=np.uint8)
    # FILL PIXEL VALUES IN IMAGE ARRAY
    im[y_img, x_img] = pixel_values
 
    return im
# lidar_path换成自己的.bin文件路径
seq_num = 21
seq_train_frame = [154,447,233,144,314,
             297,270,800,390,803,
             294,373,78 ,340,106,
             376,209,145,339,1059,
             837]##21
seq_test_frame = [465,147,243,257,421,
             809,114,215,165,349,
             1176,774,694 ,152,850,
             701,510,305,180,404,
             173,203,436,430,316,
             176,170,85,175]##29

# P0 = np.matrix([[7.533745000000e-03, -9.999714000000e-01, -6.166020000000e-04 ,-4.069766000000e-03],
#                 [1.480249000000e-02 ,7.280733000000e-04, -9.998902000000e-01, -7.631618000000e-02],
#                 [9.998621000000e-01, 7.523790000000e-03, 1.480755000000e-02, -2.717806000000e-01],
#                 [0 ,  0   ,0  , 1]])
# Tr_velo_cam = np.matrix([[7.533745000000e-03, -9.999714000000e-01, -6.166020000000e-04 ,-4.069766000000e-03],
#                 [1.480249000000e-02 ,7.280733000000e-04, -9.998902000000e-01, -7.631618000000e-02],
#                 [9.998621000000e-01, 7.523790000000e-03, 1.480755000000e-02, -2.717806000000e-01],
#                 [0 ,  0   ,0  , 1]])

# Tr_imu_velo = np.matrix([[9.999976000000e-01, 7.553071000000e-04, -2.035826000000e-03, -8.086759000000e-01],
#                 [-7.854027000000e-04, 9.998898000000e-01, -1.482298000000e-02, 3.195559000000e-01],
#                 [2.024406000000e-03, 1.482454000000e-02, 9.998881000000e-01, -7.997231000000e-01],
#                 [0 ,  0   ,0  , 1]])

  # - Camera:   x: right,   y: down,  z: forward
  # - Velodyne: x: forward, y: left,  z: up
  # - GPS/IMU:  x: forward, y: left,  z: up
T01 = np.matrix([[1.0, 0,   0,   0],
                [0 ,   -1.0 ,  0,0],
                [0 ,   0 ,  -1.0  , 0],
                [0 ,  0   ,0  , 1.0]])
for i in range(seq_num):
    print ("seq: ",i)
    seq_frame = seq_train_frame[i]
    calib_path = './calib/' + str(i).zfill(4) + '.txt'
    f  = open(calib_path,'r')
    lines = f.readlines()
    P0 = np.ones([4,4])
    P1 = np.ones([4,4])
    P2 = np.ones([4,4])
    P3 = np.ones([4,4])
    R_rect = np.ones([4,4])
    Tr_velo_cam = np.ones([4,4])
    Tr_imu_velo = np.ones([4,4])
    Tr_cam0_cam2 = np.ones([4,4])
    R_rect = np.ones([3,3])
    lens = len(lines)
    Tr_velo_cam[0] = lines[5].split()[1:5] 
    Tr_velo_cam[1] = lines[5].split()[5:9] 
    Tr_velo_cam[2] = lines[5].split()[9:13] 
    Tr_velo_cam[3] = [0,0,0,1]
    Tr_imu_velo[0] = lines[6].split()[1:5] 
    Tr_imu_velo[1] = lines[6].split()[5:9] 
    Tr_imu_velo[2] = lines[6].split()[9:13] 
    Tr_imu_velo[3] = [0,0,0,1]
    R_rect[0] = lines[4].split()[1:4] 
    R_rect[1] = lines[4].split()[4:7] 
    R_rect[2] = lines[4].split()[7:10] 
    Tr_cam0_cam2[0:3,0:3] = R_rect
    Tr_cam0_cam2[3] = [0,0,0,1]
    Tr_cam0_cam2[1,3] = lines[2].split()[4]
    Tr_cam0_cam2[2,3] = lines[2].split()[1]
    Tr_cam0_cam2[0,3] = -Tr_cam0_cam2[1,3]/Tr_cam0_cam2[2,3]
    Tr_cam0_cam2[1:3,3] = 0
    # print (Tr_cam0_cam2)
    # print (lens)
    # print (lines[0].split()[0])
    # print (lines[0].split()[1])
    # print (Tr_velo_cam)
    # print (lines[5].split())
    obj_3D_box_path = './label_02/' + str(i).zfill(4) + '.txt'
    f  = open(obj_3D_box_path,'r')
    obj_3D_box = f.readlines()
    # obj_3D_box
    pose_imu_gt_path = './pose_gt/' + str(i).zfill(4) + '.txt'
    f  = open(pose_imu_gt_path,'r')
    lines = f.readlines()
    pose_imu_gt_0 = lines[0].split(',')
    pose_imu_gt_1 = lines[1].split(',')
    pose_imu_gt_2 = lines[2].split(',')
    pose_imu_gt_3 = lines[3].split(',')
    for j in range(seq_frame-1):
        # j = 120、？
        pose_imu_gt_j_to_0 = np.zeros([4,4])
        pose_imu_gt_jt1_to_0 = np.zeros([4,4])
        pose_imu_gt_j_to_0[0] = pose_imu_gt_0[(j * 4):(j * 4 + 4)]
        pose_imu_gt_j_to_0[1] = pose_imu_gt_1[(j * 4):(j * 4 + 4)]
        pose_imu_gt_j_to_0[2] = pose_imu_gt_2[(j * 4):(j * 4 + 4)]
        pose_imu_gt_j_to_0[3] = pose_imu_gt_3[(j * 4):(j * 4 + 4)]
        # print (pose_imu_gt_j_to_0)
        pose_imu_gt_jt1_to_0[0] = pose_imu_gt_0[(j * 4 + 4):(j * 4 + 4 + 4)]
        pose_imu_gt_jt1_to_0[1] = pose_imu_gt_1[(j * 4 + 4):(j * 4 + 4 + 4)]
        pose_imu_gt_jt1_to_0[2] = pose_imu_gt_2[(j * 4 + 4):(j * 4 + 4 + 4)]
        pose_imu_gt_jt1_to_0[3] = pose_imu_gt_3[(j * 4 + 4):(j * 4 + 4 + 4)]
        # print (pose_imu_gt_jt1_to_0)
        # pose_imu_gt_jt1_to_0_inv = copy.deepcopy(pose_imu_gt_jt1_to_0) 
        # pose_imu_gt_jt1_to_0_inv[0:3,0:3] = pose_imu_gt_jt1_to_0_inv[0:3,0:3].transpose()
        # pose_imu_gt_jt1_to_0_inv[0:3,0:3]
        pose_imu_gt_jt1_to_0_inv = np.linalg.inv(copy.deepcopy(pose_imu_gt_jt1_to_0))
        # print (pose_imu_gt_jt1_to_0_inv)
        ####imu  t to t+1
        pose_imu_gt_jt_to_t1 = np.matmul(pose_imu_gt_jt1_to_0_inv, pose_imu_gt_j_to_0)
        # print (pose_imu_gt_jt_to_t1)
        ########################################zhou fangxiang butong ,dan mei yingxiang 
        T01_inv = np.linalg.inv(copy.deepcopy(T01))
        pose_imu_gt_jt_to_t1 = np.matmul(np.matmul(T01, pose_imu_gt_jt_to_t1), T01_inv)
        # print (pose_imu_gt_jt_to_t1)
        ###ladir  t   to t+1
        # Tr_imu_velo_inv = copy.deepcopy(Tr_imu_velo) 
        # Tr_imu_velo_inv[0:3,0:3] = Tr_imu_velo_inv[0:3,0:3].transpose()
        Tr_imu_velo_inv = np.linalg.inv(copy.deepcopy(Tr_imu_velo))
        pose_lidar_gt_jt_to_t1 = np.matmul(np.matmul(Tr_imu_velo, pose_imu_gt_jt_to_t1), Tr_imu_velo_inv)
        ###cam2  t   to t+1
        Tr_velo_cam2 = np.matmul(Tr_cam0_cam2, Tr_velo_cam)
        # Tr_velo_cam2_inv = copy.deepcopy(Tr_velo_cam2) 
        # Tr_velo_cam2_inv[0:3,0:3] = Tr_velo_cam2_inv[0:3,0:3].transpose()
        Tr_velo_cam2_inv = np.linalg.inv(copy.deepcopy(Tr_velo_cam2))
        pose_cam2_gt_jt_to_t1 = np.matmul(np.matmul(Tr_velo_cam2, pose_lidar_gt_jt_to_t1), Tr_velo_cam2_inv)
        ################
        pointcloud_path = './' + str(i).zfill(4) + '/' + str(j).zfill(6) + '.bin'
        pointcloud = np.fromfile(pointcloud_path, dtype=np.float32, count=-1).reshape([-1, 4])

        x = pointcloud[:, 0]  # x position of point
        y = pointcloud[:, 1]  # y position of point
        z = pointcloud[:, 2]  # z position of point

        # pose = np.ones([4,4])
        one = np.expand_dims(np.ones_like(z), 1)

        Nor_points = np.hstack((pointcloud[:, 0:3], one))
        Trans_Nor_points = np.swapaxes(np.matmul(pose_lidar_gt_jt_to_t1, np.swapaxes(Nor_points, 1, 0)), 0, 1)
        scene_flow = Trans_Nor_points - Nor_points

        mask_static = np.expand_dims(np.ones_like(z), 1)
        # print ("mask_static: ", mask_static.shape)
        ######################
        begin_id = -1
        end_id = -1
        count = 0
        for obj in obj_3D_box:
            if (int(obj.split()[0]) == j) & (begin_id == -1):
                begin_id = count
                # print ("xx000000x")
            if (int(obj.split()[0]) == (j+1)): 
                end_id = count
            count = count + 1
        if (begin_id>-1)&(end_id>-1):
            for obj_i in range(begin_id, end_id):
                for obj_j in range(obj_i+1, end_id+1):
                    if (int(obj_3D_box[obj_i].split()[1])==int(obj_3D_box[obj_j].split()[1]))&(int(obj_3D_box[obj_i].split()[1])!=-1):
                        obi_xyz = np.ones([1,3])
                        obi_hwl = np.ones([1,3])
                        obi_rotation_y = np.ones([1,1])
                        obi_alpha = np.ones([1,1])
                        obj_xyz = np.ones([1,3])
                        obj_hwl = np.ones([1,3])
                        obj_rotation_y = np.ones([1,1])
                        obj_alpha = np.ones([1,1])
                        obi_xyz = obj_3D_box[obj_i].split()[13:16]
                        obi_hwl = obj_3D_box[obj_i].split()[10:13]
                        obi_rotation_y = obj_3D_box[obj_i].split()[16]
                        obi_alpha = obj_3D_box[obj_i].split()[5]
                        obj_xyz = obj_3D_box[obj_j].split()[13:16]
                        obj_hwl = obj_3D_box[obj_j].split()[10:13]
                        obj_rotation_y = obj_3D_box[obj_j].split()[16]
                        obj_alpha = obj_3D_box[obj_j].split()[5]
                        # pose_obj = np.ones([4,4])
                        # print ("begin.....................................................")
                        # print (obj_3D_box[obj_i].split()[2])
                        # print ("obi_xyz:", obi_xyz)
                        # print ("obj_xyz:", obj_xyz)
                        # print ("obj_hwl:",obi_hwl)
                        # print (obi_rotation_y)
                        # print (obj_i," ", obj_j)
                        Nor_points_cam2 = np.swapaxes(np.matmul(Tr_velo_cam2, np.swapaxes(Nor_points, 1, 0)), 0, 1)
                        #############################################cal mask
                        # mask_y = copy.deepcopy(np.expand_dims(np.zeros_like(z), 1))###y --- y-h
                        # print (obj_xyz[1])
                        # print (float(obi_hwl[0]))
                        # print (Nor_points_cam2[:,1])
                        # Nor_points_cam2[0,1] = 0.5
                        Nor_points_obj = copy.deepcopy(Nor_points_cam2) 
                        Nor_points_obj[0] = Nor_points_obj[0] - float(obj_xyz[0])
                        Nor_points_obj[1] = Nor_points_obj[1] - float(obj_xyz[1])
                        Nor_points_obj[2] = Nor_points_obj[2] - float(obj_xyz[2])
                        mask_y = ma.masked_inside(Nor_points_obj[:,1],-float(obi_hwl[0]),0.0)
                        # print (mask_y.mask)
                        obi_rotation_y_final = 0.0
                        if float(obi_rotation_y) < 0.0:
                            obi_rotation_y_final = 2 * 3.1415926 + float(obi_rotation_y)
                        if float(obi_rotation_y) > 0.0:
                            obi_rotation_y_final = 3.1415926 - float(obi_rotation_y)
                        if float(obi_rotation_y) ==0.0:
                            print ("error obi_rotation_y",i," ",j)
                        sin_rotation_y = np.sin(obi_rotation_y_final)
                        cos_rotation_y = np.cos(obi_rotation_y_final)
                        x_new = Nor_points_cam2[:,0] * cos_rotation_y - Nor_points_cam2[:,2] * sin_rotation_y
                        z_new = Nor_points_cam2[:,0] * sin_rotation_y + Nor_points_cam2[:,2] * cos_rotation_y
                        # print (obi_rotation_y_final,cos_rotation_y)
                        mask_x = ma.masked_inside(Nor_points_obj[:,0],-0.5*float(obi_hwl[1]),0.5*float(obi_hwl[1]))
                        mask_z = ma.masked_inside(Nor_points_obj[:,2],-0.5*float(obi_hwl[2]),0.5*float(obi_hwl[2]))
                        mask_obj = mask_y.mask * mask_x.mask * mask_z.mask
                        # print (mask_obj.shape)
                        ########################################################
                        ##################################################cal obj pose
                        obj_t_t_to_t1 = [float(obj_xyz[0]) - float(obi_xyz[0]), float(obj_xyz[1]) - float(obi_xyz[1]), float(obj_xyz[2]) - float(obi_xyz[2])]
                        # print ("obj_t_t_to_t1: ", obj_t_t_to_t1)
                        obj_R_t_to_t1 = 0.0
                        if (float(obi_rotation_y)<0.0)&(float(obj_rotation_y)<0.0):
                            obj_R_t_to_t1 = -float(obj_rotation_y) - (-float(obi_rotation_y))
                        if (float(obi_rotation_y)<0.0)&(float(obj_rotation_y)>0.0):
                            obj_R_t_to_t1 = (3.1415926+float(obi_rotation_y)) + (float(obj_rotation_y))
                        if (float(obi_rotation_y)>0.0)&(float(obj_rotation_y)>0.0):
                            obj_R_t_to_t1 = float(obj_rotation_y) - float(obi_rotation_y)
                        if (float(obi_rotation_y)>0.0)&(float(obj_rotation_y)<0.0):
                            obj_R_t_to_t1 = 3.1415926-float(obi_rotation_y) - (float(obj_rotation_y))
                        obj_T_t_to_t1_matrix =  np.matrix([ [np.cos(obj_R_t_to_t1), 0,   np.sin(obj_R_t_to_t1),   float(obj_xyz[0]) - float(obi_xyz[0])],
                                                            [0 ,   1,  0,float(obj_xyz[1]) - float(obi_xyz[1])],
                                                            [-np.sin(obj_R_t_to_t1) ,   0 ,  np.cos(obj_R_t_to_t1)  , float(obj_xyz[2]) - float(obi_xyz[2])],
                                                            [0 ,  0   ,0  , 1.0]])
                        Nor_points_cam2_obi = np.swapaxes(np.matmul(obj_T_t_to_t1_matrix, np.swapaxes(Nor_points_cam2, 1, 0)), 0, 1)

                        scene_flow_obj = Nor_points_cam2_obi - Nor_points_cam2
                        scene_flow[mask_obj] = scene_flow_obj[mask_obj]

                        # print ("obj_T_t_to_t1_matrix:",obj_T_t_to_t1_matrix)
                        # print (Nor_points_cam2_obi.shape)
                        # print (np.expand_dims(np.ones([1,1]), 1).shape)
                        obi_xyz_nor = np.vstack((np.expand_dims(obi_xyz, 1), np.ones([1,1])))
                        Nor_points_cam2_obi = np.swapaxes(np.matmul(pose_cam2_gt_jt_to_t1, obi_xyz_nor.astype(float)), 0, 1)
                        # print ("Nor_points_cam2_obi: ", Nor_points_cam2_obi)
                        # print ("end###################################################3 ")

        # print (begin_id)
        # print (end_id)
        # print (scene_flow.shape)
        # # obj_3D_box_path = './label_02/' + str(i).zfill(4) + '.txt'
        # # print(len(obj_3D_box))
        # xxx
        # for mm in range()
        # print (scene_flow.shape)
        # for j in range (1):el
        # print (T01)
        # print (T01.shape)   	
        # print (Trans_Nor_points.shape)
        # print (Nor_points.shape)

        sceneflow_path = './' + str(i).zfill(4) + '/' + str(j).zfill(6) + 'gt'
        np.savez(sceneflow_path,scene_flow)

        # data = np.load("./0000/000000gt.npz")
        # # print (list(data))
        # # print ((data['arr_0'][0]))
        # # To transform a point X from GPS/IMU coordinates to the image plane:
        # # Y = P_rect_xx * R_rect_00 * (R|T)_velo_to_cam * (R|T)_imu_to_velo * X
        # Tr_imu_cam = np.matmul(Tr_velo_cam,Tr_imu_velo)
        # pointcloud_bev = np.swapaxes(np.matmul(Tr_velo_cam, np.swapaxes(Nor_points, 1, 0)), 0, 1)
        # pointcloud_bev_cam = np.hstack((np.hstack((-Nor_points[:, 1:2], -Nor_points[:, 2:3])), Nor_points[:, 0:1]))
        # # print (pointcloud_bev[0])
        # im = point_cloud_2_birdseye(Nor_points)
        # im2 = Image.fromarray(im)
        # # im2.save("./1.jpg")
        # xxx
    # print (data["arr_0"].shape)
    # print (data["arr_0"][0])
    # print (data["arr_0"][100000])

    # print (data["arr_1"].shape)
    # print (data["arr_1"][0])
    # print (data["arr_1"][100000])
 
# fig = mayavi.mlab.figure(bgcolor=(0, 0, 0), size=(640, 500))
# mayavi.mlab.points3d(x, y, z,
#                      col,  # Values used for Color
#                      mode="point",
#                      colormap='spectral',  # 'bone', 'copper', 'gnuplot'
#                      # color=(0, 1, 0),   # Used a fixed (r,g,b) instead
#                      figure=fig,
#                      )
 
# mayavi.mlab.show()
# import numpy as np
 
# ==============================================================================
# #                                                                   SCALE_TO_255
# # ==============================================================================
# def scale_to_255(a, min, max, dtype=np.uint8):
#     """ Scales an array of values from specified min, max range to 0-255
#         Optionally specify the data type of the output (default is uint8)
#     """
#     return (((a - min) / float(max - min)) * 255).astype(dtype)
 
# # ==============================================================================
# #                                                         POINT_CLOUD_2_BIRDSEYE
# # ==============================================================================
# def point_cloud_2_birdseye(points,
#                            res=0.1,
#                            side_range=(-10., 10.),  # left-most to right-most
#                            fwd_range = (-10., 10.), # back-most to forward-most
#                            height_range=(-2., 2.),  # bottom-most to upper-most
#                            ):
#     """ Creates an 2D birds eye view representation of the point cloud data.
 
#     Args:
#         points:     (numpy array)
#                     N rows of points data
#                     Each point should be specified by at least 3 elements x,y,z
#         res:        (float)
#                     Desired resolution in metres to use. Each output pixel will
#                     represent an square region res x res in size.
#         side_range: (tuple of two floats)
#                     (-left, right) in metres
#                     left and right limits of rectangle to look at.
#         fwd_range:  (tuple of two floats)
#                     (-behind, front) in metres
#                     back and front limits of rectangle to look at.
#         height_range: (tuple of two floats)
#                     (min, max) heights (in metres) relative to the origin.
#                     All height values will be clipped to this min and max value,
#                     such that anything below min will be truncated to min, and
#                     the same for values above max.
#     Returns:
#         2D numpy array representing an image of the birds eye view.
#     """
#     # EXTRACT THE POINTS FOR EACH AXIS
#     x_points = points[:, 0]
#     y_points = points[:, 1]
#     z_points = points[:, 2]
#     # FILTER - To return only indices of points within desired cube
#     # Three filters for: Front-to-back, side-to-side, and height ranges
#     # Note left side is positive y axis in LIDAR coordinates
#     f_filt = np.logical_and((x_points > fwd_range[0]), (x_points < fwd_range[1]))
#     s_filt = np.logical_and((y_points > -side_range[1]), (y_points < -side_range[0]))
#     filter = np.logical_and(f_filt, s_filt)
#     indices = np.argwhere(filter).flatten()
#     # KEEPERS
#     x_points = x_points[indices]
#     y_points = y_points[indices]
#     z_points = z_points[indices]
#     # CONVERT TO PIXEL POSITION VALUES - Based on resolution
#     x_img = (-y_points / res).astype(np.int32)  # x axis is -y in LIDAR
#     y_img = (-x_points / res).astype(np.int32)  # y axis is -x in LIDAR
#     # SHIFT PIXELS TO HAVE MINIMUM BE (0,0)
#     # floor & ceil used to prevent anything being rounded to below 0 after shift
#     x_img -= int(np.floor(side_range[0] / res))
#     y_img += int(np.ceil(fwd_range[1] / res))
#     # CLIP HEIGHT VALUES - to between min and max heights
#     pixel_values = np.clip(a=z_points,
#                            a_min=height_range[0],
#                            a_max=height_range[1])
#     # RESCALE THE HEIGHT VALUES - to be between the range 0-255
#     pixel_values = scale_to_255(pixel_values,
#                                 min=height_range[0],
#                                 max=height_range[1])
#     # INITIALIZE EMPTY ARRAY - of the dimensions we want
#     x_max = 1 + int((side_range[1] - side_range[0]) / res)
#     y_max = 1 + int((fwd_range[1] - fwd_range[0]) / res)
#     im = np.zeros([y_max, x_max], dtype=np.uint8)
#     # FILL PIXEL VALUES IN IMAGE ARRAY
#     im[y_img, x_img] = pixel_values
 
#     return im

# import torch
# import torchvision
# import os
# import torchvision.transforms as transforms
# import torch.utils.data as data
# import numpy as np
# from torch.autograd import Variable
# import torch.nn as nn
# import torch.nn.functional as F
# import torch.optim as optim
# import argparse
# import random
# from PIL import Image
# import matplotlib.pyplot as plt
# import cv2
# from models.MonodepthModel import *
# from models.PWC_net import *
# from models.PWC_net import PWCDCNet
# from models.PWC_depth_net import *
# from models.PWC_depth_net import PWCDCNet_Disp
# from utils.scene_dataloader import *
# from utils.utils import *
# from utils.evaluation_utils import *
# from PIL import Image
# from models.networks.submodules import *
# from models.networks.resample2d_package.resample2d import Resample2d
# import imageio

# os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# def convertOptRGB(optical_flow):
#     ####
#     # 超时空这里的 0 1 即 x,y 方向上的维度反了
#     ####

#     blob_x = optical_flow[1]
#     blob_y = optical_flow[0]

#     hsv = np.zeros((blob_x.shape[0], blob_y.shape[1], 3), np.uint8)
#     mag, ang = cv2.cartToPolar(blob_x, blob_y)
#     hsv[..., 0] = ang * 180 / np.pi / 2
#     hsv[..., 1] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)
#     hsv[..., 2] = 255
#     bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

#     result = np.zeros((blob_x.shape[0], blob_x.shape[1], 3), np.uint8)
#     result[:, :, 0] = bgr[:, :, 2]
#     result[:, :, 1] = bgr[:, :, 1]
#     result[:, :, 2] = bgr[:, :, 0]

#     return result

# def warp(x, flo):
#     """
#     warp an image/tensor (im2) back to im1, according to the optical flow
#     x: [B, C, H, W] (im2)
#     flo: [B, 2, H, W] flow
#     """
#     B, C, H, W = x.size()
#     B_f, C_f, H_f, W_f = flo.size()
#     # mesh grid
#     if C_f == 1:
#         flo = torch.cat((flo, torch.zeros_like(flo)), 1)
#     xx = torch.arange(0, W).view(1, -1).repeat(H, 1)
#     yy = torch.arange(0, H).view(-1, 1).repeat(1, W)
#     xx = xx.view(1, 1, H, W).repeat(B, 1, 1, 1)
#     yy = yy.view(1, 1, H, W).repeat(B, 1, 1, 1)
#     grid = torch.cat((xx, yy), 1).float()

#     if x.is_cuda:
#         grid = grid.cuda()
#     vgrid = Variable(grid) + flo

#     # scale grid to [-1,1]
#     ##2019 code
#     vgrid[:, 0, :, :] = 2.0 * vgrid[:, 0, :, :].clone() / max(W - 1, 1) - 1.0
#     vgrid[:, 1, :, :] = 2.0 * vgrid[:, 1, :, :].clone() / max(H - 1, 1) - 1.0
#     vgrid = vgrid.permute(0, 2, 3, 1)
#     output = nn.functional.grid_sample(x, vgrid)
#     mask = torch.autograd.Variable(torch.ones(x.size())).cuda()
#     mask = nn.functional.grid_sample(mask, vgrid)
#     mask[mask < 0.9999] = 0
#     mask[mask > 0] = 1
#     return output * mask

# def get_args():
#     parser = argparse.ArgumentParser()
    
#     parser.add_argument('--data_path',                 type=str,   help='path to the data', required=True)
#     parser.add_argument('--load_2012_kitti_data_path',                 type=str,   help='path to the data', default="/home/HTY_user/dataset/KITTI/kitti_2012_flow/")
#     parser.add_argument('--load_2015_kitti_data_path',                 type=str,   help='path to the data', default="/home/HTY_user/dataset/KITTI/kitti_2015_flow/")
#     parser.add_argument('--load_2012_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/2012.txt")
#     parser.add_argument('--load_2015_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/2015.txt")
#     parser.add_argument('--input_height',              type=int,   help='input height', default=320)
#     parser.add_argument('--input_width',               type=int,   help='input width', default=896)
#     parser.add_argument('--min_depth',           type=float, help='minimum depth for evaluation',        default=1e-3)
#     parser.add_argument('--max_depth',           type=float, help='maximum depth for evaluation',        default=80)
#     parser.add_argument('--checkpoint_path',           type=str,   help='path to a specific checkpoint to load', required=True)
#     parser.add_argument('--result_path',           type=str,   help='path to a save result', required=True)
#     args = parser.parse_args()
#     return args

# args = get_args()
# test_kitti_2012 = True
# test_kitti_2015 = True
# test_2012_flow = True
# test_2012_depth = True
# test_2012_rigid_flow = False
# test_2015_flow = True
# test_2015_depth = True
# test_2015_rigid_flow = False
# vis_diff = False
# save_dir = args.result_path + "test.txt"
# KITTI2012_image_path = args.result_path + "KITTI2012/"
# KITTI2015_image_path = args.result_path + "KITTI2015/"
# print("begin to test")
# f2 = open(save_dir,'a+')
# f2.write("The model is : "+args.checkpoint_path+ "\n")
# ###########load model##################
# checkpoint = torch.load(args.checkpoint_path)
# net = pwc_dc_disp_net().cuda()
# net.load_state_dict(checkpoint['state_dict'])

# if test_kitti_2012==True:
#     print ("begin to test kitti 2012!" + "\n")
#     left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, flow_noc, flow_occ, disp, K = \
#         get_test_data(args.load_2012_filenames_file, args.data_path)

#     TestImageLoader = torch.utils.data.DataLoader(
#             myImageFolder_test(left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, flow_noc, flow_occ, disp, K, args),
#             batch_size = 1, shuffle = False, num_workers = 1, drop_last =False)
#     #index = [0,5,23,27,30,68,69,74,81,86,88,95,98,109,119,129,147,150,157,180,190]

    

#     total_error_noc = fl_error_noc = total_error_occ = fl_error_occ = 0.0
#     rig_total_error_noc = rig_fl_error_noc = rig_total_error_occ = rig_fl_error_occ = 0.0
#     num_test = 0
#     ave_rms = ave_log_rms = ave_abs_rel = ave_sq_rel = ave_a1 = ave_a2 = ave_a3 = 0.0
#     rms = log_rms = abs_rel= sq_rel = a1 = a2 = a3 = 0.0

#     for batch_idx, (left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2,
#          f_noc, mask_noc, f_occ, mask_occ, disp_gt, h, w, K) in enumerate(TestImageLoader, 0):

#         # print (K.shape)

#         K_pyramid, K_inv_pyramid = make_pyramid_k(K.float().cuda(),K.inverse().float().cuda() ,1)

#         model_input = Variable(torch.cat((left_image_test_1, left_image_test_2, right_image_test_1),1).cuda())    
#         optical_flow, disparity, pose  = net(model_input, flag = 0, pose_flag=0)

#         if test_2012_depth == True:
#             pre_dis = -disparity[0][0,0,:,:].data.cpu().numpy()
#             gt_depth, pred_depth = convert_disps_to_depths_kitti_k(disp_gt[0].numpy(), pre_dis, args.input_width)
#             pred_depth[pred_depth < args.min_depth] = args.min_depth
#             pred_depth[pred_depth > args.max_depth] = args.max_depth
#             mask_dis = (disp_gt[0].numpy()>0) & (gt_depth > args.min_depth) & (gt_depth < args.max_depth)
#             abs_rel, sq_rel, rms, log_rms, a1, a2, a3 = compute_errors(gt_depth[mask_dis], pred_depth[mask_dis])
#             ave_abs_rel += abs_rel
#             ave_sq_rel += sq_rel
#             ave_rms += rms
#             ave_log_rms += log_rms
#             ave_a1 += a1
#             ave_a2 += a2
#             ave_a3 += a3
#         if test_2012_flow == True:
#             mask_noc = np.ceil(np.clip(np.abs(f_noc[0,0]), 0, 1))
#             mask_occ = np.ceil(np.clip(np.abs(f_occ[0,0]), 0, 1))
#             disp_ori_scale = F.interpolate(optical_flow[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
#             disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
#             disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height
#             # if batch_idx in index:
#             #     error_noc = 0
#             #     fl_noc = 0
#             #     error_occ = 0
#             #     fl_occ =0
#             # else:
#             #     error_noc, fl_noc = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_noc[0].numpy(),
#             #                                       (mask_noc).numpy())
#             #     error_occ, fl_occ = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_occ[0].numpy(),
#             #                                       (mask_occ).numpy())
#             error_noc, fl_noc = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_noc[0].numpy(), mask_noc.numpy())
#             total_error_noc += error_noc
#             fl_error_noc += fl_noc

#             error_occ, fl_occ = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_occ[0].numpy(), mask_occ.numpy())
#             total_error_occ += error_occ
#             fl_error_occ += fl_occ
#         if test_2012_rigid_flow == True:
#             # print (disparity[0].shape) cal_multi_rigid_flow
#             # print (pose[0].shape)
#             # print (pose[0][0,:,:,:])
#             # pose_one = torch.mean(torch.mean(pose[0],dim = 2,keepdim=True), dim = 3,keepdim=True)
#             # print (pose_one)
#             # up_scene0_r_3 = F.interpolate(pose_one[:, 0:3, :, :], [3, 7], mode='bilinear',
#             #                         align_corners=True)
#             # up_scene0_t_3 = F.interpolate(pose_one[:, 3:, :, :] , [3, 7], mode='bilinear',
#             #                         align_corners=True)
#             # pose_up_3 = [torch.cat((up_scene0_r_3,up_scene0_t_3), 1)]

#             # up_scene0_r_2 = F.interpolate(pose_up_3[0][:, 0:3, :, :], [80, 224], mode='bilinear',
#             #                         align_corners=True)
#             # up_scene0_t_2 = F.interpolate(pose_up_3[0][:, 3:, :, :] , [80, 224], mode='bilinear',
#             #                         align_corners=True)
#             # pose_up_2 = [torch.cat((up_scene0_r_2,up_scene0_t_2), 1)]

#             # up_scene0_r_1 = F.interpolate(pose_up_2[0][:, 0:3, :, :], [160, 448], mode='bilinear',
#             #                         align_corners=True)
#             # up_scene0_t_1 = F.interpolate(pose_up_2[0][:, 3:, :, :] , [160, 448], mode='bilinear',
#             #                         align_corners=True)
#             # pose_up_1 = [torch.cat((up_scene0_r_1,up_scene0_t_1), 1)]

#             # up_scene0_r_0 = F.interpolate(pose_up_1[0][:, 0:3, :, :], [320, 896], mode='bilinear',
#             #                         align_corners=True)
#             # up_scene0_t_0 = F.interpolate(pose_up_1[0][:, 3:, :, :] , [320, 896], mode='bilinear',
#             #                         align_corners=True)
#             # pose_up_0 = [torch.cat((up_scene0_r_0,up_scene0_t_0), 1)]
#             # print ("xxx")
#             # print (pose_up[0][0,:,100:101,300:301])
#             # xxx
#             # rigid_flow = cal_multi_rigid_flow(disparity, pose_up_0, K_pyramid, K_inv_pyramid, 1)
#             rigid_flow = cal_rigid_flow(disparity, pose, K_pyramid, K_inv_pyramid, 1)
#             # xxx
#             mask_noc = np.ceil(np.clip(np.abs(f_noc[0,0]), 0, 1))
#             mask_occ = np.ceil(np.clip(np.abs(f_occ[0,0]), 0, 1))
#             disp_ori_scale_r = F.interpolate(rigid_flow[0][:], [int(h), int(w)], mode='bilinear', align_corners=True)
#             disp_ori_scale_r[0,0] = disp_ori_scale_r[0,0] * int(w) / args.input_width
#             disp_ori_scale_r[0,1] = disp_ori_scale_r[0,1] * int(h) / args.input_height
#             # if batch_idx in index:
#             #     rig_error_noc, rig_fl_noc = 0, 0
#             #     rig_error_occ, rig_fl_occ = 0, 0
#             # else:
#             #     rig_error_noc, rig_fl_noc = evaluate_flow(disp_ori_scale_r[0].data.cpu().numpy(), f_noc[0].numpy(),
#             #                                               (mask_noc).numpy())
#             #     rig_error_occ, rig_fl_occ = evaluate_flow(disp_ori_scale_r[0].data.cpu().numpy(), f_occ[0].numpy(),
#             #                                               (mask_occ).numpy())
#             rig_error_noc, rig_fl_noc = evaluate_flow(disp_ori_scale_r[0].data.cpu().numpy(), f_noc[0].numpy(), mask_noc.numpy())
#             rig_total_error_noc += rig_error_noc
#             rig_fl_error_noc += rig_fl_noc

#             rig_error_occ, rig_fl_occ = evaluate_flow(disp_ori_scale_r[0].data.cpu().numpy(), f_occ[0].numpy(), mask_occ.numpy())
#             rig_total_error_occ += rig_error_occ
#             rig_fl_error_occ += rig_fl_occ
#         if vis_diff:
#             left_image = cv2.cvtColor((left_image_test_1[0] * 255.0).permute(1, 2, 0).numpy(), cv2.COLOR_RGB2BGR)
#             cv2.imwrite(KITTI2012_image_path + "{}".format(batch_idx).zfill(6) + '.png', left_image)
#             flow_diff_or = disp_ori_scale - disp_ori_scale_r
#             image_ = flow_diff_or[0]
#             image_[image_<0.5]=0.0
#             image = image_.data.cpu().numpy()
#             flow_image = convertOptRGB(image)
#             # print("image--size",image.shape)
#             # print("flow_image--size",flow_image.shape)
#             cv2.imwrite(KITTI2012_image_path + "{}".format(batch_idx).zfill(6) + 'or.png', flow_image)
#             flow_diff_og = ((disp_ori_scale[0].data.cpu()-f_occ[0]) * mask_occ).numpy()
#             # image_ = flow_diff_og[0]
#             # image = image_.data.cpu().numpy()
#             flow_image = convertOptRGB(flow_diff_og)
#             # print("image--size",image.shape)
#             # print("flow_image--size",flow_image.shape)
#             cv2.imwrite(KITTI2012_image_path + "{}".format(batch_idx).zfill(6) + 'og.png', flow_image)
#             flow_diff_rg = ((disp_ori_scale_r[0].data.cpu()-f_occ[0]) * mask_occ).numpy()
#             flow_image = convertOptRGB(flow_diff_rg)
#             # print("image--size",image.shape)
#             # print("flow_image--size",flow_image.shape)
#             cv2.imwrite(KITTI2012_image_path + "{}".format(batch_idx).zfill(6) + 'rg.png', flow_image)

#             flow_diff_org = torch.abs(disp_ori_scale[0].data.cpu()-f_occ[0]) - torch.abs(disp_ori_scale_r[0].data.cpu() - f_occ[0])
#             flow_diff_org[torch.abs(flow_diff_org) < 0.5] = 0.0
#             flow_diff_org = (flow_diff_org* mask_occ).numpy()
#             flow_image = convertOptRGB(flow_diff_org)
#             # print("image--size",image.shape)
#             # print("flow_image--size",flow_image.shape)
#             cv2.imwrite(KITTI2012_image_path + "{}".format(batch_idx).zfill(6) + 'org.png', flow_image)



#         num_test += 1
#     if test_2012_flow == True:
#         total_error_noc /= num_test
#         fl_error_noc /= num_test
#         # total_error_noc /= (num_test-len(index))
#         # fl_error_noc /= (num_test-len(index))
#         print("The 2012 noc average EPE is : ", total_error_noc)
#         print("The average Fl is : ", fl_error_noc)
#         f2.write("The 2012 noc average EPE is : "+str(total_error_noc)+ "\n")
#         f2.write("The average Fl is : "+str(fl_error_noc)+ "\n")

#         # total_error_occ /= num_test
#         # fl_error_occ /= num_test
#         total_error_occ /= (num_test)
#         fl_error_occ /= (num_test)
#         print("The 2012 occ average EPE is : ", total_error_occ)
#         print("The average Fl is : ", fl_error_occ)
#         f2.write("The 2012 occ average EPE is : "+str(total_error_occ)+ "\n")
#         f2.write("The average Fl is : "+str(fl_error_occ)+ "\n")
#     if test_2012_rigid_flow == True:
#         rig_total_error_noc /= (num_test)
#         rig_fl_error_noc /= (num_test)
#         print("The 2012 rigid flow noc average EPE is : ", rig_total_error_noc)
#         print("The average Fl is : ", rig_fl_error_noc)
#         f2.write("The 2012 rigid flow noc average EPE is : "+str(rig_total_error_noc)+ "\n")
#         f2.write("The average Fl is : "+str(rig_fl_error_noc)+ "\n")

#         rig_total_error_occ /= (num_test)
#         rig_fl_error_occ /= (num_test)
#         print("The 2012 rigid flow occ average EPE is : ", rig_total_error_occ)
#         print("The average Fl is : ", rig_fl_error_occ)
#         f2.write("The 2012 rigid flow occ average EPE is : "+str(rig_total_error_occ)+ "\n")
#         f2.write("The average Fl is : "+str(rig_fl_error_occ)+ "\n")
#     if test_2012_depth == True:
#         ave_abs_rel  /= num_test
#         ave_sq_rel  /= num_test
#         ave_rms  /= num_test
#         ave_log_rms  /= num_test
#         ave_a1  /= num_test
#         ave_a2  /= num_test
#         ave_a3  /= num_test
#         print("The 2012 depth test is :")
#         print("{:>10}, {:>10}, {:>10}, {:>10}, {:>10}, {:>10}, {:>10}".format('abs_rel', 'sq_rel', 'rms', 'log_rms', 'a1', 'a2', 'a3'))
#         print("{:10.4f}, {:10.4f}, {:10.3f}, {:10.3f}, {:10.3f}, {:10.3f}, {:10.3f}".format(ave_abs_rel, ave_sq_rel, ave_rms, ave_log_rms, ave_a1, ave_a2, ave_a3))
    
#         f2.write("The 2012 depth test is :")
#         f2.write("{:>10}, {:>10}, {:>10}, {:>10}, {:>10}, {:>10}, {:>10}".format('abs_rel', 'sq_rel', 'rms', 'log_rms',
#                                                                               'a1', 'a2', 'a3') + "\n")
#         f2.write("{:10.4f}, {:10.4f}, {:10.3f}, {:10.3f}, {:10.3f}, {:10.3f}, {:10.3f}".format(ave_abs_rel,
#                                                                                               ave_sq_rel,
#                                                                                               ave_rms,
#                                                                                               ave_log_rms,
#                                                                                               ave_a1, 
#                                                                                               ave_a2,
#                                                                                               ave_a3) + "\n")


# if test_kitti_2015==True:
#     print ("begin to test kitti 2015!" + "\n")
#     left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, flow_noc, flow_occ, disp, K, obj= \
#         get_2015_test_data(args.load_2015_filenames_file, args.data_path)

#     TestImageLoader = torch.utils.data.DataLoader(
#             myImageFolder_2015_test(left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, flow_noc, flow_occ, disp, K, obj, args),
#             batch_size = 1, shuffle = False, num_workers = 1, drop_last =False)

#     total_error_noc = fl_error_noc = total_error_occ = fl_error_occ = 0.0
#     num_test = 0
#     rig_total_error_noc = rig_fl_error_noc = rig_total_error_occ = rig_fl_error_occ = 0.0
#     ave_rms = ave_log_rms = ave_abs_rel = ave_sq_rel = ave_a1 = ave_a2 = ave_a3 = 0.0
#     rms = log_rms = abs_rel= sq_rel = a1 = a2 = a3 = 0.0

#     for batch_idx, (left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2,
#          f_noc, mask_noc, f_occ, mask_occ, disp_gt, h, w, K, obj_mask) in enumerate(TestImageLoader, 0):
#         K_pyramid, K_inv_pyramid = make_pyramid_k(K.float().cuda(), K.inverse().float().cuda(), 1)

#         model_input = Variable(torch.cat((left_image_test_1, left_image_test_2, right_image_test_1),1).cuda())    
#         optical_flow, disparity, pose  = net(model_input, flag = 0,pose_flag=0)

#         left_image_op = warp(left_image_test_2.cuda(), optical_flow[0])
#         left_image_op = left_image_op[0].detach().permute(1, 2, 0).cpu().numpy()
#         left_image_op = cv2.cvtColor((left_image_op * 255.0),
#                                      cv2.COLOR_RGB2BGR)
#         cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'o.png', left_image_op)

#         obj_mask[obj_mask<0.5]=0.0
#         obj_mask[obj_mask>=0.5]=1.0

#         if test_2015_depth == True:
#             pre_dis = -disparity[0][0,0,:,:].data.cpu().numpy()
#             # print (pre_dis)
#             gt_depth, pred_depth = convert_disps_to_depths_kitti_k(disp_gt[0].numpy(), pre_dis, args.input_width)
#             pred_depth[pred_depth < args.min_depth] = args.min_depth
#             pred_depth[pred_depth > args.max_depth] = args.max_depth
#             mask_dis =  (disp_gt[0].numpy()>0) &(gt_depth > args.min_depth) & (gt_depth < args.max_depth)
#             abs_rel, sq_rel, rms, log_rms, a1, a2, a3 = compute_errors(gt_depth[mask_dis], pred_depth[mask_dis])
#             ave_abs_rel += abs_rel
#             ave_sq_rel += sq_rel
#             ave_rms += rms
#             ave_log_rms += log_rms
#             ave_a1 += a1
#             ave_a2 += a2
#             ave_a3 += a3

#             # plt.imsave('/home/HTY_3_user/cc/model/vis/{}_disp.png'.format(batch_idx), pred_depth, cmap='plasma')

#         if test_2015_flow == True:
#             mask_noc = np.ceil(np.clip(np.abs(f_noc[0,0]), 0, 1))
#             mask_occ = np.ceil(np.clip(np.abs(f_occ[0,0]), 0, 1))
#             disp_ori_scale = F.interpolate(optical_flow[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
#             disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
#             disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height


#             error_noc, fl_noc = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_noc[0].numpy(), (mask_noc).numpy())
#             total_error_noc += error_noc
#             fl_error_noc += fl_noc

#             error_occ, fl_occ = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_occ[0].numpy(), (mask_occ).numpy())
#             total_error_occ += error_occ
#             fl_error_occ += fl_occ
#             # plt.imsave('/home/HTY_3_user/cc/model/vis/{}_flow.png'.format(batch_idx), disp_ori_scale[0,0].data.cpu().numpy(), cmap='plasma')
        
#         if test_2015_rigid_flow == True:
#             # print (disparity[0].shape)
#             rigid_flow = cal_rigid_flow(disparity, pose, K_pyramid, K_inv_pyramid, 1)

#             left_image_rigid = warp(left_image_test_2.cuda(), rigid_flow[0])
#             left_image_rigid = left_image_rigid[0].detach().permute(1, 2, 0).cpu().numpy()
#             left_image_rigid = cv2.cvtColor((left_image_rigid * 255.0),
#                                             cv2.COLOR_RGB2BGR)
#             cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'r.png', left_image_rigid)

#             mask_noc = np.ceil(np.clip(np.abs(f_noc[0,0]), 0, 1))
#             mask_occ = np.ceil(np.clip(np.abs(f_occ[0,0]), 0, 1))
#             disp_ori_scale_r = F.interpolate(rigid_flow[0][:], [int(h), int(w)], mode='bilinear', align_corners=True)
#             disp_ori_scale_r[0,0] = disp_ori_scale_r[0,0] * int(w) / args.input_width
#             disp_ori_scale_r[0,1] = disp_ori_scale_r[0,1] * int(h) / args.input_height


#             rig_error_noc, rig_fl_noc = evaluate_flow(disp_ori_scale_r[0].data.cpu().numpy(), f_noc[0].numpy(), (mask_noc).numpy())
#             rig_total_error_noc += rig_error_noc
#             rig_fl_error_noc += rig_fl_noc

#             rig_error_occ, rig_fl_occ = evaluate_flow(disp_ori_scale_r[0].data.cpu().numpy(), f_occ[0].numpy(), (mask_occ).numpy())
#             rig_total_error_occ += rig_error_occ
#             rig_fl_error_occ += rig_fl_occ
#         if vis_diff:
#             left_image = cv2.cvtColor((left_image_test_1[0] * 255.0).permute(1, 2, 0).numpy(), cv2.COLOR_RGB2BGR)
#             cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + '.png', left_image)
#             # print("00000000000")
#             # left_image_rigid = Resample2d()(left_image_test_2, disp_ori_scale_r)
#             # left_image_rigid = cv2.cvtColor((left_image_rigid[0].clone().detach() * 255.0).permute(1, 2, 0).numpy(), cv2.COLOR_RGB2BGR)
#             # cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'r.png', left_image_rigid)
#             # print("111111111111")
#             # left_image_op = Resample2d()(left_image_test_2, disp_ori_scale)
#             # left_image_op = cv2.cvtColor((left_image_op[0].clone().detach() * 255.0).permute(1, 2, 0).numpy(), cv2.COLOR_RGB2BGR)
#             # cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'r.png', left_image_op)

#             # flow_diff_or = disp_ori_scale - disp_ori_scale_r
#             # image_ = flow_diff_or[0]
#             # flow_diff = torch.norm(image_, p=2, dim=0, keepdim=True)
#             # flow_diff_mask_i = (flow_diff < 3.0).float()
#             # image_ = image_ * flow_diff_mask_i
#             # flow_diff_mask = flow_diff_mask_i.squeeze(0) * 255.0
#             # image = image_.data.cpu().numpy()
#             # flow_image = convertOptRGB(image)

#             flow_r = disp_ori_scale_r[0].data.cpu().numpy()
#             flow_r = convertOptRGB(flow_r)
#             cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'rf.png', flow_r)

#             flow_o = disp_ori_scale[0].data.cpu().numpy()
#             flow_o = convertOptRGB(flow_o)
#             cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'of.png', flow_o)

#             # cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'mask.png', flow_diff_mask.data.cpu().numpy())
#             # cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'or.png', flow_image)
#             # flow_diff_og = ((disp_ori_scale[0].data.cpu() - f_occ[0]) * mask_occ).numpy()
#             #
#             # flow_image = convertOptRGB(flow_diff_og)
#             #
#             # cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'og.png', flow_image)
#             # flow_diff_rg = ((disp_ori_scale_r[0].data.cpu() - f_occ[0]) * mask_occ).numpy()
#             # flow_image = convertOptRGB(flow_diff_rg)
#             #
#             # cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'rg.png', flow_image)
#             # flow_diff_org = torch.abs(disp_ori_scale[0].data.cpu() - f_occ[0]) - torch.abs(
#             #     disp_ori_scale_r[0].data.cpu() - f_occ[0])
#             # flow_diff_org[torch.abs(flow_diff_org) < 0.5] = 0.0
#             # flow_diff_org = (flow_diff_org * mask_occ).numpy()
#             # flow_image = convertOptRGB(flow_diff_org)
#             # cv2.imwrite(KITTI2015_image_path + "{}".format(batch_idx).zfill(6) + 'org.png', flow_image)

#         num_test += 1
#     if test_2015_flow == True:
#         total_error_noc /= num_test
#         fl_error_noc /= num_test
#         print("The 2015 noc average EPE is : ", total_error_noc)
#         print("The average Fl is : ", fl_error_noc)
#         f2.write("The 2015 noc average EPE is : "+str(total_error_noc)+ "\n")
#         f2.write("The average Fl is : "+str(fl_error_noc)+ "\n")

#         total_error_occ /= num_test
#         fl_error_occ /= num_test
#         print("The 2015 occ average EPE is : ", total_error_occ)
#         print("The average Fl is : ", fl_error_occ)
#         f2.write("The 2015 occ average EPE is : "+str(total_error_occ)+ "\n")
#         f2.write("The average Fl is : "+str(fl_error_occ)+ "\n")

#     if test_2015_rigid_flow == True:
#         rig_total_error_noc /= num_test
#         rig_fl_error_noc /= num_test
#         print("The 2015 rigid flow noc average EPE is : ", rig_total_error_noc)
#         print("The average Fl is : ", rig_fl_error_noc)
#         f2.write("The 2015 rigid flow noc average EPE is : "+str(rig_total_error_noc)+ "\n")
#         f2.write("The average Fl is : "+str(rig_fl_error_noc)+ "\n")

#         rig_total_error_occ /= num_test
#         rig_fl_error_occ /= num_test
#         print("The 2015 rigid flow occ average EPE is : ", rig_total_error_occ)
#         print("The average Fl is : ", rig_fl_error_occ)
#         f2.write("The 2015 rigid flow occ average EPE is : "+str(rig_total_error_occ)+ "\n")
#         f2.write("The average Fl is : "+str(rig_fl_error_occ)+ "\n")
#     if test_2015_depth == True:
#         ave_abs_rel  /= num_test
#         ave_sq_rel  /= num_test
#         ave_rms  /= num_test
#         ave_log_rms  /= num_test
#         ave_a1  /= num_test
#         ave_a2  /= num_test
#         ave_a3  /= num_test
#         print("The 2015 depth test is :")
#         print("{:>10}, {:>10}, {:>10}, {:>10}, {:>10}, {:>10}, {:>10}".format('abs_rel', 'sq_rel', 'rms', 'log_rms', 'a1', 'a2', 'a3'))
#         print("{:10.4f}, {:10.4f}, {:10.3f}, {:10.3f}, {:10.3f}, {:10.3f}, {:10.3f}".format(ave_abs_rel, ave_sq_rel, ave_rms, ave_log_rms, ave_a1, ave_a2, ave_a3))
    
#         f2.write("The 2015 depth test is :")
#         f2.write("{:>10}, {:>10}, {:>10}, {:>10}, {:>10}, {:>10}, {:>10}".format('abs_rel', 'sq_rel', 'rms', 'log_rms',
#                                                                               'a1', 'a2', 'a3') + "\n")
#         f2.write("{:10.4f}, {:10.4f}, {:10.3f}, {:10.3f}, {:10.3f}, {:10.3f}, {:10.3f}".format(ave_abs_rel,
#                                                                                               ave_sq_rel,
#                                                                                               ave_rms,
#                                                                                               ave_log_rms,
#                                                                                               ave_a1, 
#                                                                                               ave_a2,
#                                                                                               ave_a3) + "\n")



# # def cal_one_pose_matrix(pose, num_scales):
# #     def _euler_to_mat(rot_euler):
# #         x = rot_euler[:,:,:, 0]
# #         y = rot_euler[:,:,:, 1]
# #         z = rot_euler[:,:,:, 2]
# #         zeros = torch.zeros_like(x).unsqueeze(3)
# #         ones = torch.ones_like(x).unsqueeze(3)

# #         cosz = torch.cos(z).unsqueeze(3)
# #         sinz = torch.sin(z).unsqueeze(3)
# #         rotz_1 = torch.cat([cosz, -sinz, zeros], 3).unsqueeze(3)
# #         rotz_2 = torch.cat([sinz, cosz, zeros], 3).unsqueeze(3)
# #         rotz_3 = torch.cat([zeros, zeros, ones], 3).unsqueeze(3)
# #         zmat = torch.cat((rotz_1, rotz_2, rotz_3), 3)

# #         cosy = torch.cos(y).unsqueeze(3)
# #         siny = torch.sin(y).unsqueeze(3)
# #         roty_1 = torch.cat([cosy, zeros, siny], 3).unsqueeze(3)
# #         roty_2 = torch.cat([zeros, ones, zeros], 3).unsqueeze(3)
# #         roty_3 = torch.cat([-siny, zeros, cosy], 3).unsqueeze(3)
# #         ymat = torch.cat((roty_1, roty_2, roty_3), 3)

# #         cosx = torch.cos(x).unsqueeze(3)
# #         sinx = torch.sin(x).unsqueeze(3)
# #         rotx_1 = torch.cat([ones, zeros, zeros], 3).unsqueeze(3)
# #         rotx_2 = torch.cat([zeros, cosx, -sinx], 3).unsqueeze(3)
# #         rotx_3 = torch.cat([zeros, sinx, cosx], 3).unsqueeze(3)
# #         xmat = torch.cat((rotx_1, rotx_2, rotx_3), 3)



# #         rotMat = torch.matmul(torch.matmul(xmat, ymat), zmat)


# #         return rotMat

# #     pose_matrix = []
# #     for i in range(num_scales):


# #         B,_,H,W = pose[i].shape
# #         swap = torch.mean(torch.mean(pose[i],dim = 2,keepdim=True), dim = 3,keepdim=True).permute(0,2,3,1)
# #         rotMat = _euler_to_mat(swap[:,:,:, 0:3])
# #         # print (rotMat.shape)#2, 320, 896, 3, 3
# #         translation = (swap[:,:,:, 3:]).unsqueeze(4)
# #         filler = torch.tensor([[[0.0, 0.0, 0.0, 1.0]]])
# #         filler = filler.repeat([B,1,1, 1, 1]).cuda()
# #         swapp = torch.cat((torch.cat((rotMat, translation), 4), filler), 3)

# #         pose_matrix.append(swapp)

# #     return pose_matrix
# # def dis_to_depth_to_3D(disparity, K_pyramid, K_inv_pyramid, num_scales):
# #     def _dis_to_depth(disparity, K_pyramid, num_scales):
# #         depth = []
# #         for i in range(num_scales):
# #             depth_3d = torch.abs(disparity[i][:, 0:1, :, :].permute(0,2,3,1))#.clone().detach()
# #             B,H,W,_ = depth_3d.size()
# #             baseline = torch.tensor(0.54)
# #             fx = K_pyramid[i][:, 0, 0].unsqueeze(1).unsqueeze(1).unsqueeze(1)
# #             depth_3d_0 = baseline * fx  / depth_3d
# #             depth_3d_0[depth_3d_0 > 100] = 100
# #             depth_3d_0[depth_3d_0 < 0] = 0.0001
# #             depth.append(depth_3d_0)
# #         return depth

# #     depth = _dis_to_depth(disparity, K_pyramid, num_scales)
# #     point_3d = []
# #     for i in range(num_scales):
# #         B,H,W = disparity[i][:, 0, :, :].size()
# #         xx = torch.arange(0, W).view(1,-1).repeat(H,1)
# #         yy = torch.arange(0, H).view(-1,1).repeat(1,W)
# #         xx = xx.view(1,H,W).repeat(1,1,1).unsqueeze(1)
# #         yy = yy.view(1,H,W).repeat(1,1,1).unsqueeze(1)
# #         zz = torch.ones_like(xx)
# #         grid = torch.cat((xx,yy,zz),1).float().cuda()
# #         grid = grid.repeat([B, 1, 1, 1]).permute(0,2,3,1)
# #         depth_i = depth[i]
# #         P_nor = torch.mul(depth_i, grid).unsqueeze(4)
# #         K_inv_0 = K_inv_pyramid[i].unsqueeze(1).unsqueeze(1)
# #         # P_nor = P_nor.transpose(0,2).transpose(1,3).unsqueeze(4)
# #         P_0 = torch.matmul(K_inv_0, P_nor)
# #         # P_0 = P_0.transpose(0,2).transpose(1,3).squeeze(4)
# #         homogeneous = torch.ones_like(P_0[:,:, :, 0:1,:])
# #         P_homogeneous = torch.cat((P_0, homogeneous), 3)
# #         point_3d.append(P_homogeneous)

# #     return point_3d
# # def trans_3d(point_3d, pose_matrix, num_scales):
# #     point_3d_2 = []
# #     for i in range(num_scales):
# #         point_3d_2_i = torch.matmul(pose_matrix[i], point_3d[i])
# #         point_3d_2.append(point_3d_2_i)
# #     return point_3d_2
# # def cal_rigid_flow(disparity, pose, K_pyramid, K_inv_pyramid, num_scales = 5):

# #     pose_matrix = cal_one_pose_matrix(pose, num_scales)
# #     # pose_matrix = cal_multi_pose_matrix(pose, num_scales)
# #     point_3d  = dis_to_depth_to_3D(disparity, K_pyramid, K_inv_pyramid, num_scales)
# #     point_3d_2 = trans_3d(point_3d, pose_matrix, num_scales)
# #     rigid_flow = []
# #     for i in range(num_scales):
# #         point_3d_2_i = point_3d_2[i][:, :, :, 0:3,:]
# #         K_i = K_pyramid[i].unsqueeze(1).unsqueeze(1)
# #         point_2d_i = torch.matmul(K_i, point_3d_2_i).permute(0,3,1,2,4).squeeze(4)

# #         B,H,W = point_2d_i[:, 0, :, :].size()
# #         xx = torch.arange(0, W).view(1,-1).repeat(H,1)
# #         yy = torch.arange(0, H).view(-1,1).repeat(1,W)
# #         xx = xx.view(1,H,W).repeat(1,1,1).unsqueeze(1)
# #         yy = yy.view(1,H,W).repeat(1,1,1).unsqueeze(1)
# #         grid = torch.cat((xx,yy),1).float().cuda()
# #         grid = grid.repeat([point_2d_i.shape[0], 1, 1, 1])

# #         rigid_flow_i = (point_2d_i[:, 0:2, :, :] / point_2d_i[:, 2:, :, :]).contiguous()
# #         rigid_flow.append(rigid_flow_i-grid)

# #     return rigid_flow
