import torch
import torchvision
import torchvision.transforms as transforms
import torch.utils.data as data
import numpy as np
import os
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse
import random
from PIL import Image
import matplotlib.pyplot as plt
import cv2
from models.PWC_net import *
from models.PWC_net import PWCDCNet
from utils.scene_dataloader import *
from utils.utils import *
from models.networks.submodules import *
from models.networks.resample2d_package.resample2d import Resample2d
# from epipolarloss.loss_functions import *

os.environ["CUDA_VISIBLE_DEVICES"] = "0"

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_path',                 type=str,   help='path to the data', required=True)
    parser.add_argument('--filenames_file',            type=str,   help='path to the filenames text file', default="./utils/filenames/train_08.txt")
    parser.add_argument('--pretrain_flag',             type=int,   help='pretrain or not', default=0)
    parser.add_argument('--input_height',              type=int,   help='input height', default=320)
    parser.add_argument('--input_width',               type=int,   help='input width', default=896)
    parser.add_argument('--batch_size',                type=int,   help='batch size', default=2)
    parser.add_argument('--num_epochs',                type=int,   help='number of epochs', default=180)
    parser.add_argument('--learning_rate',             type=float, help='initial learning rate', default=0.00000005)
    parser.add_argument('--lr_loss_weight',            type=float, help='left-right consistency weight', default=0.5)
    parser.add_argument('--alpha_image_loss',          type=float, help='weight between SSIM and L1 in the image loss', default=0.85)
    parser.add_argument('--disp_gradient_loss_weight', type=float, help='disparity smoothness weigth', default=0.1)
    parser.add_argument('--epipolar_loss_weight',      type=float, help='epipolar loss weigth', default=0.001)
    parser.add_argument('--pose_path',                 type=str, help='model name', default='./utils/filenames/poses/')
    parser.add_argument('--num_threads',               type=int,   help='number of threads to use for data loading', default=8)
    parser.add_argument('--checkpoint_path',           type=str,   help='path to a specific checkpoint to load', default='')
    parser.add_argument('--pretrained_checkpoint_path',type=str,   help='pretrained path to a specific checkpoint to load', default='')

    args = parser.parse_args()
    return args

args = get_args()
net = pwc_dc_net()
pose_net = pwc_pose_net()

pre_checkpoint = torch.load("flow_best")
net.load_state_dict(pre_checkpoint['state_dict'])

######
######  load pretrained model
if args.pretrain_flag == 1:
    pretrained_model_pth = args.pretrained_checkpoint_path
    if os.path.isfile(pretrained_model_pth):
        print("=> loading pretrained checkpoint path:  '{}'".format(pretrained_model_pth))
        
        pre_checkpoint = torch.load(pretrained_model_pth)
        pose_net.load_state_dict(pre_checkpoint['state_dict'])
        epoch_cur = pre_checkpoint['epoch'] + 1
        print("epoch_cur:  ",epoch_cur)
    else:
        print("=> no checkpoint found at '{}'".format(pretrained_model_pth))
else:
    epoch_cur = 0    

net.cuda()
pose_net.cuda()
for i, p in enumerate(net.parameters()):
    p.requires_grad = False

#read image from data_path/filenames_file for training
left_image_1, left_image_2, cam_intrinsic, pose_path = get_kitti_all_data(args.filenames_file, args.data_path, args.pose_path)   

#this made image data augmentation
CycleLoader = torch.utils.data.DataLoader(
         myCycleImageFolder_pose(left_image_1, left_image_2, cam_intrinsic, pose_path, False, args), 
         batch_size = args.batch_size, shuffle = True, num_workers = args.num_threads, drop_last = False)

optimizer = optim.Adam(pose_net.parameters(), lr = args.learning_rate)
scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[0], gamma=1)
# scale_weight = [0.005,0.01,0.02,0.08,0.32]
scale_weight = [1.0,1.0,1.0,1.0,1.0]
for epoch in range(epoch_cur, args.num_epochs):
    
    scheduler.step()
    
    for batch_idx, (left_image_1, left_image_2, K, K_inv, pose_gt, pose_gt_2) in enumerate(CycleLoader, 0):

        optimizer.zero_grad()            
        model_input = Variable(torch.cat((left_image_1, left_image_2),1).cuda())
        # model_input_2 = Variable(torch.cat((left_image_2, left_image_1),1).cuda())
        xx = net(model_input)
        # xx_2 = net(model_input_2)

        pose = pose_net(xx)
        # pose_2 = pose_net(xx_2)
        
        loss_1 = torch.mean(torch.norm((pose[:,0:3] - pose_gt[:,0:3].float().cuda()), p=2, dim=1, keepdim=True))# + torch.mean(torch.norm((pose_2[:,0:3] - pose_gt_2[:,0:3].float().cuda()), p=2, dim=1, keepdim=True))
        loss_2 = torch.mean(torch.norm((pose[:,3:] - pose_gt[:,3:].float().cuda()), p=2, dim=1, keepdim=True)) #+ torch.mean(torch.norm((pose_2[:,3:] - pose_gt_2[:,3:].float().cuda()), p=2, dim=1, keepdim=True))    
            
        (20*loss_1+loss_2).backward()
        if batch_idx%10==0:
            print("================================")
            print("Epoch :", epoch)
            print("Batch Index :", batch_idx)
            print("  loss_1:  ", 20*loss_1)
            print("  loss_2:  ", loss_2)
       
        if batch_idx % 1000 == 0:
            state = {'epoch': epoch, 'batch_idx': batch_idx, 'state_dict': pose_net.state_dict(), 'optimizer': optimizer.state_dict(),
                     'scheduler': scheduler}
            torch.save(state, args.checkpoint_path + "model_epoch" + str(epoch) + "_" + "_idx" + str(batch_idx))
            print("The model of epoch", epoch, "_idx",batch_idx,"has been saved.")

        optimizer.step() 

    if epoch % 1 == 0:
        state = {'epoch': epoch, 'state_dict': pose_net.state_dict(), 'optimizer': optimizer.state_dict(), 'scheduler': scheduler}
        torch.save(state, args.checkpoint_path + "model_epoch" + str(epoch))
        print("The model of epoch ", epoch, "has been saved.")