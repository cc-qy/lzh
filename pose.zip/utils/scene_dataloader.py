import torch
import torchvision
import torchvision.transforms as transforms
import torchvision.transforms.functional  as  FF
import torch.utils.data as data
import numpy as np
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse
import random
from PIL import Image
import matplotlib.pyplot as plt
import cv2
import os
import math

def get_data(file_path_test, path):
    f_test = open(file_path_test)
    left_image_test = list()
    right_image_test = list()

    for line in f_test:
        left_image_test.append(path+line.split()[0])
        right_image_test.append(path+line.split()[1])
    return left_image_test, right_image_test

def get_kitti_all_data(file_path_train, path, pose_path):
    f_train = open(file_path_train)
    former_left_image_train = list()
    latter_left_image_train = list()
    # former_right_image_train = list()
    # latter_right_image_train = list()
    cam_intrinsic_path = list()
    # read from filesname_file   order is 0 2 1 3
    for line in f_train:
        former_left_image_train.append(path + line.split()[0])
        latter_left_image_train.append(path + line.split()[2])
        # former_right_image_train.append(path + line.split()[1])
        # latter_right_image_train.append(path + line.split()[3])
        cam_intrinsic_path.append(path + line.split()[4])
    pose = list()
    for i in range(11):
        pose_ = open(pose_path + str(i).zfill(2) + '.txt').readlines()
        pose.append(pose_)
    return former_left_image_train, latter_left_image_train, cam_intrinsic_path, pose

def get_kitti_depth_data(file_path_train, path, pose_path):
    f_train = open(file_path_train)
    former_left_image_train = list()
    latter_left_image_train = list()
    former_right_image_train = list()
    # latter_right_image_train = list()
    cam_intrinsic_path = list()
    # read from filesname_file   order is 0 2 1 3
    for line in f_train:
        former_left_image_train.append(path + line.split()[0])
        latter_left_image_train.append(path + line.split()[2])
        former_right_image_train.append(path + line.split()[1])
        # latter_right_image_train.append(path + line.split()[3])
        cam_intrinsic_path.append(path + line.split()[4])
    pose = list()
    for i in range(11):
        pose_ = open(pose_path + str(i).zfill(2) + '.txt').readlines()
        pose.append(pose_)
    return former_left_image_train, latter_left_image_train, former_right_image_train, cam_intrinsic_path, pose

def get_transform_test(param):
    return transforms.Compose([
        transforms.Resize([param.input_height, param.input_width]),
        transforms.ToTensor(),

    ])
def get_transform(param):
    return transforms.Compose([
        transforms.ToTensor()
        # transforms.Normalize(mean=[0,0,0], std=[255,255,255]),
        
    ])
def Resize(param):
    return transforms.Compose([
        transforms.Resize([param.input_height, param.input_width])
    ])

def mat2rot(pose_mat):
    t1 = pose_mat[0][3]
    t2 = pose_mat[1][3]
    t3 = pose_mat[2][3]
    r,_ = cv2.Rodrigues(pose_mat[0:3,0:3])
    r1 = r[0]
    r2 = r[1]
    r3 = r[2]
    rot = np.array([r1, r2, r3, t1, t2, t3]).astype(float)
    # rot = np.expand_dims(rot, axis=0)
    return rot

class myCycleImageFolder_pose(data.Dataset):
    def __init__(self, left_image_train_00, left_image_train_01, cam_intrinsic_path, pose, training, param):
        self.left_image_train_00 = left_image_train_00
        self.left_image_train_01 = left_image_train_01

        ########
        # self.right_image_train_00 = right_image_train_00
        # self.right_image_train_01 = right_image_train_01

        #######
        self.pose = pose
        self.cam_intrinsic_path = cam_intrinsic_path
        #######
        self.training = training
        self.param = param

    def __getitem__(self, index):
        left_image_train_00 = self.left_image_train_00[index]
        left_image_train_01 = self.left_image_train_01[index]
        #####
        # right_image_train_00 = self.right_image_train_00[index]
        # right_image_train_01 = self.right_image_train_01[index]

        ########
        cam_intrinsic_path = self.cam_intrinsic_path[index]

        param = self.param
        left_image_00 = Image.open(left_image_train_00).convert('RGB')
        left_image_01 = Image.open(left_image_train_01).convert('RGB')

        #######
        # right_image_00 = Image.open(right_image_train_00).convert('RGB')
        # right_image_01 = Image.open(right_image_train_01).convert('RGB')

        W, H = left_image_00.size
        # augmentation

        if self.training:

            # randomly shift gamma
            if random.uniform(0, 1) > 0.75:
                gamma = random.uniform(0.80, 1.2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) ** gamma), 0, 255).astype('uint8'),'RGB')
                left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) ** gamma), 0, 255).astype('uint8'),'RGB')

                ############
                # right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) ** gamma), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) ** gamma), 0, 255).astype('uint8'),'RGB')
   
            # randomly shift brightness
            if random.uniform(0, 1) > 0.75:
                brightness = random.uniform(0.8, 1.2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) * brightness), 0, 255).astype('uint8'),'RGB')
                left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) * brightness), 0, 255).astype('uint8'),'RGB')

                ############
                # right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) * brightness), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) * brightness), 0, 255).astype('uint8'),'RGB')

            # randomly shift color
            if random.uniform(0, 1) > 0.75:
                colors = [random.uniform(0.8, 1.2) for i in range(3)]
                shape = np.array(left_image_00).shape
                white = np.ones((shape[0], shape[1]))
                color_image = np.stack([white * colors[i] for i in range(3)], axis=2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) * color_image), 0, 255).astype('uint8'),'RGB')
                left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) * color_image), 0, 255).astype('uint8'),'RGB')

                ############
                # right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) * color_image), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) * color_image), 0, 255).astype('uint8'),'RGB')
                
        resize = Resize(param)
        left_image_00 = resize(left_image_00)
        left_image_01 = resize(left_image_01)
        #######
        # right_image_00 = resize(right_image_00)
        # right_image_01 = resize(right_image_01)

        #################
        file = open(cam_intrinsic_path, 'r')
        last_line = file.readlines()[-1]
        raw_cam_vec = np.array(list(map(float, last_line.split()[1:])))
        raw_cam_mat = np.reshape(raw_cam_vec, (3, 4))
        raw_cam_mat = raw_cam_mat[0:3, 0:3]
        #################
        width_ratio = 896.0 / W
        height_ratio = 320.0 / H
        raw_cam_mat[0, 0] = raw_cam_mat[0, 0] * width_ratio
        raw_cam_mat[0, 2] = raw_cam_mat[0, 2] * width_ratio
        raw_cam_mat[1, 1] = raw_cam_mat[1, 1] * height_ratio
        raw_cam_mat[1, 2] = raw_cam_mat[1, 2] * height_ratio
        #############################
        K = raw_cam_mat
        K_inv = np.linalg.inv(raw_cam_mat)
        ###########pose
        i = int(left_image_train_00.split('/')[-3])
        j = int(left_image_train_00.split('/')[-1].split('.')[0])
        pose1 = self.pose[i][j]
        i = int(left_image_train_01.split('/')[-3])
        j = int(left_image_train_01.split('/')[-1].split('.')[0])
        pose2 = self.pose[i][j]
        pose1_mat = np.array(list(map(float, pose1.split())))
        pose1_mat = np.reshape(pose1_mat, (3, 4))
        temp = np.reshape(np.array([0,0,0,1]),(1,4))
        pose1_mat = np.concatenate((pose1_mat, temp), 0)
        pose2_mat = np.array(list(map(float, pose2.split())))
        pose2_mat = np.reshape(pose2_mat, (3, 4))
        pose2_mat = np.concatenate((pose2_mat, temp), 0)
        pose_01_mat = np.dot(np.linalg.inv(pose2_mat), pose1_mat)
        pose_10_mat = np.linalg.inv(pose_01_mat)
        pose_01_mat = mat2rot(pose_01_mat)
        pose_10_mat = mat2rot(pose_10_mat)

        #########
        process = get_transform(param)
        left_image_00 = process(left_image_00)
        left_image_01 = process(left_image_01)
        #######
        # right_image_00 = process(right_image_00)
        # right_image_01 = process(right_image_01)

        return left_image_00, left_image_01, K, K_inv, pose_01_mat, pose_10_mat

    def __len__(self):
        return len(self.left_image_train_00)

class myImageFolder(data.Dataset):
    def __init__(self, left, right, flow, param):
        self.right = right
        self.left = left
        self.flow = flow
        self.param = param
        
    def __getitem__(self, index):
        left = self.left[index]
        right = self.right[index]
        param = self.param
        left_image = Image.open(left).convert('RGB')
        right_image = Image.open(right).convert('RGB')

      
        process = get_transform_test(param)
        left_image = process(left_image)
        right_image = process(right_image)

        if self.flow is not None:

            flow_noc = self.flow[index]
            flow_image_noc = cv2.imread(flow_noc, -1)
            h, w, _ = flow_image_noc.shape
            flo_img_noc = flow_image_noc[:,:,2:0:-1].astype(np.float32)
            invalid_noc = (flow_image_noc[:,:,0] == 0)
            flo_img_noc = (flo_img_noc - 32768) / 64
            flo_img_noc[np.abs(flo_img_noc) < 1e-10] = 1e-10
            flo_img_noc[invalid_noc, :] = 0

            f_noc = torch.from_numpy(flo_img_noc.transpose((2,0,1)))
            mask_noc = torch.from_numpy((flow_image_noc[:,:,0] == 1).astype(np.float32)).type(torch.FloatTensor)


            return left_image, right_image, f_noc.type(torch.FloatTensor), mask_noc, h, w
        return left_image, right_image
    
    def __len__(self):
        return len(self.left)

class myCycleImageFolder_depth(data.Dataset):
    def __init__(self, left_image_train_00, left_image_train_01, right_image_train_00, cam_intrinsic_path, pose, training, param):
        self.left_image_train_00 = left_image_train_00
        self.left_image_train_01 = left_image_train_01

        ########
        self.right_image_train_00 = right_image_train_00
        # self.right_image_train_01 = right_image_train_01

        #######
        self.pose = pose
        self.cam_intrinsic_path = cam_intrinsic_path
        #######
        self.training = training
        self.param = param

    def __getitem__(self, index):
        left_image_train_00 = self.left_image_train_00[index]
        left_image_train_01 = self.left_image_train_01[index]
        #####
        right_image_train_00 = self.right_image_train_00[index]
        # right_image_train_01 = self.right_image_train_01[index]

        ########
        cam_intrinsic_path = self.cam_intrinsic_path[index]

        param = self.param
        left_image_00 = Image.open(left_image_train_00).convert('RGB')
        left_image_01 = Image.open(left_image_train_01).convert('RGB')

        #######
        right_image_00 = Image.open(right_image_train_00).convert('RGB')
        # right_image_01 = Image.open(right_image_train_01).convert('RGB')

        W, H = left_image_00.size
        # augmentation

        if self.training:

            # randomly shift gamma
            if random.uniform(0, 1) > 0.75:
                gamma = random.uniform(0.80, 1.2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) ** gamma), 0, 255).astype('uint8'),'RGB')
                # left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) ** gamma), 0, 255).astype('uint8'),'RGB')

                ############
                right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) ** gamma), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) ** gamma), 0, 255).astype('uint8'),'RGB')
   
            # randomly shift brightness
            if random.uniform(0, 1) > 0.75:
                brightness = random.uniform(0.8, 1.2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) * brightness), 0, 255).astype('uint8'),'RGB')
                # left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) * brightness), 0, 255).astype('uint8'),'RGB')

                ############
                right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) * brightness), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) * brightness), 0, 255).astype('uint8'),'RGB')

            # randomly shift color
            if random.uniform(0, 1) > 0.75:
                colors = [random.uniform(0.8, 1.2) for i in range(3)]
                shape = np.array(left_image_00).shape
                white = np.ones((shape[0], shape[1]))
                color_image = np.stack([white * colors[i] for i in range(3)], axis=2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) * color_image), 0, 255).astype('uint8'),'RGB')
                # left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) * color_image), 0, 255).astype('uint8'),'RGB')

                ############
                right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) * color_image), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) * color_image), 0, 255).astype('uint8'),'RGB')
                
        resize = Resize(param)
        left_image_00 = resize(left_image_00)
        # left_image_01 = resize(left_image_01)
        #######
        right_image_00 = resize(right_image_00)
        # right_image_01 = resize(right_image_01)

        #################
        file = open(cam_intrinsic_path, 'r')
        last_line = file.readlines()[-1]
        raw_cam_vec = np.array(list(map(float, last_line.split()[1:])))
        raw_cam_mat = np.reshape(raw_cam_vec, (3, 4))
        raw_cam_mat = raw_cam_mat[0:3, 0:3]
        #################
        width_ratio = 896.0 / W
        height_ratio = 320.0 / H
        raw_cam_mat[0, 0] = raw_cam_mat[0, 0] * width_ratio
        raw_cam_mat[0, 2] = raw_cam_mat[0, 2] * width_ratio
        raw_cam_mat[1, 1] = raw_cam_mat[1, 1] * height_ratio
        raw_cam_mat[1, 2] = raw_cam_mat[1, 2] * height_ratio
        #############################
        K = raw_cam_mat
        K_inv = np.linalg.inv(raw_cam_mat)
        ###########pose
        i = int(left_image_train_00.split('/')[-3])
        j = int(left_image_train_00.split('/')[-1].split('.')[0])
        pose1 = self.pose[i][j]
        i = int(left_image_train_01.split('/')[-3])
        j = int(left_image_train_01.split('/')[-1].split('.')[0])
        pose2 = self.pose[i][j]
        pose1_mat = np.array(list(map(float, pose1.split())))
        pose1_mat = np.reshape(pose1_mat, (3, 4))
        temp = np.reshape(np.array([0,0,0,1]),(1,4))
        pose1_mat = np.concatenate((pose1_mat, temp), 0)
        pose2_mat = np.array(list(map(float, pose2.split())))
        pose2_mat = np.reshape(pose2_mat, (3, 4))
        pose2_mat = np.concatenate((pose2_mat, temp), 0)
        pose_01_mat = np.dot(np.linalg.inv(pose2_mat), pose1_mat)
        pose_10_mat = np.linalg.inv(pose_01_mat)
        pose_01_mat = mat2rot(pose_01_mat)
        pose_10_mat = mat2rot(pose_10_mat)

        #########
        process = get_transform(param)
        left_image_00 = process(left_image_00)
        # left_image_01 = process(left_image_01)
        #######
        right_image_00 = process(right_image_00)
        # right_image_01 = process(right_image_01)

        return left_image_00, right_image_00, K, K_inv, pose_01_mat, pose_10_mat

    def __len__(self):
        return len(self.left_image_train_00)


def mat2euler(M, cy_thresh=None, seq='zyx'):
    '''
    Taken From: http://afni.nimh.nih.gov/pub/dist/src/pkundu/meica.libs/nibabel/eulerangles.py
    Discover Euler angle vector from 3x3 matrix
    Uses the conventions above.
    Parameters
    ----------
    M : array-like, shape (3,3)
    cy_thresh : None or scalar, optional
     threshold below which to give up on straightforward arctan for
     estimating x rotation.  If None (default), estimate from
     precision of input.
    Returns
    -------
    z : scalar
    y : scalar
    x : scalar
     Rotations in radians around z, y, x axes, respectively
    Notes
    -----
    If there was no numerical error, the routine could be derived using
    Sympy expression for z then y then x rotation matrix, which is::
    [                       cos(y)*cos(z),                       -cos(y)*sin(z),         sin(y)],
    [cos(x)*sin(z) + cos(z)*sin(x)*sin(y), cos(x)*cos(z) - sin(x)*sin(y)*sin(z), -cos(y)*sin(x)],
    [sin(x)*sin(z) - cos(x)*cos(z)*sin(y), cos(z)*sin(x) + cos(x)*sin(y)*sin(z),  cos(x)*cos(y)]
    with the obvious derivations for z, y, and x
     z = atan2(-r12, r11)
     y = asin(r13)
     x = atan2(-r23, r33)
    for x,y,z order
    y = asin(-r31)
    x = atan2(r32, r33)
    z = atan2(r21, r11)
    Problems arise when cos(y) is close to zero, because both of::
     z = atan2(cos(y)*sin(z), cos(y)*cos(z))
     x = atan2(cos(y)*sin(x), cos(x)*cos(y))
    will be close to atan2(0, 0), and highly unstable.
    The ``cy`` fix for numerical instability below is from: *Graphics
    Gems IV*, Paul Heckbert (editor), Academic Press, 1994, ISBN:
    0123361559.  Specifically it comes from EulerAngles.c by Ken
    Shoemake, and deals with the case where cos(y) is close to zero:
    See: http://www.graphicsgems.org/
    The code appears to be licensed (from the website) as "can be used
    without restrictions".
    '''
    M = np.asarray(M)
    if cy_thresh is None:
        try:
            cy_thresh = np.finfo(M.dtype).eps * 4
        except ValueError:
            cy_thresh = _FLOAT_EPS_4
    r11, r12, r13, r21, r22, r23, r31, r32, r33 = M.flat
    # cy: sqrt((cos(y)*cos(z))**2 + (cos(x)*cos(y))**2)
    cy = math.sqrt(r33 * r33 + r23 * r23)
    if seq == 'zyx':
        if cy > cy_thresh:  # cos(y) not close to zero, standard form
            z = math.atan2(-r12, r11)  # atan2(cos(y)*sin(z), cos(y)*cos(z))
            y = math.atan2(r13, cy)  # atan2(sin(y), cy)
            x = math.atan2(-r23, r33)  # atan2(cos(y)*sin(x), cos(x)*cos(y))
        else:  # cos(y) (close to) zero, so x -> 0.0 (see above)
            # so r21 -> sin(z), r22 -> cos(z) and
            z = math.atan2(r21, r22)
            y = math.atan2(r13, cy)  # atan2(sin(y), cy)
            x = 0.0
    elif seq == 'xyz':
        if cy > cy_thresh:
            y = math.atan2(-r31, cy)
            x = math.atan2(r32, r33)
            z = math.atan2(r21, r11)
        else:
            z = 0.0
            if r31 < 0:
                y = np.pi / 2
                x = atan2(r12, r13)
            else:
                y = -np.pi / 2
    else:
        raise Exception('Sequence not recognized')
    return z, y, x

def trans(M):
    z, y, x = mat2euler(M[0:3,0:3])
    T = np.array([x,y,z,M[0,3],M[1,3],M[2,3]])
    # print("T: ", T.shape)
    return T

class myCycleImageFolder_Euler(data.Dataset):
    def __init__(self, left_image_train_00, left_image_train_01, right_image_train_00, cam_intrinsic_path, pose, training, param):
        self.left_image_train_00 = left_image_train_00
        self.left_image_train_01 = left_image_train_01

        ########
        self.right_image_train_00 = right_image_train_00
        # self.right_image_train_01 = right_image_train_01

        #######
        self.pose = pose
        self.cam_intrinsic_path = cam_intrinsic_path
        #######
        self.training = training
        self.param = param

    def __getitem__(self, index):
        left_image_train_00 = self.left_image_train_00[index]
        left_image_train_01 = self.left_image_train_01[index]
        #####
        right_image_train_00 = self.right_image_train_00[index]
        # right_image_train_01 = self.right_image_train_01[index]

        ########
        cam_intrinsic_path = self.cam_intrinsic_path[index]

        param = self.param
        left_image_00 = Image.open(left_image_train_00).convert('RGB')
        left_image_01 = Image.open(left_image_train_01).convert('RGB')

        #######
        right_image_00 = Image.open(right_image_train_00).convert('RGB')
        # right_image_01 = Image.open(right_image_train_01).convert('RGB')

        W, H = left_image_00.size
        # augmentation

        if self.training:

            # randomly shift gamma
            if random.uniform(0, 1) > 0.75:
                gamma = random.uniform(0.80, 1.2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) ** gamma), 0, 255).astype('uint8'),'RGB')
                # left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) ** gamma), 0, 255).astype('uint8'),'RGB')

                ############
                right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) ** gamma), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) ** gamma), 0, 255).astype('uint8'),'RGB')
   
            # randomly shift brightness
            if random.uniform(0, 1) > 0.75:
                brightness = random.uniform(0.8, 1.2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) * brightness), 0, 255).astype('uint8'),'RGB')
                # left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) * brightness), 0, 255).astype('uint8'),'RGB')

                ############
                right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) * brightness), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) * brightness), 0, 255).astype('uint8'),'RGB')

            # randomly shift color
            if random.uniform(0, 1) > 0.75:
                colors = [random.uniform(0.8, 1.2) for i in range(3)]
                shape = np.array(left_image_00).shape
                white = np.ones((shape[0], shape[1]))
                color_image = np.stack([white * colors[i] for i in range(3)], axis=2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) * color_image), 0, 255).astype('uint8'),'RGB')
                # left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) * color_image), 0, 255).astype('uint8'),'RGB')

                ############
                right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) * color_image), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) * color_image), 0, 255).astype('uint8'),'RGB')
                gamma
        resize = Resize(param)
        left_image_00 = resize(left_image_00)
        # left_image_01 = resize(left_image_01)
        #######
        right_image_00 = resize(right_image_00)
        # right_image_01 = resize(right_image_01)

        #################
        file = open(cam_intrinsic_path, 'r')
        last_line = file.readlines()[-1]
        raw_cam_vec = np.array(list(map(float, last_line.split()[1:])))
        raw_cam_mat = np.reshape(raw_cam_vec, (3, 4))
        raw_cam_mat = raw_cam_mat[0:3, 0:3]
        #################
        width_ratio = 896.0 / W
        height_ratio = 320.0 / H
        raw_cam_mat[0, 0] = raw_cam_mat[0, 0] * width_ratio
        raw_cam_mat[0, 2] = raw_cam_mat[0, 2] * width_ratio
        raw_cam_mat[1, 1] = raw_cam_mat[1, 1] * height_ratio
        raw_cam_mat[1, 2] = raw_cam_mat[1, 2] * height_ratio
        #############################
        K = raw_cam_mat
        K_inv = np.linalg.inv(raw_cam_mat)
        ###########pose
        i = int(left_image_train_00.split('/')[-3])
        j = int(left_image_train_00.split('/')[-1].split('.')[0])
        pose1 = self.pose[i][j]
        i = int(left_image_train_01.split('/')[-3])
        j = int(left_image_train_01.split('/')[-1].split('.')[0])
        pose2 = self.pose[i][j]
        pose1_mat = np.array(list(map(float, pose1.split())))
        pose1_mat = np.reshape(pose1_mat, (3, 4))
        temp = np.reshape(np.array([0,0,0,1]),(1,4))
        pose1_mat = np.concatenate((pose1_mat, temp), 0)
        pose2_mat = np.array(list(map(float, pose2.split())))
        pose2_mat = np.reshape(pose2_mat, (3, 4))
        pose2_mat = np.concatenate((pose2_mat, temp), 0)
        pose_01_mat = np.dot(np.linalg.inv(pose2_mat), pose1_mat)
        pose_10_mat = np.linalg.inv(pose_01_mat)
        pose_01_mat = trans(pose_01_mat)
        pose_10_mat = trans(pose_10_mat)

        #########
        process = get_transform(param)
        left_image_00 = process(left_image_00)
        # left_image_01 = process(left_image_01)
        #######
        right_image_00 = process(right_image_00)
        # right_image_01 = process(right_image_01)

        return left_image_00, right_image_00, K, K_inv, pose_01_mat, pose_10_mat

    def __len__(self):
        return len(self.left_image_train_00)



class myCycleImageFolder_flow_Euler(data.Dataset):
    def __init__(self, left_image_train_00, left_image_train_01, cam_intrinsic_path, pose, training, param):
        self.left_image_train_00 = left_image_train_00
        self.left_image_train_01 = left_image_train_01

        ########
        # self.right_image_train_00 = right_image_train_00
        # self.right_image_train_01 = right_image_train_01

        #######
        self.pose = pose
        self.cam_intrinsic_path = cam_intrinsic_path
        #######
        self.training = training
        self.param = param

    def __getitem__(self, index):
        left_image_train_00 = self.left_image_train_00[index]
        left_image_train_01 = self.left_image_train_01[index]
        #####
        # right_image_train_00 = self.right_image_train_00[index]
        # right_image_train_01 = self.right_image_train_01[index]

        ########
        cam_intrinsic_path = self.cam_intrinsic_path[index]

        param = self.param
        left_image_00 = Image.open(left_image_train_00).convert('RGB')
        left_image_01 = Image.open(left_image_train_01).convert('RGB')

        #######
        # right_image_00 = Image.open(right_image_train_00).convert('RGB')
        # right_image_01 = Image.open(right_image_train_01).convert('RGB')

        W, H = left_image_00.size
        # augmentation

        if self.training:

            # randomly shift gamma
            if random.uniform(0, 1) > 0.75:
                gamma = random.uniform(0.80, 1.2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) ** gamma), 0, 255).astype('uint8'),'RGB')
                left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) ** gamma), 0, 255).astype('uint8'),'RGB')

                ############
                # right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) ** gamma), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) ** gamma), 0, 255).astype('uint8'),'RGB')
   
            # randomly shift brightness
            if random.uniform(0, 1) > 0.75:
                brightness = random.uniform(0.8, 1.2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) * brightness), 0, 255).astype('uint8'),'RGB')
                left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) * brightness), 0, 255).astype('uint8'),'RGB')

                ############
                # right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) * brightness), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) * brightness), 0, 255).astype('uint8'),'RGB')

            # randomly shift color
            if random.uniform(0, 1) > 0.75:
                colors = [random.uniform(0.8, 1.2) for i in range(3)]
                shape = np.array(left_image_00).shape
                white = np.ones((shape[0], shape[1]))
                color_image = np.stack([white * colors[i] for i in range(3)], axis=2)
                left_image_00 = Image.fromarray(np.clip((np.array(left_image_00) * color_image), 0, 255).astype('uint8'),'RGB')
                left_image_01 = Image.fromarray(np.clip((np.array(left_image_01) * color_image), 0, 255).astype('uint8'),'RGB')

                ############
                # right_image_00 = Image.fromarray(np.clip((np.array(right_image_00) * color_image), 0, 255).astype('uint8'),'RGB')
                # right_image_01 = Image.fromarray(np.clip((np.array(right_image_01) * color_image), 0, 255).astype('uint8'),'RGB')
                
        resize = Resize(param)
        left_image_00 = resize(left_image_00)
        left_image_01 = resize(left_image_01)
        #######
        # right_image_00 = resize(right_image_00)
        # right_image_01 = resize(right_image_01)

        #################
        file = open(cam_intrinsic_path, 'r')
        last_line = file.readlines()[-1]
        raw_cam_vec = np.array(list(map(float, last_line.split()[1:])))
        raw_cam_mat = np.reshape(raw_cam_vec, (3, 4))
        raw_cam_mat = raw_cam_mat[0:3, 0:3]
        #################
        width_ratio = 896.0 / W
        height_ratio = 320.0 / H
        raw_cam_mat[0, 0] = raw_cam_mat[0, 0] * width_ratio
        raw_cam_mat[0, 2] = raw_cam_mat[0, 2] * width_ratio
        raw_cam_mat[1, 1] = raw_cam_mat[1, 1] * height_ratio
        raw_cam_mat[1, 2] = raw_cam_mat[1, 2] * height_ratio
        #############################
        K = raw_cam_mat
        K_inv = np.linalg.inv(raw_cam_mat)
        ###########pose
        i = int(left_image_train_00.split('/')[-3])
        j = int(left_image_train_00.split('/')[-1].split('.')[0])
        pose1 = self.pose[i][j]
        i = int(left_image_train_01.split('/')[-3])
        j = int(left_image_train_01.split('/')[-1].split('.')[0])
        pose2 = self.pose[i][j]
        pose1_mat = np.array(list(map(float, pose1.split())))
        pose1_mat = np.reshape(pose1_mat, (3, 4))
        temp = np.reshape(np.array([0,0,0,1]),(1,4))
        pose1_mat = np.concatenate((pose1_mat, temp), 0)
        pose2_mat = np.array(list(map(float, pose2.split())))
        pose2_mat = np.reshape(pose2_mat, (3, 4))
        pose2_mat = np.concatenate((pose2_mat, temp), 0)
        pose_01_mat = np.dot(np.linalg.inv(pose2_mat), pose1_mat)
        pose_10_mat = np.linalg.inv(pose_01_mat)
        pose_01_mat = trans(pose_01_mat)
        pose_10_mat = trans(pose_10_mat)

        #########
        process = get_transform(param)
        left_image_00 = process(left_image_00)
        left_image_01 = process(left_image_01)
        #######
        # right_image_00 = process(right_image_00)
        # right_image_01 = process(right_image_01)

        return left_image_00, left_image_01, K, K_inv, pose_01_mat, pose_10_mat

    def __len__(self):
        return len(self.left_image_train_00)




class myImageFolder(data.Dataset):
    def __init__(self, left, right, flow, param):
        self.right = right
        self.left = left
        self.flow = flow
        self.param = param
        
    def __getitem__(self, index):
        left = self.left[index]
        right = self.right[index]
        param = self.param
        left_image = Image.open(left).convert('RGB')
        right_image = Image.open(right).convert('RGB')

      
        process = get_transform_test(param)
        left_image = process(left_image)
        right_image = process(right_image)

        if self.flow is not None:

            flow_noc = self.flow[index]
            flow_image_noc = cv2.imread(flow_noc, -1)
            h, w, _ = flow_image_noc.shape
            flo_img_noc = flow_image_noc[:,:,2:0:-1].astype(np.float32)
            invalid_noc = (flow_image_noc[:,:,0] == 0)
            flo_img_noc = (flo_img_noc - 32768) / 64
            flo_img_noc[np.abs(flo_img_noc) < 1e-10] = 1e-10
            flo_img_noc[invalid_noc, :] = 0

            f_noc = torch.from_numpy(flo_img_noc.transpose((2,0,1)))
            mask_noc = torch.from_numpy((flow_image_noc[:,:,0] == 1).astype(np.float32)).type(torch.FloatTensor)


            return left_image, right_image, f_noc.type(torch.FloatTensor), mask_noc, h, w
        return left_image, right_image
    
    def __len__(self):
        return len(self.left)


class myImageFolder_2015_test(data.Dataset):
    def __init__(self, left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2,
                 flow_noc, flow_occ, disp, cam_intrinsic_path, param):
        self.left_image_test_1 = left_image_test_1
        self.right_image_test_1 = right_image_test_1
        self.left_image_test_2 = left_image_test_2
        self.right_image_test_2 = right_image_test_2
        self.flow_noc = flow_noc
        self.flow_occ = flow_occ
        self.disp = disp
        self.cam_intrinsic_path = cam_intrinsic_path
        self.param = param

    def __getitem__(self, index):
        left_image_test_1 = self.left_image_test_1[index]
        right_image_test_1 = self.right_image_test_1[index]
        left_image_test_2 = self.left_image_test_2[index]
        right_image_test_2 = self.right_image_test_2[index]
        flow_noc = self.flow_noc[index]
        flow_occ = self.flow_occ[index]
        disp = self.disp[index]
        cam_intrinsic_path = self.cam_intrinsic_path[index]
        param = self.param

        left_image_test_1 = Image.open(left_image_test_1).convert('RGB')
        right_image_test_1 = Image.open(right_image_test_1).convert('RGB')
        left_image_test_2 = Image.open(left_image_test_2).convert('RGB')
        right_image_test_2 = Image.open(right_image_test_2).convert('RGB')

        
        W, H = left_image_test_1.size

        process = get_transform_test(param)
        left_image_test_1 = process(left_image_test_1)
        right_image_test_1 = process(right_image_test_1)
        left_image_test_2 = process(left_image_test_2)
        right_image_test_2 = process(right_image_test_2)

        if self.flow_noc is not None:
            ########################load flow_noc
            flow_noc = self.flow_noc[index]
            flow_image_noc = cv2.imread(flow_noc, -1)
            h, w, _ = flow_image_noc.shape
            flo_img_noc = flow_image_noc[:, :, 2:0:-1].astype(np.float32)
            invalid_noc = (flow_image_noc[:, :, 0] == 0)
            flo_img_noc = (flo_img_noc - 32768) / 64
            flo_img_noc[np.abs(flo_img_noc) < 1e-10] = 1e-10
            flo_img_noc[invalid_noc, :] = 0

            f_noc = torch.from_numpy(flo_img_noc.transpose((2, 0, 1)))
            mask_noc = torch.from_numpy((flow_image_noc[:, :, 0] == 1).astype(np.float32)).type(torch.FloatTensor)
            ########################load flow_occ
            flow_occ = self.flow_occ[index]
            flow_image_occ = cv2.imread(flow_occ, -1)
            flo_img_occ = flow_image_occ[:, :, 2:0:-1].astype(np.float32)
            invalid_occ = (flow_image_occ[:, :, 0] == 0)
            flo_img_occ = (flo_img_occ - 32768) / 64
            flo_img_occ[np.abs(flo_img_occ) < 1e-10] = 1e-10
            flo_img_occ[invalid_occ, :] = 0

            f_occ = torch.from_numpy(flo_img_occ.transpose((2, 0, 1)))
            mask_occ = torch.from_numpy((flow_image_occ[:, :, 0] == 1).astype(np.float32)).type(torch.FloatTensor)
            ##############################load dis
            flow_dis = self.disp[index]

            dispi = cv2.imread(flow_dis, -1)
            dispi = torch.from_numpy(dispi.astype(np.float32) / 256)

            file = open(cam_intrinsic_path, 'r')
            last_line = file.readlines()[-1]
            raw_cam_vec = np.array(list(map(float, last_line.split()[1:])))
            raw_cam_mat = np.reshape(raw_cam_vec, (3, 4))
            raw_cam_mat = raw_cam_mat[0:3, 0:3]
            width_ratio = 896.0 / W
            height_ratio = 320.0 / H
            K_yuan = raw_cam_mat[0:3, 0:3].copy()
            raw_cam_mat[0, 0] = raw_cam_mat[0, 0] * width_ratio
            raw_cam_mat[0, 2] = raw_cam_mat[0, 2] * width_ratio
            raw_cam_mat[1, 1] = raw_cam_mat[1, 1] * height_ratio
            raw_cam_mat[1, 2] = raw_cam_mat[1, 2] * height_ratio
            K = raw_cam_mat
  

            return left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, \
                   f_noc.type(torch.FloatTensor), mask_noc, f_occ.type(torch.FloatTensor), mask_occ, dispi, h, w, K

        return left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2

    def __len__(self):
        return len(self.left_image_test_1)

def get_2015_test_data(file_path_test, path):
    f_test = open(file_path_test)
    left_image_test_1 = list()
    right_image_test_1 = list()
    left_image_test_2 = list()
    right_image_test_2 = list()
    flow_noc = list()
    flow_occ = list()
    disp = list()
    k = list()


    for line in f_test:
        left_image_test_1.append(path + line.split()[0])
        right_image_test_1.append(path + line.split()[1])
        left_image_test_2.append(path + line.split()[2])
        right_image_test_2.append(path + line.split()[3])
        flow_noc.append(path + line.split()[4])
        flow_occ.append(path + line.split()[5])
        disp.append(path + line.split()[6])
        k.append(path + line.split()[7])


    return left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, flow_noc, flow_occ, disp, k