from __future__ import division
import sys
from glob import glob
import torch
import torchvision
import os
import torchvision.transforms as transforms
import torch.utils.data as data
import numpy as np
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse
import random
from PIL import Image
import cv2
import math
from models.PWC_depth_net import *
from models.PWC_depth_net import PWCDCNet_Disp
import time
# from models.PWC_net import *
# from models.PWC_net import PWCDCNet

# from utils.utils import *
# from utils.evaluation_utils import *
# from models.networks.submodules import *

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
# torch.backends.cudnn.enabled = False

def get_args():
	parser = argparse.ArgumentParser()

	parser.add_argument('--data_path', type=str, help='path to the data', required=True)
	parser.add_argument('--load_09_filenames_file', type=str, help='path to the filenames text file',
						default="./utils/filenames/pose_09_pnp.txt")
	parser.add_argument('--load_10_filenames_file', type=str, help='path to the filenames text file',
						default="./utils/filenames/pose_10_pnp.txt")
	parser.add_argument('--pose_path', type=str, help='model name', default='./utils/filenames/poses/')
	parser.add_argument('--input_height', type=int, help='input height', default=320)
	parser.add_argument('--input_width', type=int, help='input width', default=896)
	parser.add_argument('--min_depth', type=float, help='minimum depth for evaluation', default=1e-3)
	parser.add_argument('--max_depth', type=float, help='maximum depth for evaluation', default=80)
	parser.add_argument('--checkpoint_path', type=str, help='path to a specific checkpoint to load', required=True)
	parser.add_argument('--checkpoint_pose_path', type=str, help='path to a specific checkpoint to load', default="")
	parser.add_argument('--output_dir', type=str, help='path to a save result', default="./")
	args = parser.parse_args()
	return args


args = get_args()
test_seq_09 = True
test_seq_10 = True

checkpoint = torch.load(args.checkpoint_path)
net = pwc_dc_disp_net()

net.load_state_dict(checkpoint['state_dict'])
checkpoint = torch.load(args.checkpoint_pose_path)
pose_net = pwc_pose_net()
pose_net.load_state_dict(checkpoint['state_dict'])
net.cuda()
pose_net.cuda()
# pose_net.cuda()

save_dir = args.output_dir + "test.txt"
print("begin to test")
f2 = open(save_dir,'a+')
f2.write("The model is : "+args.checkpoint_path+ "\n")

def get_test_data(file_path_test, path, pose_path):
	f_test = open(file_path_test)
	left_image_test_1 = list()
	right_image_test_1 = list()
	left_image_test_2 = list()
	right_image_test_2 = list()
	k = list()

	for line in f_test:
		left_image_test_1.append(path + line.split()[0])
		right_image_test_1.append(path + line.split()[1])
		left_image_test_2.append(path + line.split()[2])
		right_image_test_2.append(path + line.split()[3])
		k.append(path + line.split()[4])
	# f = open(pose_path)
	# gt_pose = f.readlines(pose_path)
	pose = list()
	for i in range(22):
		pose_ = open(pose_path + str(i).zfill(2) + '.txt').readlines()
		pose.append(pose_)

	return left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, k, pose

def get_transform_test(param):
	return transforms.Compose([
		# transforms.RandomCrop([param.input_height, param.input_width]),
		transforms.Resize([param.input_height, param.input_width]),
		transforms.ToTensor(),
		# transforms.Normalize(mean=[0,0,0], std=[255,255,255]),
		# transforms.Normalize(mean=[0.411,0.432,0.45], std=[1,1,1])
	])


class myImageFolder_test(data.Dataset):
	def __init__(self, left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, cam_intrinsic_path,
				  param):
		self.left_image_test_1 = left_image_test_1
		self.right_image_test_1 = right_image_test_1
		self.left_image_test_2 = left_image_test_2
		self.right_image_test_2 = right_image_test_2
		self.cam_intrinsic_path = cam_intrinsic_path
		# self.gt_pose = gt_pose
		# self.pose_seq = pose_seq
		self.param = param

	def __getitem__(self, index):
		left_image_test_1 = self.left_image_test_1[index]
		right_image_test_1 = self.right_image_test_1[index]
		left_image_test_2 = self.left_image_test_2[index]
		right_image_test_2 = self.right_image_test_2[index]
		cam_intrinsic_path = self.cam_intrinsic_path[index]
		# print(left_image_test_2)

		param = self.param

		# i = int(pose_seq)
		# j = int(left_image_test_1.split('/')[-1].split('.')[0])
		# pose1 = self.pose[i][j]
		#
		# j = int(left2.split('/')[-1].split('.')[0])
		# pose2 = self.pose[i][j]

		left_image_test_1 = Image.open(left_image_test_1).convert('RGB')
		right_image_test_1 = Image.open(right_image_test_1).convert('RGB')
		left_image_test_2 = Image.open(left_image_test_2).convert('RGB')
		right_image_test_2 = Image.open(right_image_test_2).convert('RGB')
		W, H = left_image_test_1.size

		process = get_transform_test(param)
		left_image_test_1 = process(left_image_test_1)
		right_image_test_1 = process(right_image_test_1)
		left_image_test_2 = process(left_image_test_2)
		right_image_test_2 = process(right_image_test_2)

		file = open(cam_intrinsic_path, 'r')
		last_line = file.readlines()[-1]
		raw_cam_vec = np.array(list(map(float,last_line.split()[1:])))
		raw_cam_mat = np.reshape(raw_cam_vec, (3, 4))
		raw_cam_mat = raw_cam_mat[0:3, 0:3]
		# width_ratio = 1
		# height_ratio = 1
		width_ratio = 896.0 / W
		height_ratio = 320.0 / H
		# K_yuan = raw_cam_mat[0:3, 0:3].copy()
		raw_cam_mat[0, 0] = raw_cam_mat[0, 0] * width_ratio
		raw_cam_mat[0, 2] = raw_cam_mat[0, 2] * width_ratio
		raw_cam_mat[1, 1] = raw_cam_mat[1, 1] * height_ratio
		raw_cam_mat[1, 2] = raw_cam_mat[1, 2] * height_ratio
		K = raw_cam_mat
		K_inv = np.linalg.inv(K)

		# pose1_mat = np.array(list(map(float, pose1.split())))
		# pose1_mat = np.reshape(pose1_mat, (3, 4))
		# temp = np.reshape(np.array([0, 0, 0, 1]), (1, 4))
		# pose1_mat = np.concatenate((pose1_mat, temp), 0)
		#
		# pose2_mat = np.array(list(map(float, pose2.split())))
		# pose2_mat = np.reshape(pose2_mat, (3, 4))
		# pose2_mat = np.concatenate((pose2_mat, temp), 0)
		#
		# pose_12_mat = np.dot(np.linalg.inv(pose1_mat), pose2_mat)
		# pose_21_mat = np.linalg.inv(pose_12_mat)

		return left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, K, K_inv#, pose_21_mat, pose_12_mat
	def __len__(self):
		return len(self.left_image_test_1)

def cal_one_pose_matrix(pose):
	def _rot_2_mat(r):
		theta = torch.norm(r, p=2, dim=1).unsqueeze(1).repeat(1, 3).cuda()  #(B,)
		r = r / theta
		rx = r[:,0:1]
		ry = r[:,1:2]
		rz = r[:,2:]

		zeros = torch.zeros_like(rx)
		R1 = torch.cat([zeros, -rz, ry],1).unsqueeze(1)  #(B,1,3)
		R2 = torch.cat([rz, zeros, -rx],1).unsqueeze(1)
		R3 = torch.cat([-ry, rx, zeros],1).unsqueeze(1)
		R = torch.cat([R1,R2,R3], 1)  #(B,3,3)

		I = torch.cat([torch.eye(3).unsqueeze(0).cuda() for i in range(R1.shape[0])])  #(B,3,3)
		cos = torch.cos(theta).unsqueeze(2).repeat(1,1,3)
		sin = torch.sin(theta).unsqueeze(2).repeat(1,1,3)
		rrT = torch.matmul(r.unsqueeze(2),r.unsqueeze(1))

		R_mat = cos * I + (1 - cos) * rrT + sin * R
		return R_mat

	B,_ = pose.shape
	rotMat = _rot_2_mat(pose[:,0:3])
	translation = (pose[:, 3:]).unsqueeze(2)
	filler = torch.tensor([[[0.0, 0.0, 0.0, 1.0]]])
	filler = filler.repeat(B,1,1).cuda()
	pose_matrix = torch.cat((torch.cat((rotMat, translation), 2), filler), 1)
	return pose_matrix


def read_file_list(filename):
	"""
	Reads a trajectory from a text file.

	File format:
	The file format is "stamp d1 d2 d3 ...", where stamp denotes the time stamp (to be matched)
	and "d1 d2 d3.." is arbitary data (e.g., a 3D position and 3D orientation) associated to this timestamp.

	Input:
	filename -- File name

	Output:
	dict -- dictionary of (stamp,data) tuples

	"""
	file = open(filename)
	data = file.read()
	lines = data.replace(",", " ").replace("\t", " ").split("\n")
	list = [[v.strip() for v in line.split(" ") if v.strip() != ""]
			for line in lines if len(line) > 0 and line[0] != "#"]
	list = [(float(l[0]), l[1:]) for l in list if len(l) > 1]
	return dict(list)


def associate(first_list, second_list, offset, max_difference):
	"""
	Associate two dictionaries of (stamp,data). As the time stamps never match exactly, we aim
	to find the closest match for every input tuple.

	Input:
	first_list -- first dictionary of (stamp,data) tuples
	second_list -- second dictionary of (stamp,data) tuples
	offset -- time offset between both dictionaries (e.g., to model the delay between the sensors)
	max_difference -- search radius for candidate generation

	Output:
	matches -- list of matched tuples ((stamp1,data1),(stamp2,data2))

	"""
	first_keys = list(first_list.keys())
	second_keys = list(second_list.keys())
	potential_matches = [(abs(a - (b + offset)), a, b)
						 for a in first_keys for b in second_keys
						 if abs(a - (b + offset)) < max_difference]
	potential_matches.sort()
	matches = []
	for diff, a, b in potential_matches:
		if a in first_keys and b in second_keys:
			first_keys.remove(a)
			second_keys.remove(b)
			matches.append((a, b))

	matches.sort()
	return matches

def quat2mat(q):
	''' Calculate rotation matrix corresponding to quaternion
	https://afni.nimh.nih.gov/pub/dist/src/pkundu/meica.libs/nibabel/quaternions.py
	Parameters
	----------
	q : 4 element array-like

	Returns
	-------
	M : (3,3) array
	  Rotation matrix corresponding to input quaternion *q*

	Notes
	-----
	Rotation matrix applies to column vectors, and is applied to the
	left of coordinate vectors.  The algorithm here allows non-unit
	quaternions.

	References
	----------
	Algorithm from
	http://en.wikipedia.org/wiki/Rotation_matrix#Quaternion

	Examples
	--------
	>>> import numpy as np
	>>> M = quat2mat([1, 0, 0, 0]) # Identity quaternion
	>>> np.allclose(M, np.eye(3))
	True
	>>> M = quat2mat([0, 1, 0, 0]) # 180 degree rotn around axis 0
	>>> np.allclose(M, np.diag([1, -1, -1]))
	True
	'''
	w, x, y, z = q
	Nq = w * w + x * x + y * y + z * z
	if Nq < 1e-8:
		return np.eye(3)
	s = 2.0 / Nq
	X = x * s
	Y = y * s
	Z = z * s
	wX = w * X
	wY = w * Y
	wZ = w * Z
	xX = x * X
	xY = x * Y
	xZ = x * Z
	yY = y * Y
	yZ = y * Z
	zZ = z * Z
	return np.array([[1.0 - (yY + zZ), xY - wZ, xZ + wY],
					 [xY + wZ, 1.0 - (xX + zZ), yZ - wX],
					 [xZ - wY, yZ + wX, 1.0 - (xX + yY)]])


def mat2euler(M, cy_thresh=None, seq='zyx'):
	'''
	Taken From: http://afni.nimh.nih.gov/pub/dist/src/pkundu/meica.libs/nibabel/eulerangles.py
	Discover Euler angle vector from 3x3 matrix
	Uses the conventions above.
	Parameters
	----------
	M : array-like, shape (3,3)
	cy_thresh : None or scalar, optional
	 threshold below which to give up on straightforward arctan for
	 estimating x rotation.  If None (default), estimate from
	 precision of input.
	Returns
	-------
	z : scalar
	y : scalar
	x : scalar
	 Rotations in radians around z, y, x axes, respectively
	Notes
	-----
	If there was no numerical error, the routine could be derived using
	Sympy expression for z then y then x rotation matrix, which is::
	[                       cos(y)*cos(z),                       -cos(y)*sin(z),         sin(y)],
	[cos(x)*sin(z) + cos(z)*sin(x)*sin(y), cos(x)*cos(z) - sin(x)*sin(y)*sin(z), -cos(y)*sin(x)],
	[sin(x)*sin(z) - cos(x)*cos(z)*sin(y), cos(z)*sin(x) + cos(x)*sin(y)*sin(z),  cos(x)*cos(y)]
	with the obvious derivations for z, y, and x
	 z = atan2(-r12, r11)
	 y = asin(r13)
	 x = atan2(-r23, r33)
	for x,y,z order
	y = asin(-r31)
	x = atan2(r32, r33)
	z = atan2(r21, r11)
	Problems arise when cos(y) is close to zero, because both of::
	 z = atan2(cos(y)*sin(z), cos(y)*cos(z))
	 x = atan2(cos(y)*sin(x), cos(x)*cos(y))
	will be close to atan2(0, 0), and highly unstable.
	The ``cy`` fix for numerical instability below is from: *Graphics
	Gems IV*, Paul Heckbert (editor), Academic Press, 1994, ISBN:
	0123361559.  Specifically it comes from EulerAngles.c by Ken
	Shoemake, and deals with the case where cos(y) is close to zero:
	See: http://www.graphicsgems.org/
	The code appears to be licensed (from the website) as "can be used
	without restrictions".
	'''
	M = np.asarray(M)
	if cy_thresh is None:
		try:
			cy_thresh = np.finfo(M.dtype).eps * 4
		except ValueError:
			cy_thresh = _FLOAT_EPS_4
	r11, r12, r13, r21, r22, r23, r31, r32, r33 = M.flat
	# cy: sqrt((cos(y)*cos(z))**2 + (cos(x)*cos(y))**2)
	cy = math.sqrt(r33 * r33 + r23 * r23)
	if seq == 'zyx':
		if cy > cy_thresh:  # cos(y) not close to zero, standard form
			z = math.atan2(-r12, r11)  # atan2(cos(y)*sin(z), cos(y)*cos(z))
			y = math.atan2(r13, cy)  # atan2(sin(y), cy)
			x = math.atan2(-r23, r33)  # atan2(cos(y)*sin(x), cos(x)*cos(y))
		else:  # cos(y) (close to) zero, so x -> 0.0 (see above)
			# so r21 -> sin(z), r22 -> cos(z) and
			z = math.atan2(r21, r22)
			y = math.atan2(r13, cy)  # atan2(sin(y), cy)
			x = 0.0
	elif seq == 'xyz':
		if cy > cy_thresh:
			y = math.atan2(-r31, cy)
			x = math.atan2(r32, r33)
			z = math.atan2(r21, r11)
		else:
			z = 0.0
			if r31 < 0:
				y = np.pi / 2
				x = atan2(r12, r13)
			else:
				y = -np.pi / 2
	else:
		raise Exception('Sequence not recognized')
	return z, y, x


import functools


def euler2mat(z=0, y=0, x=0, isRadian=True):
	''' Return matrix for rotations around z, y and x axes
	Uses the z, then y, then x convention above
	Parameters
	----------
	z : scalar
		 Rotation angle in radians around z-axis (performed first)
	y : scalar
		 Rotation angle in radians around y-axis
	x : scalar
		 Rotation angle in radians around x-axis (performed last)
	Returns
	-------
	M : array shape (3,3)
		 Rotation matrix giving same rotation as for given angles
	Examples
	--------
	>>> zrot = 1.3 # radians
	>>> yrot = -0.1
	>>> xrot = 0.2
	>>> M = euler2mat(zrot, yrot, xrot)
	>>> M.shape == (3, 3)
	True
	The output rotation matrix is equal to the composition of the
	individual rotations
	>>> M1 = euler2mat(zrot)
	>>> M2 = euler2mat(0, yrot)
	>>> M3 = euler2mat(0, 0, xrot)
	>>> composed_M = np.dot(M3, np.dot(M2, M1))
	>>> np.allclose(M, composed_M)
	True
	You can specify rotations by named arguments
	>>> np.all(M3 == euler2mat(x=xrot))
	True
	When applying M to a vector, the vector should column vector to the
	right of M.  If the right hand side is a 2D array rather than a
	vector, then each column of the 2D array represents a vector.
	>>> vec = np.array([1, 0, 0]).reshape((3,1))
	>>> v2 = np.dot(M, vec)
	>>> vecs = np.array([[1, 0, 0],[0, 1, 0]]).T # giving 3x2 array
	>>> vecs2 = np.dot(M, vecs)
	Rotations are counter-clockwise.
	>>> zred = np.dot(euler2mat(z=np.pi/2), np.eye(3))
	>>> np.allclose(zred, [[0, -1, 0],[1, 0, 0], [0, 0, 1]])
	True
	>>> yred = np.dot(euler2mat(y=np.pi/2), np.eye(3))
	>>> np.allclose(yred, [[0, 0, 1],[0, 1, 0], [-1, 0, 0]])
	True
	>>> xred = np.dot(euler2mat(x=np.pi/2), np.eye(3))
	>>> np.allclose(xred, [[1, 0, 0],[0, 0, -1], [0, 1, 0]])
	True
	Notes
	-----
	The direction of rotation is given by the right-hand rule (orient
	the thumb of the right hand along the axis around which the rotation
	occurs, with the end of the thumb at the positive end of the axis;
	curl your fingers; the direction your fingers curl is the direction
	of rotation).  Therefore, the rotations are counterclockwise if
	looking along the axis of rotation from positive to negative.
	'''

	if not isRadian:
		z = ((np.pi) / 180.) * z
		y = ((np.pi) / 180.) * y
		x = ((np.pi) / 180.) * x
	assert z >= (-np.pi) and z < np.pi, 'Inapprorpriate z: %f' % z
	assert y >= (-np.pi) and y < np.pi, 'Inapprorpriate y: %f' % y
	assert x >= (-np.pi) and x < np.pi, 'Inapprorpriate x: %f' % x

	Ms = []
	if z:
		cosz = math.cos(z)
		sinz = math.sin(z)
		Ms.append(np.array([[cosz, -sinz, 0], [sinz, cosz, 0], [0, 0, 1]]))
	if y:
		cosy = math.cos(y)
		siny = math.sin(y)
		Ms.append(np.array([[cosy, 0, siny], [0, 1, 0], [-siny, 0, cosy]]))
	if x:
		cosx = math.cos(x)
		sinx = math.sin(x)
		Ms.append(np.array([[1, 0, 0], [0, cosx, -sinx], [0, sinx, cosx]]))
	if Ms:
		return functools.reduce(np.dot, Ms[::-1])
	return np.eye(3)


def euler2quat(z=0, y=0, x=0, isRadian=True):
	''' Return quaternion corresponding to these Euler angles
	Uses the z, then y, then x convention above
	Parameters
	----------
	z : scalar
		 Rotation angle in radians around z-axis (performed first)
	y : scalar
		 Rotation angle in radians around y-axis
	x : scalar
		 Rotation angle in radians around x-axis (performed last)
	Returns
	-------
	quat : array shape (4,)
		 Quaternion in w, x, y z (real, then vector) format
	Notes
	-----
	We can derive this formula in Sympy using:
	1. Formula giving quaternion corresponding to rotation of theta radians
		 about arbitrary axis:
		 http://mathworld.wolfram.com/EulerParameters.html
	2. Generated formulae from 1.) for quaternions corresponding to
		 theta radians rotations about ``x, y, z`` axes
	3. Apply quaternion multiplication formula -
		 http://en.wikipedia.org/wiki/Quaternions#Hamilton_product - to
		 formulae from 2.) to give formula for combined rotations.
	'''

	if not isRadian:
		z = ((np.pi) / 180.) * z
		y = ((np.pi) / 180.) * y
		x = ((np.pi) / 180.) * x
	z = z / 2.0
	y = y / 2.0
	x = x / 2.0
	cz = math.cos(z)
	sz = math.sin(z)
	cy = math.cos(y)
	sy = math.sin(y)
	cx = math.cos(x)
	sx = math.sin(x)
	return np.array([
		cx * cy * cz - sx * sy * sz, cx * sy * sz + cy * cz * sx,
		cx * cz * sy - sx * cy * sz, cx * cy * sz + sx * cz * sy
	])


def pose_vec_to_mat(vec):
	tx = vec[0]
	ty = vec[1]
	tz = vec[2]
	trans = np.array([tx, ty, tz]).reshape((3, 1))
	rot = euler2mat(vec[5], vec[4], vec[3])
	Tmat = np.concatenate((rot, trans), axis=1)
	hfiller = np.array([0, 0, 0, 1]).reshape((1, 4))
	Tmat = np.concatenate((Tmat, hfiller), axis=0)
	return Tmat

def rot2quat(R):
	rz, ry, rx = mat2euler(R)
	qw, qx, qy, qz = euler2quat(rz, ry, rx)
	return qw, qx, qy, qz

def dump_pose_seq_TUM(out_file, poses, times):
	# First frame as the origin
	with open(out_file, 'w') as f:
		for p in range(len(times)):
			this_pose = poses[p]
			tx = this_pose[0, 3]
			ty = this_pose[1, 3]
			tz = this_pose[2, 3]
			rot = this_pose[:3, :3]
			qw, qx, qy, qz = rot2quat(rot)
			f.write('%f %f %f %f %f %f %f %f\n' %
					(times[p], tx, ty, tz, qx, qy, qz, qw))

def compute_ate(gtruth_file, pred_file):
	gtruth_list = read_file_list(gtruth_file)
	pred_list = read_file_list(pred_file)
	matches = associate(gtruth_list, pred_list, 0, 0.01)
	if len(matches) < 2:
		return False

	gtruth_xyz = np.array(
		[[float(value) for value in gtruth_list[a][0:3]] for a, b in matches])
	pred_xyz = np.array(
		[[float(value) for value in pred_list[b][0:3]] for a, b in matches])

	# Make sure that the first matched frames align (no need for rotational alignment as
	# all the predicted/ground-truth snippets have been converted to use the same coordinate
	# system with the first frame of the snippet being the origin).
	offset = gtruth_xyz[0] - pred_xyz[0]
	pred_xyz += offset[None, :]

	# Optimize the scaling factor
	scale = np.sum(gtruth_xyz * pred_xyz) / np.sum(pred_xyz**2)
	alignment_error = pred_xyz * scale - gtruth_xyz
	rmse = np.sqrt(np.sum(alignment_error**2)) / len(matches)
	return rmse

def eval_snippet(pred_dir, gt_dir):
	pred_files = glob(pred_dir + '/*.txt')
	ate_all = []
	for i in range(len(pred_files)):
		gtruth_file = gt_dir + "/" + os.path.basename(pred_files[i])
		if not os.path.exists(gtruth_file):
			continue
		ate = compute_ate(gtruth_file, pred_files[i])
		if ate == False:
			continue
		ate_all.append(ate)
	ate_all = np.array(ate_all)
	sys.stderr.write("ATE mean: %.4f, std: %.4f \n" %
					 (np.mean(ate_all), np.std(ate_all)))
	f2.write("ATE mean: %.4f, std: %.4f \n" %
					 (np.mean(ate_all), np.std(ate_all))+ " ")
					 
class kittiEvalOdom():
	# ----------------------------------------------------------------------
	# poses: N,4,4
	# pose: 4,4
	# ----------------------------------------------------------------------
	def __init__(self, gt_dir):
		self.lengths = [100, 200, 300, 400, 500, 600, 700, 800]
		self.num_lengths = len(self.lengths)
		self.gt_dir = gt_dir

	def loadPoses(self, file_name):
		# ----------------------------------------------------------------------
		# Each line in the file should follow one of the following structures
		# (1) idx pose(3x4 matrix in terms of 12 numbers)
		# (2) pose(3x4 matrix in terms of 12 numbers)
		# ----------------------------------------------------------------------
		f = open(file_name, 'r')
		s = f.readlines()
		f.close()
		file_len = len(s)
		poses = {}
		for cnt, line in enumerate(s):
			P = np.eye(4)
			line_split = [float(i) for i in line.split(" ")]
			withIdx = int(len(line_split) == 13)
			for row in range(3):
				for col in range(4):
					P[row, col] = line_split[row * 4 + col + withIdx]
			if withIdx:
				frame_idx = line_split[0]
			else:
				frame_idx = cnt
			poses[frame_idx] = P
		return poses

	def trajectoryDistances(self, poses):
		# ----------------------------------------------------------------------
		# poses: dictionary: [frame_idx: pose]
		# ----------------------------------------------------------------------
		dist = [0]
		sort_frame_idx = sorted(poses.keys())
		for i in range(len(sort_frame_idx) - 1):
			cur_frame_idx = sort_frame_idx[i]
			next_frame_idx = sort_frame_idx[i + 1]
			P1 = poses[cur_frame_idx]
			P2 = poses[next_frame_idx]
			dx = P1[0, 3] - P2[0, 3]
			dy = P1[1, 3] - P2[1, 3]
			dz = P1[2, 3] - P2[2, 3]
			dist.append(dist[i] + np.sqrt(dx**2 + dy**2 + dz**2))
		return dist

	def rotationError(self, pose_error):
		a = pose_error[0, 0]
		b = pose_error[1, 1]
		c = pose_error[2, 2]
		d = 0.5 * (a + b + c - 1.0)
		return np.arccos(max(min(d, 1.0), -1.0))

	def translationError(self, pose_error):
		dx = pose_error[0, 3]
		dy = pose_error[1, 3]
		dz = pose_error[2, 3]
		return np.sqrt(dx**2 + dy**2 + dz**2)

	def lastFrameFromSegmentLength(self, dist, first_frame, len_):
		for i in range(first_frame, len(dist), 1):
			if dist[i] > (dist[first_frame] + len_):
				return i
		return -1

	def calcSequenceErrors(self, poses_gt, poses_result):
		err = []
		dist = self.trajectoryDistances(poses_gt)
		self.step_size = 10

		for first_frame in range(9, len(poses_gt), self.step_size):
			for i in range(self.num_lengths):
				len_ = self.lengths[i]
				last_frame = self.lastFrameFromSegmentLength(dist, first_frame,
															 len_)

				# ----------------------------------------------------------------------
				# Continue if sequence not long enough
				# ----------------------------------------------------------------------
				if last_frame == -1 or not (
						last_frame in poses_result.keys()) or not (
							first_frame in poses_result.keys()):
					continue

				# ----------------------------------------------------------------------
				# compute rotational and translational errors
				# ----------------------------------------------------------------------
				pose_delta_gt = np.dot(
					np.linalg.inv(poses_gt[first_frame]), poses_gt[last_frame])
				pose_delta_result = np.dot(
					np.linalg.inv(poses_result[first_frame]),
					poses_result[last_frame])
				pose_error = np.dot(
					np.linalg.inv(pose_delta_result), pose_delta_gt)

				r_err = self.rotationError(pose_error)
				t_err = self.translationError(pose_error)

				# ----------------------------------------------------------------------
				# compute speed
				# ----------------------------------------------------------------------
				num_frames = last_frame - first_frame + 1.0
				speed = len_ / (0.1 * num_frames)

				err.append(
					[first_frame, r_err / len_, t_err / len_, len_, speed])
		return err

	def saveSequenceErrors(self, err, file_name):
		fp = open(file_name, 'w')
		for i in err:
			line_to_write = " ".join([str(j) for j in i])
			fp.writelines(line_to_write + "\n")
		fp.close()

	def computeOverallErr(self, seq_err):
		t_err = 0
		r_err = 0

		seq_len = len(seq_err)

		for item in seq_err:
			r_err += item[1]
			t_err += item[2]
		ave_t_err = t_err / seq_len
		ave_r_err = r_err / seq_len
		return ave_t_err, ave_r_err

	def plotPath(self, seq, poses_gt, poses_result):
		plot_keys = ["Ground Truth", "Ours"]
		fontsize_ = 20
		plot_num = -1

		poses_dict = {}
		poses_dict["Ground Truth"] = poses_gt
		poses_dict["Ours"] = poses_result

		fig = plt.figure()
		ax = plt.gca()
		ax.set_aspect('equal')

		for key in plot_keys:
			pos_xz = []
			# for pose in poses_dict[key]:
			for frame_idx in sorted(poses_dict[key].keys()):
				pose = poses_dict[key][frame_idx]
				pos_xz.append([pose[0, 3], pose[2, 3]])
			pos_xz = np.asarray(pos_xz)
			plt.plot(pos_xz[:, 0], pos_xz[:, 1], label=key)

		plt.legend(loc="upper right", prop={'size': fontsize_})
		plt.xticks(fontsize=fontsize_)
		plt.yticks(fontsize=fontsize_)
		plt.xlabel('x (m)', fontsize=fontsize_)
		plt.ylabel('z (m)', fontsize=fontsize_)
		fig.set_size_inches(10, 10)
		png_title = "sequence_{:02}".format(seq)
		plt.savefig(
			self.plot_path_dir + "/" + png_title + ".pdf",
			bbox_inches='tight',
			pad_inches=0)
		# plt.show()

	def plotError(self, avg_segment_errs):
		# ----------------------------------------------------------------------
		# avg_segment_errs: dict [100: err, 200: err...]
		# ----------------------------------------------------------------------
		plot_y = []
		plot_x = []
		for len_ in self.lengths:
			plot_x.append(len_)
			plot_y.append(avg_segment_errs[len_][0])
		fig = plt.figure()
		plt.plot(plot_x, plot_y)
		plt.show()

	def computeSegmentErr(self, seq_errs):
		# ----------------------------------------------------------------------
		# This function calculates average errors for different segment.
		# ----------------------------------------------------------------------

		segment_errs = {}
		avg_segment_errs = {}
		for len_ in self.lengths:
			segment_errs[len_] = []
		# ----------------------------------------------------------------------
		# Get errors
		# ----------------------------------------------------------------------
		for err in seq_errs:
			len_ = err[3]
			t_err = err[2]
			r_err = err[1]
			segment_errs[len_].append([t_err, r_err])
		# ----------------------------------------------------------------------
		# Compute average
		# ----------------------------------------------------------------------
		for len_ in self.lengths:
			if segment_errs[len_] != []:
				avg_t_err = np.mean(np.asarray(segment_errs[len_])[:, 0])
				avg_r_err = np.mean(np.asarray(segment_errs[len_])[:, 1])
				avg_segment_errs[len_] = [avg_t_err, avg_r_err]
			else:
				avg_segment_errs[len_] = []
		return avg_segment_errs

	def eval(self, result_dir):
		error_dir = result_dir + "/errors"
		self.plot_path_dir = result_dir + "/plot_path"
		plot_error_dir = result_dir + "/plot_error"

		if not os.path.exists(error_dir):
			os.makedirs(error_dir)
		if not os.path.exists(self.plot_path_dir):
			os.makedirs(self.plot_path_dir)
		if not os.path.exists(plot_error_dir):
			os.makedirs(plot_error_dir)

		total_err = []

		ave_t_errs = []
		ave_r_errs = []

		for seq in self.eval_seqs:
			self.cur_seq = seq
			file_name = seq + ".txt"

			poses_result = self.loadPoses(result_dir + "/" + file_name)
			poses_gt = self.loadPoses(self.gt_dir + "/" + file_name)
			self.result_file_name = result_dir + file_name

			# ----------------------------------------------------------------------
			# compute sequence errors
			# ----------------------------------------------------------------------
			seq_err = self.calcSequenceErrors(poses_gt, poses_result)
			self.saveSequenceErrors(seq_err, error_dir + "/" + file_name)

			# ----------------------------------------------------------------------
			# Compute segment errors
			# ----------------------------------------------------------------------
			avg_segment_errs = self.computeSegmentErr(seq_err)

			# ----------------------------------------------------------------------
			# compute overall error
			# ----------------------------------------------------------------------
			ave_t_err, ave_r_err = self.computeOverallErr(seq_err)
			sys.stderr.write("pose: " + seq + ":")
			sys.stderr.write("Average translational RMSE (%%): %.2f \n" %
							 (ave_t_err * 100))
			sys.stderr.write("Average rotational error (deg/100m): %.4f \n" %
							 (ave_r_err / np.pi * 180 * 100))
			ave_t_errs.append(ave_t_err)
			ave_r_errs.append(ave_r_err)
			f2.write("pose: " + seq + ": ")
			f2.write("Average translational RMSE (%%): %.2f " %
							 (ave_t_err * 100))
			f2.write("Average rotational error (deg/100m): %.4f " %
							 (ave_r_err / np.pi * 180 * 100))

class myImageFolder_test(data.Dataset):
	def __init__(self, left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, cam_intrinsic_path, pose,
				  param):
		self.left_image_test_1 = left_image_test_1
		self.right_image_test_1 = right_image_test_1
		self.left_image_test_2 = left_image_test_2
		self.right_image_test_2 = right_image_test_2
		self.cam_intrinsic_path = cam_intrinsic_path
		# self.gt_pose = gt_pose
		# self.pose_seq = pose_seq
		self.pose = pose
		self.param = param

	def __getitem__(self, index):
		left_image_test_1 = self.left_image_test_1[index]
		right_image_test_1 = self.right_image_test_1[index]
		left_image_test_2 = self.left_image_test_2[index]
		right_image_test_2 = self.right_image_test_2[index]
		cam_intrinsic_path = self.cam_intrinsic_path[index]
		# print(left_image_test_2)

		i = int(left_image_test_1.split('/')[-3])
		j = int(left_image_test_1.split('/')[-1].split('.')[0])

		pose1 = self.pose[i][j]
		#print("pose1    ", pose1)
		i = int(left_image_test_2.split('/')[-3])
		j = int(left_image_test_2.split('/')[-1].split('.')[0])
		# print("i  ", i)
		# print("j  ", j)
		pose2 = self.pose[i][j]

		param = self.param

		left_image_test_1 = Image.open(left_image_test_1).convert('RGB')
		right_image_test_1 = Image.open(right_image_test_1).convert('RGB')
		left_image_test_2 = Image.open(left_image_test_2).convert('RGB')
		right_image_test_2 = Image.open(right_image_test_2).convert('RGB')
		W, H = left_image_test_1.size

		process = get_transform_test(param)
		left_image_test_1 = process(left_image_test_1)
		right_image_test_1 = process(right_image_test_1)
		left_image_test_2 = process(left_image_test_2)
		right_image_test_2 = process(right_image_test_2)

		file = open(cam_intrinsic_path, 'r')
		last_line = file.readlines()[-1]
		raw_cam_vec = np.array(list(map(float,last_line.split()[1:])))
		raw_cam_mat = np.reshape(raw_cam_vec, (3, 4))
		raw_cam_mat = raw_cam_mat[0:3, 0:3]
		# width_ratio = 1
		# height_ratio = 1
		width_ratio = 896.0 / W
		height_ratio = 320.0 / H
		# K_yuan = raw_cam_mat[0:3, 0:3].copy()
		raw_cam_mat[0, 0] = raw_cam_mat[0, 0] * width_ratio
		raw_cam_mat[0, 2] = raw_cam_mat[0, 2] * width_ratio
		raw_cam_mat[1, 1] = raw_cam_mat[1, 1] * height_ratio
		raw_cam_mat[1, 2] = raw_cam_mat[1, 2] * height_ratio
		K = raw_cam_mat
		K_inv = np.linalg.inv(K)


		###############  pose load
		pose1_mat = np.array(list(map(float, pose1.split())))
		pose1_mat = np.reshape(pose1_mat, (3, 4))
		temp = np.reshape(np.array([0,0,0,1]),(1,4))
		pose1_mat = np.concatenate((pose1_mat, temp), 0)

		pose2_mat = np.array(list(map(float, pose2.split())))
		pose2_mat = np.reshape(pose2_mat, (3, 4))
		pose2_mat = np.concatenate((pose2_mat, temp), 0)

		pose_12_mat = np.dot(np.linalg.inv(pose2_mat), pose1_mat)
		pose_21_mat = np.linalg.inv(pose_12_mat)


		return left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, K, K_inv, pose_12_mat, pose_21_mat#, pose_21_mat, pose_12_mat
	def __len__(self):
		return len(self.left_image_test_1)

class myImageFolder_test1(data.Dataset):
	def __init__(self, left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, cam_intrinsic_path, pose,
				  param):
		self.left_image_test_1 = left_image_test_1
		self.right_image_test_1 = right_image_test_1
		self.left_image_test_2 = left_image_test_2
		self.right_image_test_2 = right_image_test_2
		self.cam_intrinsic_path = cam_intrinsic_path
		# self.gt_pose = gt_pose
		# self.pose_seq = pose_seq
		self.pose = pose
		self.param = param

	def __getitem__(self, index):
		left_image_test_1 = self.left_image_test_1[index]
		right_image_test_1 = self.right_image_test_1[index]
		left_image_test_2 = self.left_image_test_2[index]
		right_image_test_2 = self.right_image_test_2[index]
		cam_intrinsic_path = self.cam_intrinsic_path[index]
		# print(left_image_test_2)

		# i = int(left_image_test_1.split('/')[-3])
		# j = int(left_image_test_1.split('/')[-1].split('.')[0])

		# pose1 = self.pose[i][j]
		# i = int(left_image_test_2.split('/')[-3])
		# j = int(left_image_test_2.split('/')[-1].split('.')[0])
		# pose2 = self.pose[i][j]

		param = self.param

		left_image_test_1 = Image.open(left_image_test_1).convert('RGB')
		right_image_test_1 = Image.open(right_image_test_1).convert('RGB')
		left_image_test_2 = Image.open(left_image_test_2).convert('RGB')
		right_image_test_2 = Image.open(right_image_test_2).convert('RGB')
		W, H = left_image_test_1.size

		process = get_transform_test(param)
		left_image_test_1 = process(left_image_test_1)
		right_image_test_1 = process(right_image_test_1)
		left_image_test_2 = process(left_image_test_2)
		right_image_test_2 = process(right_image_test_2)

		file = open(cam_intrinsic_path, 'r')
		last_line = file.readlines()[-1]
		raw_cam_vec = np.array(list(map(float,last_line.split()[1:])))
		raw_cam_mat = np.reshape(raw_cam_vec, (3, 4))
		raw_cam_mat = raw_cam_mat[0:3, 0:3]
		# width_ratio = 1
		# height_ratio = 1
		width_ratio = 896.0 / W
		height_ratio = 320.0 / H
		# K_yuan = raw_cam_mat[0:3, 0:3].copy()
		raw_cam_mat[0, 0] = raw_cam_mat[0, 0] * width_ratio
		raw_cam_mat[0, 2] = raw_cam_mat[0, 2] * width_ratio
		raw_cam_mat[1, 1] = raw_cam_mat[1, 1] * height_ratio
		raw_cam_mat[1, 2] = raw_cam_mat[1, 2] * height_ratio
		K = raw_cam_mat
		K_inv = np.linalg.inv(K)


		###############  pose load
		# pose1_mat = np.array(list(map(float, pose1.split())))
		# pose1_mat = np.reshape(pose1_mat, (3, 4))
		# temp = np.reshape(np.array([0,0,0,1]),(1,4))
		# pose1_mat = np.concatenate((pose1_mat, temp), 0)

		# pose2_mat = np.array(list(map(float, pose2.split())))
		# pose2_mat = np.reshape(pose2_mat, (3, 4))
		# pose2_mat = np.concatenate((pose2_mat, temp), 0)

		# pose_12_mat = np.dot(np.linalg.inv(pose2_mat), pose1_mat)
		# pose_21_mat = np.linalg.inv(pose_12_mat)


		return left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, K, K_inv#, pose_12_mat, pose_21_mat#, pose_21_mat, pose_12_mat
	def __len__(self):
		return len(self.left_image_test_1)
if test_seq_09:
	# pose_seq = "09"
	# if test_seq_09 and test_seq_10:
	seqs=['09', '10']
	# seqs=['00', '01','02', '03','04', '05','06', '07','08']
	# seqs=['11','12','13','14', '15']
	for pose_seq in seqs:
		begin_time = time.time()
		filenames_file = "./utils/filenames/pose_" + pose_seq + "_pnp.txt"
		curr_pose_mat = np.identity(4)
		test_result_pose_mat_full = [curr_pose_mat]
		test_result_pose_mat = [np.reshape(curr_pose_mat[0:3, 0:4], [1, -1])]
		left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, cam_intrinsic_path, pose_path= \
			get_test_data(filenames_file, args.data_path, args.pose_path)

		TestImageLoader = torch.utils.data.DataLoader(
				myImageFolder_test(left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, cam_intrinsic_path,pose_path, args),
				batch_size = 1, shuffle = False, num_workers = 1, drop_last =False)
		for batch_idx, (left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, K, K_inv,pose_gt, pose_gt_2) in enumerate(TestImageLoader, 0):
		# for batch_idx, (left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, K, K_inv) in enumerate(TestImageLoader, 0):	
			model_input = Variable(torch.cat((left_image_test_1, right_image_test_1), 1).cuda())
			xx = net(model_input, 0)
			pose = pose_net(xx)

			########################
			pred_pose_mat = cal_one_pose_matrix(pose).squeeze(0)
			pred_pose_mat = pred_pose_mat.detach().cpu().numpy()
			#print("pose_mat shape: ", pred_pose_mat.shape)
			curr_pose_mat = np.matmul(pred_pose_mat, curr_pose_mat)

			test_result_pose_mat_full.append(curr_pose_mat)
			# tensor = np.linalg.inv(curr_pose_mat)[0:3, 0:4]
			# print("tensor:  ", tensor.shape)
			test_result_pose_mat.append(
				np.reshape(np.linalg.inv(curr_pose_mat)[0:3, 0:4], [1, -1]))
		end_time = time.time()
		print("time:  ", end_time-begin_time)

		if not os.path.exists(os.path.join(args.output_dir, "pred_poses")):
			os.mkdir(os.path.join(args.output_dir, "pred_poses"))
		if not os.path.exists(os.path.join(args.output_dir, "pred_poses", pose_seq)):
			os.mkdir(os.path.join(args.output_dir, "pred_poses", pose_seq))
		np.savetxt(
			args.output_dir + "/pred_poses/" + pose_seq + '.txt',
			np.concatenate(
				test_result_pose_mat, axis=0),
			fmt='%1.4e')
		with open("./pose_gt_data/" + pose_seq + ".txt") as f:
			times = f.readlines()
		times = [float(t.split(" ")[0]) for t in times]

		for i in range(len(test_result_pose_mat_full) - 4):
			curr_snippet = []
			for j in range(5):
				curr_snippet.append(
					np.matmul(test_result_pose_mat_full[i],
							  np.linalg.inv(test_result_pose_mat_full[i +
																	  j])))
			# Save aligned pose snippet
			dump_pose_seq_TUM(
				os.path.join(args.output_dir, "pred_poses", pose_seq,
							 str(i).zfill(6) + ".txt"), curr_snippet,
				times[i:(i + 5)])


if test_seq_09 and test_seq_10:
	seqs=['09', '10']
	# seqs=['00', '01','02', '03','04', '05','06', '07','08']
	# seqs=['11','12','13','14', '15']
	for pose_seq in seqs:
		print("pose seq %s: " % pose_seq)
		f2.write("pose: " + pose_seq + ": ")
		eval_snippet(
			os.path.join(args.output_dir, "pred_poses", pose_seq),
			os.path.join("./pose_gt_data/", pose_seq))

	odom_eval = kittiEvalOdom("./pose_gt_data/")
	odom_eval.eval_seqs = seqs
	odom_eval.eval(args.output_dir + "/pred_poses/")
	print("pose_prediction_finished \n")






