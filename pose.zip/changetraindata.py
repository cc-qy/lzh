import torch
import torchvision
import torchvision.transforms as transforms
import torch.utils.data as data
import numpy as np
import os
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse
import random
from PIL import Image
import matplotlib.pyplot as plt
import cv2
from models.PWC_net import *
from models.PWC_net import PWCDCNet
from utils.scene_dataloader import *
from utils.utils import *
from models.networks.submodules import *
from models.networks.resample2d_package.resample2d import Resample2d
# from epipolarloss.loss_functions import *

os.environ["CUDA_VISIBLE_DEVICES"] = "0"


file_path_train="./utils/filenames/train_08.txt"
f_train = open(file_path_train)
#former_left_image_train = list()
#latter_left_image_train = list()
# former_right_image_train = list()
# latter_right_image_train = list()
#cam_intrinsic_path = list()
# read from filesname_file   order is 0 2 1 3
lines = f_train.readlines()
    #print(lines)
with open("./utils/filenames/fileread.txt","w",encoding="utf-8") as f_w:
    for line in lines:
        i = int(line.split('/')[1])
        if (i==9)or(i==10):
            continue
        f_w.write(line)
