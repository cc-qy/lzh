## Testing
* Test on optical flow
```shell
python3 test_flow.py --data_path KITTI_PATH
                    --checkpoint_path YOUR_CHECKPOINT_PATH/TRAINED_MODEL_NAME
```



* Test on stereo matching
```shell
python3 test_stereo_epe.py --data_path KITTI_PATH
                    --checkpoint_path YOUR_CHECKPOINT_PATH/TRAINED_MODEL_NAME
python3 test_stereo.py --data_path KITTI_PATH
                    --checkpoint_path YOUR_CHECKPOINT_PATH/TRAINED_MODEL_NAME
```
The network will output `disparities.npy`, containing all the estimated disparities of test data. You need to evaluate it by running:
```shell
python3 utils/evaluate_kitti.py --split kitti --predicted_disp_path ./disparities.npy --gt_path ~/dataset/
```

python3 test_flow.py --checkpoint_path="/home/cc/ww/model/pnp_refine/flow_best" --data_path="/home/cc/dataset/KITTI"
python3 test_stereo_epe.py --checkpoint_path="/home/cc/ww/model/pnp_refine/depth_best_model_1" --data_path="/home/cc/dataset/KITTI"
python3 test_stereo.py --model_name=monodepth --data_path="/home/cc/dataset/KITTI"  --checkpoint_path="/home/cc/ww/model/pnp_refine/depth_best_model_1"
python3 utils/evaluate_kitti.py --split="kitti" --predicted_disp_path="./disparities.npy" --gt_path="/home/cc/dataset/KITTI/kitti_2015_flow/"

