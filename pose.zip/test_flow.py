import torch
import torchvision
import os
import torchvision.transforms as transforms
import torch.utils.data as data
import numpy as np
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse
import random
from PIL import Image
import matplotlib.pyplot as plt
import cv2
from models.PWC_net import *
from models.PWC_net import PWCDCNet
from models.PWC_depth_net import *
from models.PWC_depth_net import PWCDCNet_Disp
from utils.scene_dataloader import *
from utils.utils import *
from utils.evaluation_utils import *
from PIL import Image
from models.networks.submodules import *
from models.networks.resample2d_package.resample2d import Resample2d
import imageio
import warnings
warnings.filterwarnings("ignore")

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

def convertOptRGB(optical_flow):

    blob_x = optical_flow[1]
    blob_y = optical_flow[0]

    hsv = np.zeros((blob_x.shape[0], blob_y.shape[1], 3), np.uint8)
    mag, ang = cv2.cartToPolar(blob_x, blob_y)
    hsv[..., 0] = ang * 180 / np.pi / 2
    hsv[..., 1] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)
    hsv[..., 2] = 255
    bgr = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

    result = np.zeros((blob_x.shape[0], blob_x.shape[1], 3), np.uint8)
    result[:, :, 0] = bgr[:, :, 2]
    result[:, :, 1] = bgr[:, :, 1]
    result[:, :, 2] = bgr[:, :, 0]

    return result

def warp(x, flo):
    """
    warp an image/tensor (im2) back to im1, according to the optical flow
    x: [B, C, H, W] (im2)
    flo: [B, 2, H, W] flow
    """
    B, C, H, W = x.size()
    B_f, C_f, H_f, W_f = flo.size()
    # mesh grid
    if C_f == 1:
        flo = torch.cat((flo, torch.zeros_like(flo)), 1)
    xx = torch.arange(0, W).view(1, -1).repeat(H, 1)
    yy = torch.arange(0, H).view(-1, 1).repeat(1, W)
    xx = xx.view(1, 1, H, W).repeat(B, 1, 1, 1)
    yy = yy.view(1, 1, H, W).repeat(B, 1, 1, 1)
    grid = torch.cat((xx, yy), 1).float()

    if x.is_cuda:
        grid = grid.cuda()
    vgrid = Variable(grid) + flo

    # scale grid to [-1,1]
    ##2019 code
    vgrid[:, 0, :, :] = 2.0 * vgrid[:, 0, :, :].clone() / max(W - 1, 1) - 1.0
    vgrid[:, 1, :, :] = 2.0 * vgrid[:, 1, :, :].clone() / max(H - 1, 1) - 1.0
    vgrid = vgrid.permute(0, 2, 3, 1)
    output = nn.functional.grid_sample(x, vgrid)
    mask = torch.autograd.Variable(torch.ones(x.size())).cuda()
    mask = nn.functional.grid_sample(mask, vgrid)
    mask[mask < 0.9999] = 0
    mask[mask > 0] = 1
    return output * mask

def get_args():
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--data_path',                 type=str,   help='path to the data', required=True)
    parser.add_argument('--load_2015_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/2015_flow.txt")
    parser.add_argument('--load_2012_filenames_file',   type=str,   help='path to the filenames text file', default="./utils/filenames/2012_flow.txt")
    parser.add_argument('--input_height',              type=int,   help='input height', default=320)
    parser.add_argument('--input_width',               type=int,   help='input width', default=896)
    parser.add_argument('--min_depth',           type=float, help='minimum depth for evaluation',        default=1e-3)
    parser.add_argument('--max_depth',           type=float, help='maximum depth for evaluation',        default=80)
    parser.add_argument('--checkpoint_path',           type=str,   help='path to a specific checkpoint to load', required=True)
    parser.add_argument('--flow_diff_threshold', type=float,
                        help='threshold when comparing optical flow and rigid flow', default=3.5)
    args = parser.parse_args()
    return args

args = get_args()
test_kitti_2015 = True
test_2015_flow = True
test_kitti_2012 = True
test_2012_flow = True
print("begin to test"+ "\n")
###########load model##################
checkpoint = torch.load(args.checkpoint_path)
net = pwc_dc_net()
net.cuda()
net.load_state_dict(checkpoint['state_dict'])


if test_kitti_2012==True:
    print ("begin to test kitti 2012!" + "\n")
    left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, flow_noc, flow_occ, disp, K= \
        get_2015_test_data(args.load_2012_filenames_file, args.data_path)

    TestImageLoader = torch.utils.data.DataLoader(
            myImageFolder_2015_test(left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, flow_noc, flow_occ, disp, K, args),
            batch_size = 1, shuffle = False, num_workers = 1, drop_last =False)

    total_error_noc = fl_error_noc = total_error_occ = fl_error_occ = total_error_all = fl_error_all = 0.0
    num_test = 0

    for batch_idx, (left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2,
         f_noc, mask_noc, f_occ, mask_occ, disp_gt, h, w, K) in enumerate(TestImageLoader, 0):

        model_input = Variable(torch.cat((left_image_test_1, left_image_test_2),1).cuda())
        optical_flow  = net(model_input)

        if test_2012_flow == True:
            mask_noc = np.ceil(np.clip(np.abs(f_noc[0,0]), 0, 1))
            mask_occ = np.ceil(np.clip(np.abs(f_occ[0,0]), 0, 1))
            disp_ori_scale = F.interpolate(optical_flow[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
            disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
            disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

            error_noc, fl_noc = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_noc[0].numpy(), (mask_noc).numpy())
            total_error_noc += error_noc
            fl_error_noc += fl_noc

            error_occ, fl_occ = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_occ[0].numpy(), ((mask_occ-mask_noc)).numpy())
            total_error_occ += error_occ
            fl_error_occ += fl_occ

            error_all, fl_all = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_occ[0].numpy(), ((mask_occ)).numpy())
            total_error_all += error_all
            fl_error_all += fl_all

        num_test += 1
    if test_2012_flow == True:
        total_error_noc /= num_test
        fl_error_noc /= num_test
        print("The 2012 noc average EPE is : ", total_error_noc)
        print("The average Fl is : ", fl_error_noc)

        total_error_occ /= num_test
        fl_error_occ /= num_test
        print("The 2012 occ average EPE is : ", total_error_occ)
        print("The average Fl is : ", fl_error_occ)

        total_error_all /= num_test
        fl_error_all /= num_test
        print("The 2012 all average EPE is : ", total_error_all)
        print("The average Fl is : ", fl_error_all)

if test_kitti_2015==True:
    print ("\n"+"begin to test kitti 2015!" + "\n")
    left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, flow_noc, flow_occ, disp, K= \
        get_2015_test_data(args.load_2015_filenames_file, args.data_path)

    TestImageLoader = torch.utils.data.DataLoader(
            myImageFolder_2015_test(left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2, flow_noc, flow_occ, disp, K, args),
            batch_size = 1, shuffle = False, num_workers = 1, drop_last =False)

    total_error_noc = fl_error_noc = total_error_occ = fl_error_occ = total_error_all = fl_error_all = 0.0
    num_test = 0

    for batch_idx, (left_image_test_1, right_image_test_1, left_image_test_2, right_image_test_2,
         f_noc, mask_noc, f_occ, mask_occ, disp_gt, h, w, K) in enumerate(TestImageLoader, 0):

        model_input = Variable(torch.cat((left_image_test_1, left_image_test_2),1).cuda())
        optical_flow  = net(model_input)

        if test_2015_flow == True:
            mask_noc = np.ceil(np.clip(np.abs(f_noc[0,0]), 0, 1))
            mask_occ = np.ceil(np.clip(np.abs(f_occ[0,0]), 0, 1))
            disp_ori_scale = F.interpolate(optical_flow[0][:1], [int(h), int(w)], mode='bilinear', align_corners=True)
            disp_ori_scale[0,0] = disp_ori_scale[0,0] * int(w) / args.input_width
            disp_ori_scale[0,1] = disp_ori_scale[0,1] * int(h) / args.input_height

            error_noc, fl_noc = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_noc[0].numpy(), (mask_noc).numpy())
            total_error_noc += error_noc
            fl_error_noc += fl_noc

            error_occ, fl_occ = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_occ[0].numpy(), ((mask_occ-mask_noc)).numpy())
            total_error_occ += error_occ
            fl_error_occ += fl_occ

            error_all, fl_all = evaluate_flow(disp_ori_scale[0].data.cpu().numpy(), f_occ[0].numpy(), ((mask_occ)).numpy())
            total_error_all += error_all
            fl_error_all += fl_all

        num_test += 1
    if test_2015_flow == True:
        total_error_noc /= num_test
        fl_error_noc /= num_test
        print("The 2015 noc average EPE is : ", total_error_noc)
        print("The average Fl is : ", fl_error_noc)

        total_error_occ /= num_test
        fl_error_occ /= num_test
        print("The 2015 occ average EPE is : ", total_error_occ)
        print("The average Fl is : ", fl_error_occ)

        total_error_all /= num_test
        fl_error_all /= num_test
        print("The 2015 all average EPE is : ", total_error_all)
        print("The average Fl is : ", fl_error_all)
  

