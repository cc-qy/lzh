from __future__ import division
import sys
from glob import glob
import torch
import torchvision
import os
import torchvision.transforms as transforms
import torch.utils.data as data
import numpy as np
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse
import random
from PIL import Image
import cv2
import math
from models.PWC_net import *
from models.PWC_net import PWCDCNet





def eval_snippet(pred_dir, gt_dir):
	pred_files = glob(pred_dir + '/*.txt')
	ate_all = []
	for i in range(len(pred_files)):
		gtruth_file = gt_dir + "/" + os.path.basename(pred_files[i])
		if not os.path.exists(gtruth_file):
			continue
		ate = compute_ate(gtruth_file, pred_files[i])
		if ate == False:
			continue
		ate_all.append(ate)
	ate_all = np.array(ate_all)
	sys.stderr.write("ATE mean: %.4f, std: %.4f \n" %
					 (np.mean(ate_all), np.std(ate_all)))
	f2.write("ATE mean: %.4f, std: %.4f \n" %
					 (np.mean(ate_all), np.std(ate_all))+ " ")


def associate(first_list, second_list, offset, max_difference):
	"""
	Associate two dictionaries of (stamp,data). As the time stamps never match exactly, we aim
	to find the closest match for every input tuple.

	Input:
	first_list -- first dictionary of (stamp,data) tuples
	second_list -- second dictionary of (stamp,data) tuples
	offset -- time offset between both dictionaries (e.g., to model the delay between the sensors)
	max_difference -- search radius for candidate generation

	Output:
	matches -- list of matched tuples ((stamp1,data1),(stamp2,data2))

	"""
	first_keys = list(first_list.keys())
	print(first_keys)
	second_keys = list(second_list.keys())
	potential_matches = [(abs(a - (b + offset)), a, b)
						 for a in first_keys for b in second_keys
						 if abs(a - (b + offset)) < max_difference]
	potential_matches.sort()
	matches = []
	for diff, a, b in potential_matches:
		if a in first_keys and b in second_keys:
			first_keys.remove(a)
			second_keys.remove(b)
			matches.append((a, b))

	matches.sort()
	return matches
def read_file_list(filename):
	"""
	Reads a trajectory from a text file.

	File format:
	The file format is "stamp d1 d2 d3 ...", where stamp denotes the time stamp (to be matched)
	and "d1 d2 d3.." is arbitary data (e.g., a 3D position and 3D orientation) associated to this timestamp.

	Input:
	filename -- File name

	Output:
	dict -- dictionary of (stamp,data) tuples

	"""
	file = open(filename)
	data = file.read()
	lines = data.replace(",", " ").replace("\t", " ").split("\n")
	list = [[v.strip() for v in line.split(" ") if v.strip() != ""]
			for line in lines if len(line) > 0 and line[0] != "#"]
	list = [(float(l[0]), l[1:]) for l in list if len(l) > 1]
	print(dict(list))
	return dict(list)
'''
pred_dir=os.path.join(".", "pred_poses", '09')
#print(pred_dir)
pred_files = glob(pred_dir + '/*.txt')
#print(pred_files[0])
gtruth_file = "./pose_gt_data/09/000000.txt"
pred_file = "./pred_poses/09/000000.txt"
gtruth_list = read_file_list(gtruth_file)
#pred_list = read_file_list(pred_file)
#matches = associate(gtruth_list, pred_list, 0, 0.01)'''

		# ----------------------------------------------------------------------
f = open("./pred_poses/00.txt", 'r')
s = f.readlines()
f.close()
file_len = len(s)
poses = {}
for cnt, line in enumerate(s):
	P = np.eye(4)
	line_split = [float(i) for i in line.split(" ")]
	withIdx = int(len(line_split) == 13)
	for row in range(3):
		for col in range(4):
			P[row, col] = line_split[row * 4 + col + withIdx]
	if withIdx:
		frame_idx = line_split[0]
	else:
		frame_idx = cnt
	poses[frame_idx] = P
sort_frame_idx = sorted(poses.keys())
dist = [0]
for i in range(len(sort_frame_idx) - 1):
	cur_frame_idx = sort_frame_idx[i]
	next_frame_idx = sort_frame_idx[i + 1]
	P1 = poses[cur_frame_idx]
	P2 = poses[next_frame_idx]
	dx = P1[0, 3] - P2[0, 3]
	dy = P1[1, 3] - P2[1, 3]
	dz = P1[2, 3] - P2[2, 3]
	dist.append(dist[i] + np.sqrt(dx**2 + dy**2 + dz**2))
print(dist)