import torch
import torchvision
import torchvision.transforms as transforms
import torch.utils.data as data
import numpy as np
import os
from torch.autograd import Variable
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import argparse
import random
from PIL import Image
import matplotlib.pyplot as plt
import cv2
from models.PWC_net import *
from models.PWC_net import PWCDCNet
from utils.utils import *
from models.networks.submodules import *
from models.networks.resample2d_package.resample2d import Resample2d






def trajectoryDistances(poses):
    # ----------------------------------------------------------------------
    # poses: dictionary: [frame_idx: pose]
    # ----------------------------------------------------------------------
    dist = [0]
    sort_frame_idx = sorted(poses.keys())
    for i in range(len(sort_frame_idx) - 1):
        cur_frame_idx = sort_frame_idx[i]
        next_frame_idx = sort_frame_idx[i + 1]
        P1 = poses[cur_frame_idx]
        P2 = poses[next_frame_idx]
        dx = P1[0, 3] - P2[0, 3]
        dy = P1[1, 3] - P2[1, 3]
        dz = P1[2, 3] - P2[2, 3]
        dist.append(dist[i] + np.sqrt(dx**2 + dy**2 + dz**2))
    return dist


def loadPoses(file_name):
    # ----------------------------------------------------------------------
    # Each line in the file should follow one of the following structures
    # (1) idx pose(3x4 matrix in terms of 12 numbers)
    # (2) pose(3x4 matrix in terms of 12 numbers)
    # ----------------------------------------------------------------------
    f = open(file_name, 'r')
    s = f.readlines()
    f.close()
    file_len = len(s)
    poses = {}
    for cnt, line in enumerate(s):
        P = np.eye(4)
        line_split = [float(i) for i in line.split(" ")]
        withIdx = int(len(line_split) == 13)
        for row in range(3):
            for col in range(4):
                P[row, col] = line_split[row * 4 + col + withIdx]
        if withIdx:
            frame_idx = line_split[0]
        else:
            frame_idx = cnt
        poses[frame_idx] = P
    return poses

gt_dir = "./pose_gt_data/10.txt"
poses_gt = loadPoses(gt_dir)
dist = trajectoryDistances(poses_gt)
print(dist)







