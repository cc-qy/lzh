
from PIL import Image
import numpy as np
import copy
import numpy.ma as ma
# ==============================================================================
#                                                                   SCALE_TO_255
# ==============================================================================
def scale_to_255(a, min, max, dtype=np.uint8):
    """ Scales an array of values from specified min, max range to 0-255
        Optionally specify the data type of the output (default is uint8)
    """
    return (((a - min) / float(max - min)) * 255).astype(dtype)
 
# ==============================================================================
#                                                         POINT_CLOUD_2_BIRDSEYE
# ==============================================================================
def point_cloud_2_birdseye(points,
                           res=0.02,
                           side_range=(-20., 20.),  # left-most to right-most
                           fwd_range = (-10., 35.), # back-most to forward-most
                           height_range=(-3., 5.),  # bottom-most to upper-most
                           ):
    """ Creates an 2D birds eye view representation of the point cloud data.
 
    Args:
        points:     (numpy array)
                    N rows of points data
                    Each point should be specified by at least 3 elements x,y,z
        res:        (float)
                    Desired resolution in metres to use. Each output pixel will
                    represent an square region res x res in size.
        side_range: (tuple of two floats)
                    (-left, right) in metres
                    left and right limits of rectangle to look at.
        fwd_range:  (tuple of two floats)
                    (-behind, front) in metres
                    back and front limits of rectangle to look at.
        height_range: (tuple of two floats)
                    (min, max) heights (in metres) relative to the origin.
                    All height values will be clipped to this min and max value,
                    such that anything below min will be truncated to min, and
                    the same for values above max.
    Returns:
        2D numpy array representing an image of the birds eye view.
    """
    # EXTRACT THE POINTS FOR EACH AXIS
    x_points = points[:, 0]
    y_points = points[:, 1]
    z_points = points[:, 2]
    # FILTER - To return only indices of points within desired cube
    # Three filters for: Front-to-back, side-to-side, and height ranges
    # Note left side is positive y axis in LIDAR coordinates
    f_filt = np.logical_and((x_points > fwd_range[0]), (x_points < fwd_range[1]))
    s_filt = np.logical_and((y_points > -side_range[1]), (y_points < -side_range[0]))
    filter = np.logical_and(f_filt, s_filt)
    indices = np.argwhere(filter).flatten()
    # KEEPERS
    x_points = x_points[indices]
    y_points = y_points[indices]
    z_points = z_points[indices]
    # CONVERT TO PIXEL POSITION VALUES - Based on resolution
    x_img = (-y_points / res).astype(np.int32)  # x axis is -y in LIDAR
    y_img = (-x_points / res).astype(np.int32)  # y axis is -x in LIDAR
      # - Camera:   x: right,   y: down,  z: forward
  # - Velodyne: x: forward, y: left,  z: up
  # - GPS/IMU:  x: forward, y: left,  z: up
    # SHIFT PIXELS TO HAVE MINIMUM BE (0,0)
    # floor & ceil used to prevent anything being rounded to below 0 after shift
    x_img -= int(np.floor(side_range[0] / res))
    y_img += int(np.ceil(fwd_range[1] / res))
    # CLIP HEIGHT VALUES - to between min and max heights
    pixel_values = np.clip(a=z_points,
                           a_min=height_range[0],
                           a_max=height_range[1])
    # RESCALE THE HEIGHT VALUES - to be between the range 0-255
    pixel_values = scale_to_255(pixel_values,
                                min=height_range[0],
                                max=height_range[1])
    # INITIALIZE EMPTY ARRAY - of the dimensions we want
    x_max = 1 + int((side_range[1] - side_range[0]) / res)
    y_max = 1 + int((fwd_range[1] - fwd_range[0]) / res)
    im = np.zeros([y_max, x_max], dtype=np.uint8)
    # FILL PIXEL VALUES IN IMAGE ARRAY
    im[y_img, x_img] = pixel_values
 
    return im
# 
seq_num = 21
seq_train_frame = [154,447,233,144,314,
             297,270,800,390,803,
             294,373,78 ,340,106,
             376,209,145,339,1059,
             837]##21
seq_test_frame = [465,147,243,257,421,
             809,114,215,165,349,
             1176,774,694 ,152,850,
             701,510,305,180,404,
             173,203,436,430,316,
             176,170,85,175]##29

# P0 = np.matrix([[7.533745000000e-03, -9.999714000000e-01, -6.166020000000e-04 ,-4.069766000000e-03],
#                 [1.480249000000e-02 ,7.280733000000e-04, -9.998902000000e-01, -7.631618000000e-02],
#                 [9.998621000000e-01, 7.523790000000e-03, 1.480755000000e-02, -2.717806000000e-01],
#                 [0 ,  0   ,0  , 1]])
# Tr_velo_cam = np.matrix([[7.533745000000e-03, -9.999714000000e-01, -6.166020000000e-04 ,-4.069766000000e-03],
#                 [1.480249000000e-02 ,7.280733000000e-04, -9.998902000000e-01, -7.631618000000e-02],
#                 [9.998621000000e-01, 7.523790000000e-03, 1.480755000000e-02, -2.717806000000e-01],
#                 [0 ,  0   ,0  , 1]])

# Tr_imu_velo = np.matrix([[9.999976000000e-01, 7.553071000000e-04, -2.035826000000e-03, -8.086759000000e-01],
#                 [-7.854027000000e-04, 9.998898000000e-01, -1.482298000000e-02, 3.195559000000e-01],
#                 [2.024406000000e-03, 1.482454000000e-02, 9.998881000000e-01, -7.997231000000e-01],
#                 [0 ,  0   ,0  , 1]])

  # - Camera:   x: right,   y: down,  z: forward
  # - Velodyne: x: forward, y: left,  z: up
  # - GPS/IMU:  x: forward, y: left,  z: up
T01 = np.matrix([[1.0, 0,   0,   0],
                [0 ,   -1.0 ,  0,0],
                [0 ,   0 ,  -1.0  , 0],
                [0 ,  0   ,0  , 1.0]])

def read_obj_data(obj_i, obj_3D_box):
    obi_xyz = np.ones([1,3])
    obi_hwl = np.ones([1,3])
    obi_rotation_y = np.ones([1,1])
    obi_alpha = np.ones([1,1])
   
    obi_xyz = obj_3D_box[obj_i].split()[13:16]
    obi_hwl = obj_3D_box[obj_i].split()[10:13]
    obi_rotation_y = obj_3D_box[obj_i].split()[16]
    obi_alpha = obj_3D_box[obj_i].split()[5]

    return obi_xyz, obi_hwl, obi_rotation_y, obi_alpha

def read_pcl(i, j, Tr_velo_cam2):
    pointcloud_path = './velodyne/' + str(i).zfill(4) + '/' + str(j).zfill(6) + '.bin'
    pointcloud = np.fromfile(pointcloud_path, dtype=np.float32, count=-1).reshape([-1, 4])

    x = pointcloud[:, 0]  # x position of point
    y = pointcloud[:, 1]  # y position of point
    z = pointcloud[:, 2]  # z position of point

    # pose = np.ones([4,4])
    one = np.expand_dims(np.ones_like(z), 1)

    Nor_points = np.hstack((pointcloud[:, 0:3], one))
    Nor_points_cam2 = np.swapaxes(np.matmul(Tr_velo_cam2, np.swapaxes(Nor_points, 1, 0)), 0, 1)

    return Nor_points, Nor_points_cam2   

def read_calib(i):
    calib_path = './calib/' + str(i).zfill(4) + '.txt'
    f  = open(calib_path,'r')
    lines = f.readlines()
    P0 = np.ones([4,4])
    P1 = np.ones([4,4])
    P2 = np.ones([3,4])
    P3 = np.ones([4,4])
    R_rect = np.ones([4,4])
    Tr_velo_cam = np.ones([4,4])
    Tr_imu_velo = np.ones([4,4])
    Tr_cam0_cam2 = np.ones([4,4])
    # R_rect = np.ones([3,3])
    lens = len(lines)
    Tr_velo_cam[0] = lines[5].split()[1:5] 
    Tr_velo_cam[1] = lines[5].split()[5:9] 
    Tr_velo_cam[2] = lines[5].split()[9:13] 
    Tr_velo_cam[3] = [0,0,0,1]
    Tr_imu_velo[0] = lines[6].split()[1:5] 
    Tr_imu_velo[1] = lines[6].split()[5:9] 
    Tr_imu_velo[2] = lines[6].split()[9:13] 
    Tr_imu_velo[3] = [0,0,0,1]
    R_rect[0,0:3] = lines[4].split()[1:4] 
    R_rect[1,0:3] = lines[4].split()[4:7] 
    R_rect[2,0:3] = lines[4].split()[7:10] 
    R_rect[3] = 0.0
    R_rect[:,3] = 0.0
    R_rect[3,3] = 1.0

    Tr_cam0_cam2[0:3,0:3] = R_rect[:3,:3]
    Tr_cam0_cam2[3] = [0,0,0,1]
    Tr_cam0_cam2[1,3] = lines[2].split()[4]
    Tr_cam0_cam2[2,3] = lines[2].split()[1]
    Tr_cam0_cam2[0,3] = -Tr_cam0_cam2[1,3]/Tr_cam0_cam2[2,3]
    Tr_cam0_cam2[1:3,3] = 0
    P2[0] = lines[2].split()[1:5] 
    P2[1] = lines[2].split()[5:9] 
    P2[2] = lines[2].split()[9:13] 

    return R_rect, Tr_imu_velo, Tr_velo_cam, Tr_cam0_cam2, P2

def read_obj(i):
    obj_3D_box_path = './label_02/' + str(i).zfill(4) + '.txt'
    f  = open(obj_3D_box_path,'r')
    obj_3D_box = f.readlines()

    return obj_3D_box

def read_abs_pose_in_imu(i):
    pose_imu_gt_path = './pose_gt/' + str(i).zfill(4) + '.txt'
    f  = open(pose_imu_gt_path,'r')
    lines = f.readlines()
    pose_imu_gt_0 = lines[0].split(',')
    pose_imu_gt_1 = lines[1].split(',')
    pose_imu_gt_2 = lines[2].split(',')
    pose_imu_gt_3 = lines[3].split(',')

    return pose_imu_gt_0,pose_imu_gt_1,pose_imu_gt_2,pose_imu_gt_3

def read_one_pose_in_imu(j):
    pose_imu_gt_j_to_0 = np.zeros([4,4])
    # pose_imu_gt_jt1_to_0 = np.zeros([4,4])
    pose_imu_gt_j_to_0[0] = pose_imu_gt_0[(j * 4):(j * 4 + 4)]
    pose_imu_gt_j_to_0[1] = pose_imu_gt_1[(j * 4):(j * 4 + 4)]
    pose_imu_gt_j_to_0[2] = pose_imu_gt_2[(j * 4):(j * 4 + 4)]
    pose_imu_gt_j_to_0[3] = pose_imu_gt_3[(j * 4):(j * 4 + 4)]
    # print (pose_imu_gt_j_to_0)
    return pose_imu_gt_j_to_0

def cal_mask_obj(Nor_points_cam2, obi_xyz, obi_hwl, obi_rotation_y):
    Nor_points_obj = copy.deepcopy(Nor_points_cam2) 
    Nor_points_obj[:,0] = Nor_points_obj[:,0] - float(obi_xyz[0])
    Nor_points_obj[:,1] = Nor_points_obj[:,1] - float(obi_xyz[1])
    Nor_points_obj[:,2] = Nor_points_obj[:,2] - float(obi_xyz[2])
    mask_y = ma.masked_inside(Nor_points_obj[:,1],-float(obi_hwl[0]),0.0)
    # print (mask_y.mask)
    obi_rotation_y_final = 0.0
    if float(obi_rotation_y) < 0.0:
        obi_rotation_y_final = 2 * 3.1415926 + float(obi_rotation_y)
    if float(obi_rotation_y) > 0.0:
        obi_rotation_y_final = float(obi_rotation_y)
    if float(obi_rotation_y) ==0.0:
        print ("error obi_rotation_y",i," ",j)
    sin_rotation_y = np.sin(obi_rotation_y_final)
    cos_rotation_y = np.cos(obi_rotation_y_final)
    z_new = Nor_points_obj[:,0] * cos_rotation_y - Nor_points_obj[:,2] * sin_rotation_y
    x_new = Nor_points_obj[:,0] * sin_rotation_y + Nor_points_obj[:,2] * cos_rotation_y
    # print (obi_rotation_y_final,cos_rotation_y)
    mask_x = ma.masked_inside(x_new,-0.5*float(obi_hwl[1])-0.15,0.5*float(obi_hwl[1])+0.15)
    mask_z = ma.masked_inside(z_new,-0.5*float(obi_hwl[2])-0.15,0.5*float(obi_hwl[2])+0.15)
    mask_obj = mask_y.mask * mask_x.mask * mask_z.mask

    return mask_obj

def cal_obj_pose(obi_xyz, obi_rotation_y,obj_xyz, obj_rotation_y):
    obj_t_t_to_t1 = [float(obj_xyz[0]) - float(obi_xyz[0]), float(obj_xyz[1]) - float(obi_xyz[1]), float(obj_xyz[2]) - float(obi_xyz[2])]
    # print ("obj_t_t_to_t1: ", obj_t_t_to_t1)
    obj_R_t_to_t1 = 0.0
    if (float(obi_rotation_y)<0.0)&(float(obj_rotation_y)<0.0):
        obj_R_t_to_t1 = -float(obj_rotation_y) - (-float(obi_rotation_y))
    if (float(obi_rotation_y)<0.0)&(float(obj_rotation_y)>0.0):
        obj_R_t_to_t1 = (3.1415926+float(obi_rotation_y)) + (float(obj_rotation_y))
    if (float(obi_rotation_y)>0.0)&(float(obj_rotation_y)>0.0):
        obj_R_t_to_t1 = float(obj_rotation_y) - float(obi_rotation_y)
    if (float(obi_rotation_y)>0.0)&(float(obj_rotation_y)<0.0):
        obj_R_t_to_t1 = 3.1415926-float(obi_rotation_y) - (float(obj_rotation_y))
    obj_T_t_to_t1_matrix =  np.matrix([ [np.cos(obj_R_t_to_t1), 0,   np.sin(obj_R_t_to_t1),   float(obj_xyz[0]) - float(obi_xyz[0])],
                                        [0 ,   1,  0,float(obj_xyz[1]) - float(obi_xyz[1])],
                                        [-np.sin(obj_R_t_to_t1) ,   0 ,  np.cos(obj_R_t_to_t1)  , float(obj_xyz[2]) - float(obi_xyz[2])],
                                        [0 ,  0   ,0  , 1.0]])
    return obj_R_t_to_t1, obj_T_t_to_t1_matrix

def cal_mask_type(obj_i, obj_3D_box):
    mask_type = -1
    if (obj_3D_box[obj_i].split()[2]) == 'car':
        mask_type = 0
    if (obj_3D_box[obj_i].split()[2]) == 'Van':
        mask_type = 1
    if (obj_3D_box[obj_i].split()[2]) == 'Truck':
        mask_type = 2
    if (obj_3D_box[obj_i].split()[2]) == 'Pedestrian':
        mask_type = 3
    if (obj_3D_box[obj_i].split()[2]) == 'Person_sitting':
        mask_type = 4
    if (obj_3D_box[obj_i].split()[2]) == 'Cyclist':
        mask_type = 5
    if (obj_3D_box[obj_i].split()[2]) == 'Tram':
        mask_type = 6
    if (obj_3D_box[obj_i].split()[2]) == 'Misc':
        mask_type = 7
    if (obj_3D_box[obj_i].split()[2]) == 'DontCare':
        mask_type = 8

    return mask_type

def save_gt(i ,j ,scene_flow, scene_flow_gt):
    sceneflow_path = './velodyne/' + str(i).zfill(4) + '/' + str(j).zfill(6) + 'gt'
    scene_flow = np.hstack([scene_flow, scene_flow_gt])
    np.savez(sceneflow_path,scene_flow)

    return True

def save_pcl(i ,j ,points):
    sceneflow_path = './velodyne/' + str(i).zfill(4) + '/' + str(j).zfill(6) + 'pcl'
    scene_flow = points
    # print (scene_flow.shape)
    # xxx
    np.savez(sceneflow_path,scene_flow)

    return True



def view_point(points):
    real_points = copy.deepcopy(points)
    real_points[:,0] = +points[:,2]
    real_points[:,1] = -points[:,0]
    real_points[:,2] = -points[:,1]
    img = point_cloud_2_birdseye(real_points)

    return img


for i in range(0,21):
    print ("cal_seq: ",i)
    seq_frame = seq_train_frame[i]
    #####load data
    R_rect, Tr_imu_velo, Tr_velo_cam, Tr_cam0_cam2, P2 = read_calib(i)
    obj_3D_box = read_obj(i)
    pose_imu_gt_0,pose_imu_gt_1,pose_imu_gt_2,pose_imu_gt_3 = read_abs_pose_in_imu(i)

    #####cai data
    for j in range(0, seq_train_frame[i]-1, 1):
        if not((i==1) & (j>175) & (j<181)):
            pose_imu_gt_j_to_0 = read_one_pose_in_imu(j)
            pose_imu_gt_jt1_to_0 = read_one_pose_in_imu(j+1)

            pose_imu_gt_jt1_to_0_inv = np.linalg.inv(copy.deepcopy(pose_imu_gt_jt1_to_0))
            pose_imu_gt_jt_to_t1 = np.matmul(pose_imu_gt_jt1_to_0_inv, pose_imu_gt_j_to_0)

            T01_inv = np.linalg.inv(copy.deepcopy(T01))
            pose_imu_gt_jt_to_t1 = np.matmul(np.matmul(T01, pose_imu_gt_jt_to_t1), T01_inv)

            Tr_imu_velo_inv = np.linalg.inv(copy.deepcopy(Tr_imu_velo))
            pose_lidar_gt_jt_to_t1 = np.matmul(np.matmul(Tr_imu_velo, pose_imu_gt_jt_to_t1), Tr_imu_velo_inv)


            Tr_velo_cam2 = np.matmul(Tr_cam0_cam2, Tr_velo_cam)
            Tr_velo_cam2_inv = np.linalg.inv(copy.deepcopy(Tr_velo_cam2))
            pose_cam2_gt_jt_to_t1 = np.matmul(np.matmul(Tr_velo_cam2, pose_lidar_gt_jt_to_t1), Tr_velo_cam2_inv)

            Nor_points, Nor_points_cam2 = read_pcl(i, j, Tr_velo_cam2)
            Nor_points_2, Nor_points_cam2_2 = read_pcl(i, j+1, Tr_velo_cam2)
            Trans_Nor_points = np.swapaxes(np.matmul(pose_cam2_gt_jt_to_t1, np.swapaxes(Nor_points_cam2, 1, 0)), 0, 1)

            #####cal gt
            scene_flow = Trans_Nor_points - Nor_points_cam2
            scene_flow[:,3] = -1.0
            scene_flow_rigid = copy.deepcopy(scene_flow)
            scene_flow_gt = np.zeros_like(scene_flow)
            scene_flow_gt = np.hstack([scene_flow_gt, scene_flow_gt, scene_flow_gt, scene_flow_gt[:,0:3]])
            scene_flow_gt[:,0] = -1.0

            # #####view
            # img_1 = view_point(Nor_points_cam2)
            # img_2 = view_point(Nor_points_cam2_2)
            # img_1_warp_2 = view_point(Nor_points_cam2 + scene_flow)
            # img_1_rigid_2 = view_point(Nor_points_cam2 + scene_flow_rigid)

            # h, w = img_1.shape
            # im_write = np.zeros_like(img_1)[:,0:10]+255

            # im_write = np.expand_dims(im_write,axis = 2)
            # im_write_zero = np.zeros_like(im_write)
            # im_write = np.dstack([im_write, im_write, im_write]) 

            # img_1 = np.expand_dims(img_1,axis = 2)
            # im_write_zero = np.zeros_like(img_1)
            # img_1 = np.dstack([im_write_zero, img_1, im_write_zero]) 

            # img_2 = np.expand_dims(img_2,axis = 2)
            # im_write_zero = np.zeros_like(img_2)
            # img_2 = np.dstack([img_2, im_write_zero, im_write_zero]) 

            # img_1_warp_2 = np.expand_dims(img_1_warp_2,axis = 2)
            # im_write_zero = np.zeros_like(img_1_warp_2)
            # img_1_warp_2 = np.dstack([im_write_zero, img_1_warp_2, im_write_zero]) 

            # img_1_rigid_2 = np.expand_dims(img_1_rigid_2,axis = 2)
            # im_write_zero = np.zeros_like(img_1_rigid_2)
            # img_1_rigid_2 = np.dstack([img_1_rigid_2, img_1_rigid_2, img_1_rigid_2]) 

            # image_real_all = np.hstack([im_write,img_1, im_write, img_1+img_2, im_write, img_2+img_1_warp_2, im_write, img_2+img_1_rigid_2,im_write])

            # image_real_all_show = Image.fromarray(255-image_real_all)
            # image_real_all_show.save('./view/' + str(i).zfill(4) + '_' + str(j).zfill(6) + 'view_all.jpg')

            begin_id = -1
            end_id = -1
            count = 0
            for obj in obj_3D_box:
                if (int(obj.split()[0]) == j) & (begin_id == -1):
                    begin_id = count
                    # print ("xx000000x")
                if (int(obj.split()[0]) == (j+1)): 
                    end_id = count
                count = count + 1
            move_num = 0
            if (begin_id>-1)&(end_id>-1):
                for obj_i in range(begin_id, end_id):
                    for obj_j in range(obj_i+1, end_id+1):
                        if (int(obj_3D_box[obj_i].split()[1])==int(obj_3D_box[obj_j].split()[1]))&(int(obj_3D_box[obj_i].split()[1])!=-1):


                            obi_xyz, obi_hwl, obi_rotation_y, obi_alpha = read_obj_data(obj_i, obj_3D_box)
                            obj_xyz, obj_hwl, obj_rotation_y, obj_alpha = read_obj_data(obj_j, obj_3D_box)
                            # print (Nor_points_cam2[0], obi_xyz, obi_hwl, obi_rotation_y)

                            mask_obj_i = cal_mask_obj(Nor_points_cam2, obi_xyz, obi_hwl, obi_rotation_y)
                            # print (sum(mask_obj_i))
                            mask_obj_j = cal_mask_obj(Nor_points_cam2_2, obj_xyz, obj_hwl, obj_rotation_y)

                            obj_R_t_to_t1, obj_T_t_to_t1_matrix = cal_obj_pose(obi_xyz, obi_rotation_y,obj_xyz, obj_rotation_y)

                            Nor_points_cam2_obi = np.swapaxes(np.matmul(obj_T_t_to_t1_matrix, np.swapaxes(Nor_points_cam2, 1, 0)), 0, 1)

                            scene_flow_obj = Nor_points_cam2_obi - Nor_points_cam2

                            mask_type = cal_mask_type(obj_i, obj_3D_box)

                            scene_flow_obj[:,3][mask_obj_i] = mask_type
                            scene_flow[mask_obj_i] = scene_flow_obj[mask_obj_i]
                            # print (sum(mask_obj_i))

                            min_point = min(mask_obj_i.shape[0], mask_obj_j.shape[0])
                            if mask_obj_j.shape[0] > min_point:
                                scene_flow_gt[:,0][mask_obj_j[0:min_point]] = mask_type
                            else:
                                scene_flow_gt[0:mask_obj_j.shape[0],0][mask_obj_j] = mask_type

                            ##### move
                            obi_xyz_nor = np.vstack((np.expand_dims(obi_xyz, 1), np.ones([1,1])))
                            Nor_points_cam2_obi = np.swapaxes(np.matmul(pose_cam2_gt_jt_to_t1, obi_xyz_nor.astype(float)), 0, 1)
                            error = ((Nor_points_cam2_obi[0,0]-float(obj_xyz[0]))**2 + (Nor_points_cam2_obi[0,1]-float(obj_xyz[1]))**2 + (Nor_points_cam2_obi[0,2]-float(obj_xyz[2]))**2)**0.5

                            if error >0.1:
                                move_type = 1
                                move_num += 1
                                scene_flow_gt[:,1][mask_obj_i] = move_type
                                scene_flow_gt[:,2] = move_num
                            scene_flow_gt[:,3][mask_obj_i] = float(obi_rotation_y)
                            scene_flow_gt[:,4][mask_obj_i] = float(obj_rotation_y)
                            scene_flow_gt[:,5][mask_obj_i] = obj_R_t_to_t1
                            scene_flow_gt[:,6][mask_obj_i] = float(obi_xyz[0])
                            scene_flow_gt[:,7][mask_obj_i] = float(obi_xyz[1])
                            scene_flow_gt[:,8][mask_obj_i] = float(obi_xyz[2])
                            scene_flow_gt[:,9][mask_obj_i] = float(obj_xyz[0])
                            scene_flow_gt[:,10][mask_obj_i] = float(obj_xyz[1])
                            scene_flow_gt[:,11][mask_obj_i] = float(obj_xyz[2])
                            scene_flow_gt[:,12][mask_obj_i] = float(obi_hwl[0])
                            scene_flow_gt[:,13][mask_obj_i] = float(obi_hwl[1])
                            scene_flow_gt[:,14][mask_obj_i] = float(obi_hwl[2])         
                            # print ("end###################################################3 ")
        # flag = save_gt(i, j, scene_flow[mask], scene_flow_gt[mask])
        # flag_pcl = save_pcl(i, j, Nor_points_cam2[mask])
        # flag_pcl = save_pcl(i, j+1, Nor_points_cam2_2[mask_2])
        pc1_cam2_image = np.swapaxes(np.matmul(P2, np.matmul(R_rect, np.matmul(Tr_velo_cam, np.swapaxes(Nor_points, 1, 0)))), 0, 1)
        pc1_cam2_image = pc1_cam2_image / np.repeat(np.expand_dims(pc1_cam2_image[:,2], axis=1),3,axis=1)

        mask_w = ma.masked_inside(pc1_cam2_image[:,0],-0,1300)
        mask_h = ma.masked_inside(pc1_cam2_image[:,1],-0,370)
        mask_depth = ma.masked_inside(Nor_points_cam2[:,2],-0,35)
        mask = mask_w.mask * mask_h.mask * mask_depth.mask

        pc2_cam2_image = np.swapaxes(np.matmul(P2, np.matmul(R_rect, np.matmul(Tr_velo_cam, np.swapaxes(Nor_points_2, 1, 0)))), 0, 1)
        pc2_cam2_image = pc2_cam2_image / np.repeat(np.expand_dims(pc2_cam2_image[:,2], axis=1),3,axis=1)

        mask_w = ma.masked_inside(pc2_cam2_image[:,0],-0,1300)
        mask_h = ma.masked_inside(pc2_cam2_image[:,1],-0,370)
        mask_depth = ma.masked_inside(Nor_points_cam2_2[:,2],-0,35)
        mask_2 = mask_w.mask * mask_h.mask * mask_depth.mask

        # flag = save_gt(i, j, scene_flow[mask], scene_flow_gt[mask])
        flag_pcl = save_pcl(i, j, Nor_points_cam2[mask])
        flag_pcl = save_pcl(i, j+1, Nor_points_cam2_2[mask_2])
        # ####view
        # img_1 = view_point(Nor_points_cam2[mask])
        # img_2 = view_point(Nor_points_cam2_2[mask_2])
        # img_1_warp_2 = view_point(Nor_points_cam2[mask] + scene_flow[mask])
        # img_1_rigid_2 = view_point(Nor_points_cam2[mask] + scene_flow_rigid[mask])

        # h, w = img_1.shape
        # im_write = np.zeros_like(img_1)[:,0:10]+255

        # im_write = np.expand_dims(im_write,axis = 2)
        # im_write_zero = np.zeros_like(im_write)
        # im_write = np.dstack([im_write, im_write, im_write]) 

        # img_1 = np.expand_dims(img_1,axis = 2)
        # im_write_zero = np.zeros_like(img_1)
        # img_1 = np.dstack([im_write_zero, img_1, im_write_zero]) 

        # img_2 = np.expand_dims(img_2,axis = 2)
        # im_write_zero = np.zeros_like(img_2)
        # img_2 = np.dstack([img_2, im_write_zero, im_write_zero]) 

        # img_1_warp_2 = np.expand_dims(img_1_warp_2,axis = 2)
        # im_write_zero = np.zeros_like(img_1_warp_2)
        # img_1_warp_2 = np.dstack([im_write_zero, img_1_warp_2, im_write_zero]) 

        # img_1_rigid_2 = np.expand_dims(img_1_rigid_2,axis = 2)
        # im_write_zero = np.zeros_like(img_1_rigid_2)
        # img_1_rigid_2 = np.dstack([img_1_rigid_2, img_1_rigid_2, img_1_rigid_2]) 

        # image_real_all = np.hstack([im_write,img_1, im_write, img_1+img_2, im_write, img_2+img_1_warp_2, im_write, img_2+img_1_rigid_2,im_write])

        # image_real_all_show = Image.fromarray(255-image_real_all)
        # image_real_all_show.save('./view0/' + str(i).zfill(4) + '/' + str(j).zfill(6) + 'view_all.jpg')
        # # xxx


